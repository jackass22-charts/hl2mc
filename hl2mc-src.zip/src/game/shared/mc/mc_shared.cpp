//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Replicated convars shared by client and server.
//
//=============================================================================//

#include "cbase.h"
#include "mc/mc_shared.h"

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"

ConVar mc_enable( "mc_enable", "1", FCVAR_REPLICATED | FCVAR_NOTIFY,
	"Enable Minecraft-style player mechanics (hunger, sprint, sneak, fall damage, XP)." );

// Minecraft jump apex is about 1.25 blocks (50 units at 40 units/block).
// Vanilla HL2 is 21 units, so this changes which ledges you can reach. Lower it if a map gets too easy.
ConVar mc_jump_height( "mc_jump_height", "50", FCVAR_REPLICATED | FCVAR_NOTIFY,
	"Jump apex height in units while mc_enable is on (Minecraft: 1.25 blocks = 50).", true, 1.0f, true, 200.0f );

ConVar mc_sneak_edge_guard( "mc_sneak_edge_guard", "1", FCVAR_REPLICATED | FCVAR_NOTIFY,
	"While crouched (sneaking), stop at ledges instead of walking off them." );

ConVar mc_sprintjump_boost( "mc_sprintjump_boost", "80", FCVAR_REPLICATED | FCVAR_NOTIFY,
	"Forward speed added when jumping while sprinting (units/sec)." );

ConVar mc_sprintjump_speed( "mc_sprintjump_speed", "285", FCVAR_REPLICATED | FCVAR_NOTIFY,
	"Horizontal speed cap for the sprint-jump boost (Minecraft sprint-jumping averages ~7.1 blocks/sec = 285 units/sec)." );
