//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Loads the HUD sprites and bitmap font that tools/mc_extract_textures.py
//			copies out of the player's own Minecraft install, and draws them
//			with point sampling on Minecraft's GUI pixel grid.
//
//			If a sprite is missing (script not run yet), Find() returns NULL and
//			the HUD draws plain placeholder shapes instead.
//
//=============================================================================//

#ifndef MC_SPRITES_H
#define MC_SPRITES_H
#ifdef _WIN32
#pragma once
#endif

#include <vgui/VGUI.h>
#include "Color.h"
#include "utldict.h"

struct MCSprite_t
{
	int		iTexture;	// vgui texture id
	int		w, h;		// size in Minecraft GUI pixels
	float	u1, v1;		// texture coords of the bottom-right corner (sprites are padded to powers of two)
};

//-----------------------------------------------------------------------------
// Minecraft's GUI pixel grid. Everything is laid out in "GUI pixels" and
// multiplied by the GUI scale, like the real game.
//-----------------------------------------------------------------------------
struct MCGui_t
{
	int scale;	// screen pixels per GUI pixel
	int w, h;	// screen size in GUI pixels (rounded up)
};

MCGui_t MC_GetGui( void );

class CMCSprites
{
public:
	static CMCSprites &Get( void );

	void	Reload( void );

	const MCSprite_t *Find( const char *pszName );
	bool	Has( const char *pszName ) { return Find( pszName ) != NULL; }

	// Draw a sprite at GUI coordinates. flFraction < 1 crops it from the right (XP bar).
	// Returns false (and draws nothing) if the sprite isn't installed.
	bool	DrawSprite( const char *pszName, int x, int y, const MCGui_t &gui, Color clr = Color( 255, 255, 255, 255 ), float flFraction = 1.0f );

	// Text on the GUI grid, using the Minecraft bitmap font when installed.
	int		TextWidth( const char *pszText, const MCGui_t &gui );	// in GUI pixels
	void	DrawString( const char *pszText, int x, int y, const MCGui_t &gui, Color clr, bool bShadow = true );

	// Draw a solid rectangle on the GUI grid (placeholders and backgrounds).
	static void FillRect( int x, int y, int w, int h, const MCGui_t &gui, Color clr );

	bool	HasFont( void ) { EnsureLoaded(); return m_iFontTexture != -1; }
	bool	AnyLoaded( void ) { EnsureLoaded(); return m_Sprites.Count() > 0; }

private:
	CMCSprites();
	void	EnsureLoaded( void );
	int		LoadTexture( const char *pszMaterial );
	vgui::HFont FallbackFont( int iScale );

	bool					m_bLoaded;
	CUtlDict< MCSprite_t, unsigned short > m_Sprites;

	int						m_iFontTexture;
	int						m_iFontCell;		// cell size in texture pixels (8 for vanilla)
	int						m_iFontTexW, m_iFontTexH;
	unsigned char			m_Advance[256];		// per glyph advance in GUI pixels

	vgui::HFont				m_hFallbackFont;
	int						m_iFallbackScale;
};

#endif // MC_SPRITES_H
