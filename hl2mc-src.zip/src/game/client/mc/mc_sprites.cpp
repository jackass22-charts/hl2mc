//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Sprite and bitmap-font loader for the Minecraft-style HUD.
//
//=============================================================================//

#include "cbase.h"
#include "mc/mc_sprites.h"
#include "filesystem.h"
#include "KeyValues.h"
#include <vgui/ISurface.h>
#include <vgui/ILocalize.h>
#include <vgui_controls/Controls.h>
#include "tier3/tier3.h"

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"

using namespace vgui;

#define MC_SPRITES_FILE		"resource/mc_sprites.res"

ConVar mc_gui_scale( "mc_gui_scale", "0", FCVAR_ARCHIVE, "Minecraft GUI scale (0 = auto, like the game's Auto setting)." );

//-----------------------------------------------------------------------------
// Auto scale = the largest whole number that keeps at least 320x240 GUI pixels.
//-----------------------------------------------------------------------------
MCGui_t MC_GetGui( void )
{
	MCGui_t gui;
	const int sw = ScreenWidth();
	const int sh = ScreenHeight();

	int iMax = 1;
	while ( ( iMax + 1 ) * 320 <= sw && ( iMax + 1 ) * 240 <= sh )
		iMax++;

	int iScale = mc_gui_scale.GetInt();
	if ( iScale <= 0 || iScale > iMax )
		iScale = iMax;

	gui.scale = iScale;
	gui.w = ( sw + iScale - 1 ) / iScale;
	gui.h = ( sh + iScale - 1 ) / iScale;
	return gui;
}

//-----------------------------------------------------------------------------
CMCSprites &CMCSprites::Get( void )
{
	static CMCSprites s_Sprites;
	return s_Sprites;
}

CMCSprites::CMCSprites()
{
	m_bLoaded = false;
	m_iFontTexture = -1;
	m_iFontCell = 8;
	m_iFontTexW = m_iFontTexH = 128;
	m_hFallbackFont = INVALID_FONT;
	m_iFallbackScale = 0;
	memset( m_Advance, 6, sizeof( m_Advance ) );
}

void CMCSprites::Reload( void )
{
	m_bLoaded = false;
	m_Sprites.RemoveAll();
	m_iFontTexture = -1;
	EnsureLoaded();
}

int CMCSprites::LoadTexture( const char *pszMaterial )
{
	char szPath[MAX_PATH];
	Q_snprintf( szPath, sizeof( szPath ), "materials/%s.vmt", pszMaterial );
	if ( !g_pFullFileSystem->FileExists( szPath, "GAME" ) )
	{
		DevWarning( "[MC] missing HUD material %s\n", szPath );
		return -1;
	}

	// Reuse texture ids across reloads (vgui never frees them)
	static CUtlDict< int, unsigned short > s_TextureIds;
	unsigned short idx = s_TextureIds.Find( pszMaterial );
	int id;
	bool bReload = false;
	if ( idx != s_TextureIds.InvalidIndex() )
	{
		id = s_TextureIds[idx];
		bReload = true;
	}
	else
	{
		id = surface()->CreateNewTextureID();
		s_TextureIds.Insert( pszMaterial, id );
	}

	// hardwareFilter = false: crisp pixels (the VTFs are also flagged point-sample)
	surface()->DrawSetTextureFile( id, pszMaterial, false, bReload );
	return id;
}

void CMCSprites::EnsureLoaded( void )
{
	if ( m_bLoaded )
		return;
	m_bLoaded = true;

	KeyValues *pKV = new KeyValues( "MCSprites" );
	if ( !pKV->LoadFromFile( g_pFullFileSystem, MC_SPRITES_FILE, "GAME" ) )
	{
		Msg( "[MC] %s not found. Run tools/mc_extract_textures.py to copy HUD textures from your Minecraft install; using placeholder HUD.\n", MC_SPRITES_FILE );
		pKV->deleteThis();
		return;
	}

	KeyValues *pSprites = pKV->FindKey( "sprites" );
	if ( pSprites )
	{
		for ( KeyValues *pSub = pSprites->GetFirstTrueSubKey(); pSub; pSub = pSub->GetNextTrueSubKey() )
		{
			const char *pszMat = pSub->GetString( "material" );
			int tw = pSub->GetInt( "tw", 1 );
			int th = pSub->GetInt( "th", 1 );
			MCSprite_t sprite;
			sprite.w = pSub->GetInt( "w" );
			sprite.h = pSub->GetInt( "h" );
			if ( !pszMat[0] || sprite.w <= 0 || sprite.h <= 0 || tw <= 0 || th <= 0 )
				continue;

			sprite.iTexture = LoadTexture( pszMat );
			if ( sprite.iTexture == -1 )
				continue;

			// Size on screen is the sprite's GUI size; the texture may be an HD pack at a multiple of it.
			sprite.u1 = (float)pSub->GetInt( "pw", sprite.w ) / (float)tw;
			sprite.v1 = (float)pSub->GetInt( "ph", sprite.h ) / (float)th;
			m_Sprites.Insert( pSub->GetName(), sprite );
		}
	}

	KeyValues *pFont = pKV->FindKey( "font" );
	if ( pFont )
	{
		m_iFontTexture = LoadTexture( pFont->GetString( "material" ) );
		m_iFontCell = MAX( pFont->GetInt( "cell", 8 ), 1 );
		m_iFontTexW = MAX( pFont->GetInt( "tw", 128 ), 1 );
		m_iFontTexH = MAX( pFont->GetInt( "th", 128 ), 1 );

		// "advance" is 256 space-separated numbers in GUI pixels
		const char *p = pFont->GetString( "advance" );
		for ( int i = 0; i < 256 && *p; i++ )
		{
			while ( *p == ' ' ) p++;
			if ( !*p )
				break;
			m_Advance[i] = (unsigned char)clamp( atoi( p ), 0, 32 );
			while ( *p && *p != ' ' ) p++;
		}
	}

	DevMsg( "[MC] loaded %d HUD sprites%s\n", m_Sprites.Count(), m_iFontTexture != -1 ? " and the bitmap font" : "" );
	pKV->deleteThis();
}

const MCSprite_t *CMCSprites::Find( const char *pszName )
{
	EnsureLoaded();
	unsigned short idx = m_Sprites.Find( pszName );
	if ( idx == m_Sprites.InvalidIndex() )
		return NULL;
	return &m_Sprites[idx];
}

bool CMCSprites::DrawSprite( const char *pszName, int x, int y, const MCGui_t &gui, Color clr, float flFraction )
{
	const MCSprite_t *pSprite = Find( pszName );
	if ( !pSprite )
		return false;

	flFraction = clamp( flFraction, 0.0f, 1.0f );
	int w = (int)( pSprite->w * flFraction );
	if ( w <= 0 )
		return true;

	const int s = gui.scale;
	surface()->DrawSetColor( clr );
	surface()->DrawSetTexture( pSprite->iTexture );
	surface()->DrawTexturedSubRect( x * s, y * s, ( x + w ) * s, ( y + pSprite->h ) * s,
									0.0f, 0.0f, pSprite->u1 * ( (float)w / pSprite->w ), pSprite->v1 );
	return true;
}

void CMCSprites::FillRect( int x, int y, int w, int h, const MCGui_t &gui, Color clr )
{
	const int s = gui.scale;
	surface()->DrawSetColor( clr );
	surface()->DrawFilledRect( x * s, y * s, ( x + w ) * s, ( y + h ) * s );
}

//-----------------------------------------------------------------------------
// Text
//-----------------------------------------------------------------------------
vgui::HFont CMCSprites::FallbackFont( int iScale )
{
	if ( m_hFallbackFont == INVALID_FONT || m_iFallbackScale != iScale )
	{
		m_hFallbackFont = surface()->CreateFont();
		surface()->SetFontGlyphSet( m_hFallbackFont, "Courier New", 9 * iScale, 700, 0, 0, 0 );
		m_iFallbackScale = iScale;
	}
	return m_hFallbackFont;
}

int CMCSprites::TextWidth( const char *pszText, const MCGui_t &gui )
{
	EnsureLoaded();
	if ( m_iFontTexture != -1 )
	{
		int w = 0;
		for ( const char *p = pszText; *p; p++ )
			w += m_Advance[(unsigned char)*p];
		return w;
	}

	HFont hFont = FallbackFont( gui.scale );
	int w = 0;
	for ( const char *p = pszText; *p; p++ )
		w += surface()->GetCharacterWidth( hFont, (unsigned char)*p );
	return ( w + gui.scale - 1 ) / gui.scale;
}

void CMCSprites::DrawString( const char *pszText, int x, int y, const MCGui_t &gui, Color clr, bool bShadow )
{
	EnsureLoaded();
	const int s = gui.scale;

	if ( bShadow )
	{
		// Minecraft's drop shadow: same text, one pixel down-right, a quarter as bright
		Color shadow( clr.r() / 4, clr.g() / 4, clr.b() / 4, clr.a() );
		DrawString( pszText, x + 1, y + 1, gui, shadow, false );
	}

	if ( m_iFontTexture != -1 )
	{
		const float flCellU = (float)m_iFontCell / m_iFontTexW;
		const float flCellV = (float)m_iFontCell / m_iFontTexH;

		surface()->DrawSetColor( clr );
		surface()->DrawSetTexture( m_iFontTexture );

		int cx = x;
		for ( const char *p = pszText; *p; p++ )
		{
			unsigned char c = (unsigned char)*p;
			if ( c != ' ' )
			{
				float u0 = ( c % 16 ) * flCellU;
				float v0 = ( c / 16 ) * flCellV;
				surface()->DrawTexturedSubRect( cx * s, y * s, ( cx + 8 ) * s, ( y + 8 ) * s,
												u0, v0, u0 + flCellU, v0 + flCellV );
			}
			cx += m_Advance[c];
		}
		return;
	}

	// No font installed: draw with a system font on the same grid
	HFont hFont = FallbackFont( s );
	wchar_t wszText[256];
	g_pVGuiLocalize->ConvertANSIToUnicode( pszText, wszText, sizeof( wszText ) );
	surface()->DrawSetTextFont( hFont );
	surface()->DrawSetTextColor( clr );
	surface()->DrawSetTextPos( x * s, y * s - s );
	surface()->DrawPrintText( wszText, wcslen( wszText ) );
}

CON_COMMAND( mc_reload_textures, "Reload resource/mc_sprites.res and the Minecraft HUD textures." )
{
	CMCSprites::Get().Reload();
}
