//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Client view tweaks: sprint FOV and hiding the HL2 HUD elements the
//			Minecraft HUD replaces. Called from small hooks in hud.cpp and
//			clientmode_shared.cpp.
//
//=============================================================================//

#include "cbase.h"
#include "view_shared.h"
#include "c_basehlplayer.h"
#include "mc/mc_shared.h"

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"

extern ConVar mc_hud;

ConVar mc_fov_effects( "mc_fov_effects", "1", FCVAR_ARCHIVE, "Widen the view while sprinting (Minecraft's FOV Effects slider, 0-1)." , true, 0.0f, true, 1.0f );

//-----------------------------------------------------------------------------
// HL2 HUD elements replaced by the Minecraft HUD
//-----------------------------------------------------------------------------
static const char *s_pszReplacedHudElements[] =
{
	"CHudHealth",
	"CHudBattery",
	"CHudAmmo",
	"CHudSecondaryAmmo",
	"CHudWeaponSelection",
	"CHudCrosshair",
	"CHUDQuickInfo",
};

bool MC_ShouldHideHL2HudElement( const char *pszElementName )
{
	if ( !MC_IsEnabled() || !mc_hud.GetBool() || !pszElementName )
		return false;

	for ( int i = 0; i < ARRAYSIZE( s_pszReplacedHudElements ); i++ )
	{
		if ( !Q_strcmp( pszElementName, s_pszReplacedHudElements[i] ) )
			return true;
	}
	return false;
}

//-----------------------------------------------------------------------------
// Sprint FOV: Minecraft scales FOV by (1 + speed ratio) / 2, which is 1.15
// for sprinting, and eases toward it by half the gap each tick.
//-----------------------------------------------------------------------------
void MC_OverrideView( CViewSetup *pSetup )
{
	static float s_flModifier = 1.0f;
	static float s_flLastTime = 0.0f;

	const float flNow = gpGlobals->realtime;
	float flDelta = clamp( flNow - s_flLastTime, 0.0f, 0.25f );
	s_flLastTime = flNow;

	C_BaseHLPlayer *pPlayer = dynamic_cast< C_BaseHLPlayer * >( C_BasePlayer::GetLocalPlayer() );

	float flTarget = 1.0f;
	if ( MC_IsEnabled() && pPlayer && pPlayer->IsAlive() && pPlayer->m_fIsSprinting &&
		 !pPlayer->m_HL2Local.m_bZooming && !pPlayer->IsInAVehicle() )
	{
		flTarget = 1.0f + 0.15f * mc_fov_effects.GetFloat();
	}

	// 0.5 per 50 ms tick, made frame-rate independent
	const float flBlend = 1.0f - powf( 0.5f, flDelta / MC_TICK_INTERVAL );
	s_flModifier += ( flTarget - s_flModifier ) * flBlend;

	if ( fabsf( s_flModifier - 1.0f ) > 0.001f )
	{
		pSetup->fov = MIN( pSetup->fov * s_flModifier, 170.0f );
	}
}
