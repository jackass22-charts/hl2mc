//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Minecraft-style HUD.
//			- CHudMCStatus:    hearts, armor (suit battery), hunger, air bubbles, XP bar + level
//			- CHudMCHotbar:    9-slot hotbar of your weapons with ammo as stack counts,
//			                   selected-item name, plus the hotbar console commands
//			- CHudMCCrosshair: the crosshair
//
//			Layout follows Minecraft's GUI pixel grid (see MC_GetGui). Sprites come
//			from the player's own Minecraft install via mc_extract_textures.py;
//			without them the HUD falls back to plain placeholder shapes.
//
//=============================================================================//

#include "cbase.h"
#include "hud.h"
#include "hudelement.h"
#include "hud_macros.h"
#include "iclientmode.h"
#include "iinput.h"
#include "c_basehlplayer.h"
#include "mc/mc_shared.h"
#include "mc/mc_sprites.h"
#include <vgui_controls/Panel.h>
#include <vgui/ISurface.h>
#include <vgui/ILocalize.h>

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"

using namespace vgui;

ConVar mc_hud( "mc_hud", "1", FCVAR_ARCHIVE, "Use the Minecraft-style HUD (hides the HL2 health, suit, ammo, weapon selection and crosshair)." );
ConVar mc_hud_icon_color( "mc_hud_icon_color", "255 236 160", FCVAR_ARCHIVE, "Tint for HL2 weapon icons in the hotbar (R G B)." );

static inline bool MC_HudActive( void )
{
	return MC_IsEnabled() && mc_hud.GetBool();
}

// Deterministic per-tick "random" so jitter changes 20 times a second, like the game, not every frame
static inline int MC_TickRand( int iTick, int iSalt, int iRange )
{
	unsigned int h = (unsigned int)iTick * 2654435761u ^ (unsigned int)( iSalt + 1 ) * 2246822519u;
	h ^= h >> 13;
	h *= 3266489917u;
	h ^= h >> 16;
	return (int)( h % (unsigned int)iRange );
}

static inline int MC_CurrentTick( void )
{
	return (int)( gpGlobals->curtime / MC_TICK_INTERVAL );
}

//-----------------------------------------------------------------------------
// Draw a sprite, or a flat placeholder if the player hasn't extracted textures.
//-----------------------------------------------------------------------------
static void MC_Sprite( const char *pszName, int x, int y, const MCGui_t &gui, int w, int h, Color placeholder, float flFraction = 1.0f )
{
	if ( CMCSprites::Get().DrawSprite( pszName, x, y, gui, Color( 255, 255, 255, 255 ), flFraction ) )
		return;

	if ( placeholder.a() > 0 )
	{
		int pw = (int)( w * clamp( flFraction, 0.0f, 1.0f ) );
		if ( pw > 0 )
			CMCSprites::FillRect( x, y, pw, h, gui, placeholder );
	}
}

//=============================================================================
// Hotbar contents: the player's weapons in HL2 bucket order.
//=============================================================================
static int MC_WeaponSort( C_BaseCombatWeapon * const *a, C_BaseCombatWeapon * const *b )
{
	if ( (*a)->GetSlot() != (*b)->GetSlot() )
		return (*a)->GetSlot() - (*b)->GetSlot();
	return (*a)->GetPosition() - (*b)->GetPosition();
}

static void MC_GetWeapons( C_BasePlayer *pPlayer, CUtlVector< C_BaseCombatWeapon * > &list )
{
	list.RemoveAll();
	if ( !pPlayer )
		return;

	for ( int i = 0; i < pPlayer->WeaponCount(); i++ )
	{
		C_BaseCombatWeapon *pWeapon = pPlayer->GetWeapon( i );
		if ( pWeapon && pWeapon->VisibleInWeaponSelection() )
			list.AddToTail( pWeapon );
	}
	list.Sort( MC_WeaponSort );
}

// HL2 can carry more than 9 weapons, so the 9 visible slots scroll to keep the held one in view.
static int s_iMCHotbarWindow = 0;

static int MC_HotbarWindow( const CUtlVector< C_BaseCombatWeapon * > &list, C_BaseCombatWeapon *pActive )
{
	int iActive = list.Find( pActive );
	if ( iActive >= 0 )
	{
		if ( iActive < s_iMCHotbarWindow )
			s_iMCHotbarWindow = iActive;
		else if ( iActive >= s_iMCHotbarWindow + MC_HOTBAR_SLOTS )
			s_iMCHotbarWindow = iActive - MC_HOTBAR_SLOTS + 1;
	}
	s_iMCHotbarWindow = clamp( s_iMCHotbarWindow, 0, MAX( list.Count() - MC_HOTBAR_SLOTS, 0 ) );
	return s_iMCHotbarWindow;
}

static bool MC_SelectWeapon( C_BasePlayer *pPlayer, C_BaseCombatWeapon *pWeapon )
{
	if ( !pPlayer || !pWeapon )
		return false;

	if ( pWeapon == pPlayer->GetActiveWeapon() )
		return true;

	if ( !pWeapon->CanBeSelected() )
	{
		pPlayer->EmitSound( "Player.DenyWeaponSelection" );
		return false;
	}

	::input->MakeWeaponSelection( pWeapon );
	return true;
}

//-----------------------------------------------------------------------------
// Commands. mc_binds.cfg binds 1-9 and the mouse wheel to these.
//-----------------------------------------------------------------------------
CON_COMMAND( mc_hotbar, "Select hotbar slot 1-9." )
{
	if ( args.ArgC() < 2 )
		return;

	C_BasePlayer *pPlayer = C_BasePlayer::GetLocalPlayer();
	if ( !pPlayer || !pPlayer->IsAlive() )
		return;

	CUtlVector< C_BaseCombatWeapon * > list;
	MC_GetWeapons( pPlayer, list );

	int iSlot = atoi( args[1] ) - 1;
	if ( iSlot < 0 || iSlot >= MC_HOTBAR_SLOTS )
		return;

	int iIndex = MC_HotbarWindow( list, pPlayer->GetActiveWeapon() ) + iSlot;
	if ( list.IsValidIndex( iIndex ) )
		MC_SelectWeapon( pPlayer, list[iIndex] );
}

static void MC_HotbarStep( int iDir )
{
	C_BasePlayer *pPlayer = C_BasePlayer::GetLocalPlayer();
	if ( !pPlayer || !pPlayer->IsAlive() )
		return;

	CUtlVector< C_BaseCombatWeapon * > list;
	MC_GetWeapons( pPlayer, list );
	if ( list.Count() == 0 )
		return;

	int iStart = list.Find( pPlayer->GetActiveWeapon() );
	if ( iStart < 0 )
		iStart = iDir > 0 ? -1 : 0;

	// Like Minecraft, scrolling wraps around. Skip weapons that can't be drawn (no ammo).
	for ( int n = 1; n <= list.Count(); n++ )
	{
		int i = ( iStart + iDir * n + list.Count() * 2 ) % list.Count();
		if ( list[i]->CanBeSelected() )
		{
			MC_SelectWeapon( pPlayer, list[i] );
			return;
		}
	}
}

CON_COMMAND( mc_hotbar_next, "Select the next hotbar slot (mouse wheel down)." ) { MC_HotbarStep( 1 ); }
CON_COMMAND( mc_hotbar_prev, "Select the previous hotbar slot (mouse wheel up)." ) { MC_HotbarStep( -1 ); }

//=============================================================================
// Status bars: hearts, armor, food, air, experience
//=============================================================================
class CHudMCStatus : public CHudElement, public vgui::Panel
{
	DECLARE_CLASS_SIMPLE( CHudMCStatus, vgui::Panel );

public:
	CHudMCStatus( const char *pElementName );

	virtual void	Init( void );
	virtual void	Reset( void );
	virtual bool	ShouldDraw( void );
	virtual void	OnThink( void );
	virtual void	Paint( void );
	virtual void	ApplySchemeSettings( vgui::IScheme *pScheme );

private:
	void	PaintHearts( C_BaseHLPlayer *pPlayer, const MCGui_t &gui, int left, int top, int iTick );
	void	PaintArmor( C_BaseHLPlayer *pPlayer, const MCGui_t &gui, int left, int top );
	void	PaintFood( C_BaseHLPlayer *pPlayer, const MCGui_t &gui, int right, int top, int iTick );
	void	PaintAir( C_BaseHLPlayer *pPlayer, const MCGui_t &gui, int right, int top );
	void	PaintExperience( C_BaseHLPlayer *pPlayer, const MCGui_t &gui );

	int		m_iLastHealth;		// MC health points last frame
	int		m_iDisplayHealth;	// health shown by the blinking "lost" hearts
	float	m_flLastHealthTime;
	float	m_flBlinkUntil;
};

DECLARE_HUDELEMENT( CHudMCStatus );

CHudMCStatus::CHudMCStatus( const char *pElementName ) : CHudElement( pElementName ), BaseClass( NULL, "HudMCStatus" )
{
	SetParent( g_pClientMode->GetViewport() );
	SetHiddenBits( HIDEHUD_HEALTH | HIDEHUD_PLAYERDEAD );
	SetPaintBackgroundEnabled( false );
	SetMouseInputEnabled( false );
	SetKeyBoardInputEnabled( false );
}

void CHudMCStatus::Init( void )
{
	Reset();
}

void CHudMCStatus::Reset( void )
{
	m_iLastHealth = -1;
	m_iDisplayHealth = 0;
	m_flLastHealthTime = 0.0f;
	m_flBlinkUntil = 0.0f;
}

void CHudMCStatus::ApplySchemeSettings( vgui::IScheme *pScheme )
{
	BaseClass::ApplySchemeSettings( pScheme );
	SetBgColor( Color( 0, 0, 0, 0 ) );
	SetPaintBackgroundEnabled( false );
}

bool CHudMCStatus::ShouldDraw( void )
{
	return MC_HudActive() && CHudElement::ShouldDraw();
}

void CHudMCStatus::OnThink( void )
{
	SetBounds( 0, 0, ScreenWidth(), ScreenHeight() );

	C_BasePlayer *pPlayer = C_BasePlayer::GetLocalPlayer();
	if ( !pPlayer )
		return;

	const int iHealth = (int)ceilf( MAX( pPlayer->GetHealth(), 0 ) / MC_HL2HP_PER_MCHP );
	const float flNow = gpGlobals->curtime;

	if ( m_iLastHealth < 0 || flNow < m_flLastHealthTime )	// first frame or level load
	{
		m_iLastHealth = m_iDisplayHealth = iHealth;
		m_flLastHealthTime = flNow;
	}

	// Taking damage makes the hearts flash for a second, showing what you lost
	if ( iHealth < m_iLastHealth )
	{
		m_flLastHealthTime = flNow;
		m_flBlinkUntil = flNow + 1.0f;
	}

	if ( flNow - m_flLastHealthTime > 1.0f )
	{
		m_iDisplayHealth = iHealth;
		m_flLastHealthTime = flNow;
	}

	m_iLastHealth = iHealth;
}

void CHudMCStatus::Paint( void )
{
	C_BaseHLPlayer *pPlayer = dynamic_cast< C_BaseHLPlayer * >( C_BasePlayer::GetLocalPlayer() );
	if ( !pPlayer )
		return;

	const MCGui_t gui = MC_GetGui();
	const int iTick = MC_CurrentTick();
	const int cx = gui.w / 2;
	const int top = gui.h - 39;

	PaintExperience( pPlayer, gui );
	PaintHearts( pPlayer, gui, cx - 91, top, iTick );
	PaintArmor( pPlayer, gui, cx - 91, top - 10 );
	PaintFood( pPlayer, gui, cx + 91, top, iTick );
	PaintAir( pPlayer, gui, cx + 91, top - 10 );
}

void CHudMCStatus::PaintHearts( C_BaseHLPlayer *pPlayer, const MCGui_t &gui, int left, int top, int iTick )
{
	const int iHealth = (int)ceilf( MAX( pPlayer->GetHealth(), 0 ) / MC_HL2HP_PER_MCHP );
	const int iMaxHealth = (int)ceilf( MAX( pPlayer->GetMaxHealth(), 1 ) / MC_HL2HP_PER_MCHP );
	const int iHearts = clamp( ( iMaxHealth + 1 ) / 2, 1, 10 );

	// Blink in 3-tick halves while the flash lasts
	const int iBlinkTicks = (int)( ( m_flBlinkUntil - gpGlobals->curtime ) / MC_TICK_INTERVAL );
	const bool bBlink = iBlinkTicks > 0 && ( ( iBlinkTicks / 3 ) % 2 ) == 1;

	for ( int i = 0; i < iHearts; i++ )
	{
		const int x = left + i * 8;
		int y = top;

		// Low health: hearts jiggle
		if ( iHealth <= 4 )
			y += MC_TickRand( iTick, i, 2 );

		const int j = i * 2;

		MC_Sprite( bBlink ? "heart_container_blinking" : "heart_container", x, y, gui, 9, 9,
				   bBlink ? Color( 255, 255, 255, 200 ) : Color( 30, 0, 0, 200 ) );

		if ( bBlink && j < m_iDisplayHealth )
		{
			const bool bHalf = j + 1 == m_iDisplayHealth;
			MC_Sprite( bHalf ? "heart_half_blinking" : "heart_full_blinking", x, y, gui, bHalf ? 5 : 9, 9, Color( 255, 200, 200, 255 ) );
		}

		if ( j < iHealth )
		{
			const bool bHalf = j + 1 == iHealth;
			MC_Sprite( bHalf ? "heart_half" : "heart_full", x, y, gui, bHalf ? 5 : 9, 9, Color( 220, 20, 20, 255 ) );
		}
	}
}

void CHudMCStatus::PaintArmor( C_BaseHLPlayer *pPlayer, const MCGui_t &gui, int left, int top )
{
	// The HEV suit battery is the armor bar: 100 battery = 20 armor points
	const int iArmor = (int)ceilf( MAX( pPlayer->m_HL2Local.m_iMCArmor, 0 ) / MC_HL2HP_PER_MCHP );
	if ( iArmor <= 0 )
		return;

	for ( int i = 0; i < 10; i++ )
	{
		const int x = left + i * 8;
		const int j = i * 2 + 1;

		if ( j < iArmor )
			MC_Sprite( "armor_full", x, top, gui, 9, 9, Color( 200, 200, 210, 255 ) );
		else if ( j == iArmor )
			MC_Sprite( "armor_half", x, top, gui, 5, 9, Color( 200, 200, 210, 255 ) );
		else
			MC_Sprite( "armor_empty", x, top, gui, 9, 9, Color( 40, 40, 40, 160 ) );
	}
}

void CHudMCStatus::PaintFood( C_BaseHLPlayer *pPlayer, const MCGui_t &gui, int right, int top, int iTick )
{
	const int iFood = pPlayer->m_HL2Local.m_iMCFood;
	const float flSat = pPlayer->m_HL2Local.m_flMCSaturation;

	for ( int i = 0; i < 10; i++ )
	{
		const int x = right - i * 8 - 9;
		int y = top;

		// Out of saturation: the bar shakes, faster the hungrier you are
		if ( flSat <= 0.0f && ( iTick % ( iFood * 3 + 1 ) ) == 0 )
			y += MC_TickRand( iTick, 100 + i, 3 ) - 1;

		MC_Sprite( "food_empty", x, y, gui, 9, 9, Color( 30, 20, 10, 200 ) );

		const int j = i * 2 + 1;
		if ( j < iFood )
			MC_Sprite( "food_full", x, y, gui, 9, 9, Color( 190, 120, 50, 255 ) );
		else if ( j == iFood )
			MC_Sprite( "food_half", x, y, gui, 5, 9, Color( 190, 120, 50, 255 ) );
	}
}

void CHudMCStatus::PaintAir( C_BaseHLPlayer *pPlayer, const MCGui_t &gui, int right, int top )
{
	const int iAir = clamp( pPlayer->m_HL2Local.m_iMCAir, 0, MC_MAX_AIR );
	const bool bUnderwater = pPlayer->GetWaterLevel() == 3;
	if ( !bUnderwater && iAir >= MC_MAX_AIR )
		return;

	const int iFull = (int)ceil( ( iAir - 2 ) * 10.0 / MC_MAX_AIR );
	const int iPopping = (int)ceil( iAir * 10.0 / MC_MAX_AIR ) - iFull;
	const bool bHasEmpty = CMCSprites::Get().Has( "air_empty" );

	for ( int i = 0; i < 10; i++ )
	{
		const int x = right - i * 8 - 9;
		if ( i < iFull )
			MC_Sprite( "air", x, top, gui, 9, 9, Color( 80, 160, 255, 255 ) );
		else if ( i < iFull + iPopping )
			MC_Sprite( "air_bursting", x, top, gui, 9, 9, Color( 160, 210, 255, 255 ) );
		else if ( bHasEmpty )
			MC_Sprite( "air_empty", x, top, gui, 9, 9, Color( 0, 0, 0, 0 ) );
	}
}

void CHudMCStatus::PaintExperience( C_BaseHLPlayer *pPlayer, const MCGui_t &gui )
{
	const int cx = gui.w / 2;
	const int iLevel = pPlayer->m_HL2Local.m_iMCXPLevel;
	const float flProgress = pPlayer->m_HL2Local.m_flMCXPProgress;

	// Bar
	const int y = gui.h - 32 + 3;
	MC_Sprite( "xp_bar_background", cx - 91, y, gui, 182, 5, Color( 20, 20, 20, 200 ) );
	const int iFilled = (int)( flProgress * 183.0f );
	if ( iFilled > 0 )
		MC_Sprite( "xp_bar_progress", cx - 91, y, gui, 182, 5, Color( 128, 255, 32, 255 ), MIN( iFilled, 182 ) / 182.0f );

	// Level number: green with a 1px black outline
	if ( iLevel > 0 )
	{
		char szLevel[16];
		Q_snprintf( szLevel, sizeof( szLevel ), "%d", iLevel );

		CMCSprites &sprites = CMCSprites::Get();
		const int tx = ( gui.w - sprites.TextWidth( szLevel, gui ) ) / 2;
		const int ty = gui.h - 31 - 4;
		const Color black( 0, 0, 0, 255 );
		sprites.DrawString( szLevel, tx + 1, ty, gui, black, false );
		sprites.DrawString( szLevel, tx - 1, ty, gui, black, false );
		sprites.DrawString( szLevel, tx, ty + 1, gui, black, false );
		sprites.DrawString( szLevel, tx, ty - 1, gui, black, false );
		sprites.DrawString( szLevel, tx, ty, gui, Color( 0x80, 0xFF, 0x20, 255 ), false );
	}
}

//=============================================================================
// Hotbar
//=============================================================================
class CHudMCHotbar : public CHudElement, public vgui::Panel
{
	DECLARE_CLASS_SIMPLE( CHudMCHotbar, vgui::Panel );

public:
	CHudMCHotbar( const char *pElementName );

	virtual void	Reset( void );
	virtual bool	ShouldDraw( void );
	virtual void	OnThink( void );
	virtual void	Paint( void );
	virtual void	ApplySchemeSettings( vgui::IScheme *pScheme );

private:
	void	PaintIcon( C_BaseCombatWeapon *pWeapon, int x, int y, const MCGui_t &gui );
	void	PaintCount( C_BaseCombatWeapon *pWeapon, C_BasePlayer *pPlayer, int x, int y, const MCGui_t &gui );
	void	PaintItemName( const MCGui_t &gui );
	vgui::HFont IconFont( int iTall );

	EHANDLE		m_hLastActive;
	float		m_flNameShownAt;
	char		m_szName[64];

	CUtlMap< int, vgui::HFont > m_IconFonts;	// HL2 weapon-icon font at various sizes
};

DECLARE_HUDELEMENT( CHudMCHotbar );

CHudMCHotbar::CHudMCHotbar( const char *pElementName ) : CHudElement( pElementName ), BaseClass( NULL, "HudMCHotbar" ),
	m_IconFonts( DefLessFunc( int ) )
{
	SetParent( g_pClientMode->GetViewport() );
	SetHiddenBits( HIDEHUD_WEAPONSELECTION | HIDEHUD_PLAYERDEAD );
	SetPaintBackgroundEnabled( false );
	SetMouseInputEnabled( false );
	SetKeyBoardInputEnabled( false );
	m_flNameShownAt = -100.0f;
	m_szName[0] = 0;
}

void CHudMCHotbar::Reset( void )
{
	m_hLastActive = NULL;
	m_flNameShownAt = -100.0f;
}

void CHudMCHotbar::ApplySchemeSettings( vgui::IScheme *pScheme )
{
	BaseClass::ApplySchemeSettings( pScheme );
	SetBgColor( Color( 0, 0, 0, 0 ) );
	SetPaintBackgroundEnabled( false );
}

bool CHudMCHotbar::ShouldDraw( void )
{
	return MC_HudActive() && CHudElement::ShouldDraw();
}

void CHudMCHotbar::OnThink( void )
{
	SetBounds( 0, 0, ScreenWidth(), ScreenHeight() );

	C_BasePlayer *pPlayer = C_BasePlayer::GetLocalPlayer();
	C_BaseCombatWeapon *pActive = pPlayer ? pPlayer->GetActiveWeapon() : NULL;

	// Show the item's name for 2 seconds after switching
	if ( pActive && pActive != m_hLastActive.Get() )
	{
		m_flNameShownAt = gpGlobals->curtime;

		const char *pszPrint = pActive->GetPrintName();
		const wchar_t *pwsz = g_pVGuiLocalize->Find( pszPrint );
		if ( pwsz )
			g_pVGuiLocalize->ConvertUnicodeToANSI( pwsz, m_szName, sizeof( m_szName ) );
		else
			Q_strncpy( m_szName, pszPrint, sizeof( m_szName ) );
	}
	m_hLastActive = pActive;
}

vgui::HFont CHudMCHotbar::IconFont( int iTall )
{
	unsigned short idx = m_IconFonts.Find( iTall );
	if ( idx != m_IconFonts.InvalidIndex() )
		return m_IconFonts[idx];

	// "HalfLife2" is the icon font the HL2 scheme loads (halflife2.ttf)
	vgui::HFont hFont = surface()->CreateFont();
	surface()->SetFontGlyphSet( hFont, "HalfLife2", iTall, 0, 0, 0, ISurface::FONTFLAG_ANTIALIAS | ISurface::FONTFLAG_ADDITIVE | ISurface::FONTFLAG_CUSTOM );
	m_IconFonts.Insert( iTall, hFont );
	return hFont;
}

void CHudMCHotbar::PaintIcon( C_BaseCombatWeapon *pWeapon, int x, int y, const MCGui_t &gui )
{
	const CHudTexture *pIcon = pWeapon->GetSpriteInactive();
	if ( !pIcon )
		pIcon = pWeapon->GetSpriteActive();

	const int s = gui.scale;
	const int iBox = 18 * s;				// a little wider than an item, slots are 20 wide
	const int iCenterX = ( x + 8 ) * s;
	const int iCenterY = ( y + 8 ) * s;

	int r = 255, g = 236, b = 160;
	sscanf( mc_hud_icon_color.GetString(), "%d %d %d", &r, &g, &b );
	const Color tint( r, g, b, 255 );

	if ( !pIcon )
	{
		// No icon at all: first letter of the weapon name
		const char *pszClass = pWeapon->GetName();	// "weapon_xxx"
		char szLetter[2] = { Q_strlen( pszClass ) > 7 ? (char)toupper( pszClass[7] ) : '?', 0 };
		CMCSprites::Get().DrawString( szLetter, x + 5, y + 4, gui, tint );
		return;
	}

	if ( pIcon->bRenderUsingFont )
	{
		// Weapon icons are glyphs; size the font so the glyph fits the slot
		const wchar_t ch = (wchar_t)(unsigned char)pIcon->cCharacterInFont;
		int iTall = 16 * s;
		vgui::HFont hFont = IconFont( iTall );
		int w = surface()->GetCharacterWidth( hFont, ch );
		if ( w > iBox && w > 0 )
		{
			iTall = MAX( 4, iTall * iBox / w );
			hFont = IconFont( iTall );
			w = surface()->GetCharacterWidth( hFont, ch );
		}
		const int h = surface()->GetFontTall( hFont );

		surface()->DrawSetTextFont( hFont );
		surface()->DrawSetTextColor( tint );
		surface()->DrawSetTextPos( iCenterX - w / 2, iCenterY - h / 2 );
		surface()->DrawUnicodeChar( ch );
	}
	else
	{
		// Texture icon: keep aspect ratio inside the slot
		int w = pIcon->Width(), h = pIcon->Height();
		if ( w <= 0 || h <= 0 )
			return;
		float flScale = MIN( (float)iBox / w, (float)( 16 * s ) / h );
		int dw = (int)( w * flScale ), dh = (int)( h * flScale );
		pIcon->DrawSelf( iCenterX - dw / 2, iCenterY - dh / 2, dw, dh, tint );
	}
}

void CHudMCHotbar::PaintCount( C_BaseCombatWeapon *pWeapon, C_BasePlayer *pPlayer, int x, int y, const MCGui_t &gui )
{
	// Ammo shown like a stack count: clip + reserve
	if ( !pWeapon->UsesPrimaryAmmo() )
		return;

	int iCount = pPlayer->GetAmmoCount( pWeapon->GetPrimaryAmmoType() );
	if ( pWeapon->UsesClipsForAmmo1() )
		iCount += MAX( pWeapon->Clip1(), 0 );

	if ( iCount == 1 )
		return;	// Minecraft doesn't label single items

	char szCount[16];
	Q_snprintf( szCount, sizeof( szCount ), "%d", iCount );

	CMCSprites &sprites = CMCSprites::Get();
	const Color clr = iCount > 0 ? Color( 255, 255, 255, 255 ) : Color( 255, 85, 85, 255 );
	sprites.DrawString( szCount, x + 19 - 2 - sprites.TextWidth( szCount, gui ), y + 6 + 3, gui, clr, true );
}

void CHudMCHotbar::PaintItemName( const MCGui_t &gui )
{
	// 2 seconds total, fading over the last half second
	const float flAge = gpGlobals->curtime - m_flNameShownAt;
	if ( flAge < 0.0f || flAge > 2.0f || !m_szName[0] )
		return;

	int iAlpha = (int)( ( 2.0f - flAge ) / 0.5f * 255.0f );
	iAlpha = clamp( iAlpha, 0, 255 );
	if ( iAlpha < 5 )
		return;

	CMCSprites &sprites = CMCSprites::Get();
	const int x = ( gui.w - sprites.TextWidth( m_szName, gui ) ) / 2;
	const int y = gui.h - 59;
	sprites.DrawString( m_szName, x, y, gui, Color( 255, 255, 255, iAlpha ), true );
}

void CHudMCHotbar::Paint( void )
{
	C_BasePlayer *pPlayer = C_BasePlayer::GetLocalPlayer();
	if ( !pPlayer )
		return;

	const MCGui_t gui = MC_GetGui();
	const int cx = gui.w / 2;

	CUtlVector< C_BaseCombatWeapon * > list;
	MC_GetWeapons( pPlayer, list );
	C_BaseCombatWeapon *pActive = pPlayer->GetActiveWeapon();
	const int iWindow = MC_HotbarWindow( list, pActive );

	// Bar and selection frame
	MC_Sprite( "hotbar", cx - 91, gui.h - 22, gui, 182, 22, Color( 0, 0, 0, 120 ) );

	int iSelected = list.Find( pActive ) - iWindow;
	if ( iSelected >= 0 && iSelected < MC_HOTBAR_SLOTS )
	{
		const int sx = cx - 91 - 1 + iSelected * 20;
		const int sy = gui.h - 22 - 1;
		if ( !CMCSprites::Get().DrawSprite( "hotbar_selection", sx, sy, gui ) )
		{
			// Placeholder: white frame
			const Color white( 255, 255, 255, 255 );
			CMCSprites::FillRect( sx, sy, 24, 1, gui, white );
			CMCSprites::FillRect( sx, sy + 23, 24, 1, gui, white );
			CMCSprites::FillRect( sx, sy, 1, 24, gui, white );
			CMCSprites::FillRect( sx + 23, sy, 1, 24, gui, white );
		}
	}

	// Items
	for ( int iSlot = 0; iSlot < MC_HOTBAR_SLOTS; iSlot++ )
	{
		int i = iWindow + iSlot;
		if ( !list.IsValidIndex( i ) )
			break;

		const int x = cx - 90 + iSlot * 20 + 2;
		const int y = gui.h - 16 - 3;
		PaintIcon( list[i], x, y, gui );
		PaintCount( list[i], pPlayer, x, y, gui );
	}

	// More weapons than slots: small arrows at the ends
	if ( iWindow > 0 )
		CMCSprites::Get().DrawString( "<", cx - 91 - 7, gui.h - 15, gui, Color( 255, 255, 255, 200 ) );
	if ( iWindow + MC_HOTBAR_SLOTS < list.Count() )
		CMCSprites::Get().DrawString( ">", cx + 91 + 2, gui.h - 15, gui, Color( 255, 255, 255, 200 ) );

	PaintItemName( gui );
}

//=============================================================================
// Crosshair
//=============================================================================
class CHudMCCrosshair : public CHudElement, public vgui::Panel
{
	DECLARE_CLASS_SIMPLE( CHudMCCrosshair, vgui::Panel );

public:
	CHudMCCrosshair( const char *pElementName ) : CHudElement( pElementName ), BaseClass( NULL, "HudMCCrosshair" )
	{
		SetParent( g_pClientMode->GetViewport() );
		SetHiddenBits( HIDEHUD_PLAYERDEAD | HIDEHUD_CROSSHAIR );
		SetPaintBackgroundEnabled( false );
		SetMouseInputEnabled( false );
		SetKeyBoardInputEnabled( false );
	}

	virtual void ApplySchemeSettings( vgui::IScheme *pScheme )
	{
		BaseClass::ApplySchemeSettings( pScheme );
		SetBgColor( Color( 0, 0, 0, 0 ) );
		SetPaintBackgroundEnabled( false );
	}

	virtual bool ShouldDraw( void )
	{
		static ConVarRef crosshair( "crosshair" );
		if ( !MC_HudActive() || !crosshair.GetBool() || !CHudElement::ShouldDraw() )
			return false;

		// Hide while zoomed or driving, like HL2's own crosshair
		C_BaseHLPlayer *pPlayer = dynamic_cast< C_BaseHLPlayer * >( C_BasePlayer::GetLocalPlayer() );
		if ( !pPlayer || pPlayer->IsInAVehicle() || pPlayer->m_HL2Local.m_bZooming )
			return false;

		return g_pClientMode->ShouldDrawCrosshair();
	}

	virtual void OnThink( void )
	{
		SetBounds( 0, 0, ScreenWidth(), ScreenHeight() );
	}

	virtual void Paint( void )
	{
		const MCGui_t gui = MC_GetGui();
		const int x = ( gui.w - 15 ) / 2;
		const int y = ( gui.h - 15 ) / 2;

		if ( CMCSprites::Get().DrawSprite( "crosshair", x, y, gui, Color( 255, 255, 255, 220 ) ) )
			return;

		// Placeholder plus
		const Color clr( 255, 255, 255, 220 );
		CMCSprites::FillRect( x + 7, y, 1, 15, gui, clr );
		CMCSprites::FillRect( x, y + 7, 15, 1, gui, clr );
	}
};

DECLARE_HUDELEMENT( CHudMCCrosshair );
