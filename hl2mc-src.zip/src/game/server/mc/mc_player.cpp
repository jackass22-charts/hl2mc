//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Server side of the Minecraft mechanics, implemented as members of
//			CHL2_Player so they can use the player's protected state.
//
//			- Hunger, saturation and exhaustion (FoodData rules)
//			- Natural regeneration and starvation, by difficulty
//			- Sprinting: double-tap forward or hold sprint, needs food > 6,
//			  stops on release, wall hit, sneaking or low food
//			- Fall damage: 1 point per block fallen beyond 3
//			- Experience from kills, with the level curve
//			- Air: 15 seconds of breath, shown as bubbles
//
// All rules are re-implemented from public documentation of the game's
// behaviour. Health stays on HL2's 100 point scale (5 HL2 health = 1 MC point).
//
//=============================================================================//

#include "cbase.h"
#include "hl2_player.h"
#include "in_buttons.h"
#include "ai_basenpc.h"
#include "gamerules.h"
#include "mc/mc_shared.h"

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"

//-----------------------------------------------------------------------------
// Server settings
//-----------------------------------------------------------------------------
// Minecraft: walk 4.317 blocks/s, sprint 5.612 blocks/s. At 40 units per block:
ConVar mc_walk_speed( "mc_walk_speed", "173", FCVAR_NOTIFY, "Walking speed in units/sec (Minecraft: 4.317 blocks/s)." );
ConVar mc_sprint_speed( "mc_sprint_speed", "224", FCVAR_NOTIFY, "Sprinting speed in units/sec (Minecraft: 5.612 blocks/s)." );
ConVar mc_doubletap_sprint( "mc_doubletap_sprint", "1", FCVAR_ARCHIVE, "Double-tap forward to start sprinting." );
ConVar mc_doubletap_window( "mc_doubletap_window", "0.35", FCVAR_ARCHIVE, "Seconds allowed between the two forward taps (Minecraft: 7 ticks)." );
ConVar mc_hunger( "mc_hunger", "1", FCVAR_NOTIFY, "Enable hunger, saturation and exhaustion." );
ConVar mc_natural_regen( "mc_natural_regen", "1", FCVAR_NOTIFY, "Heal over time while well fed (the naturalRegeneration game rule)." );
ConVar mc_fall_damage( "mc_fall_damage", "1", FCVAR_NOTIFY, "Use Minecraft fall damage (1 point per block beyond 3)." );
ConVar mc_safe_fall_blocks( "mc_safe_fall_blocks", "3", FCVAR_NOTIFY, "Blocks you can fall without taking damage." );
ConVar mc_xp( "mc_xp", "1", FCVAR_NOTIFY, "Award experience for kills." );
ConVar mc_food_pickups( "mc_food_pickups", "1", FCVAR_NOTIFY, "Health kits and vials restore hunger instead of health." );
ConVar mc_debug_food( "mc_debug_food", "0", FCVAR_CHEAT, "Print hunger state changes to the console." );

static bool s_bMCSelfDamage = false;	// true while we apply starvation, so it doesn't add exhaustion

//-----------------------------------------------------------------------------
// Helpers
//-----------------------------------------------------------------------------
static inline float MC_CurrentGravity( CBasePlayer *pPlayer )
{
	static ConVarRef sv_gravity( "sv_gravity" );
	float flScale = pPlayer->GetGravity();
	if ( flScale == 0.0f )
		flScale = 1.0f;
	return sv_gravity.GetFloat() * flScale;
}

//-----------------------------------------------------------------------------
// Spawn: only transient state. Food and XP live in m_HL2Local, which starts
// at 20 food / 5 saturation and is carried through saves and level changes.
//-----------------------------------------------------------------------------
void CHL2_Player::MC_Spawn( void )
{
	m_flMCTickAccum = 0.0f;
	m_bMCHasLastOrigin = false;
	m_flMCLastForwardTap = -100.0f;
	m_flMCSprintStartTime = 0.0f;
	m_flMCBlockedTime = 0.0f;
	m_HL2Local.m_iMCAir = MC_MAX_AIR;

	if ( MC_IsEnabled() )
	{
		m_fIsWalking = false;
		SetMaxSpeed( mc_walk_speed.GetFloat() );
	}
}

//-----------------------------------------------------------------------------
// Sprint and walk speed. Runs every command from PreThink.
//-----------------------------------------------------------------------------
bool CHL2_Player::MC_HandleSpeedChanges( void )
{
	if ( !MC_IsEnabled() )
		return false;

	// HL2's walk key and no-suit walking don't exist in Minecraft.
	m_fIsWalking = false;

	const bool bOnGround = ( GetFlags() & FL_ONGROUND ) != 0;
	const bool bForward = ( m_nButtons & IN_FORWARD ) && !( m_nButtons & IN_BACK );
	const bool bSneaking = ( m_nButtons & IN_DUCK ) || ( m_Local.m_bDucked && bOnGround );
	const bool bEnoughFood = !mc_hunger.GetBool() || m_HL2Local.m_iMCFood > MC_SPRINT_MIN_FOOD;
	const bool bInWater = GetWaterLevel() >= 2;

	// Conditions that must hold for a sprint to start or continue
	const bool bCanSprint = m_bSprintEnabled &&		// physcannon holding something heavy turns this off
							bForward &&
							!bSneaking &&
							bEnoughFood &&
							!bInWater &&
							!IsInAVehicle() &&
							GetMoveType() != MOVETYPE_LADDER;

	if ( !IsSprinting() )
	{
		bool bTrigger = false;

		// Double-tap forward (only from the ground, like Minecraft)
		if ( m_afButtonPressed & IN_FORWARD )
		{
			if ( mc_doubletap_sprint.GetBool() && bOnGround &&
				 ( gpGlobals->curtime - m_flMCLastForwardTap ) <= mc_doubletap_window.GetFloat() )
			{
				bTrigger = true;
			}
			m_flMCLastForwardTap = gpGlobals->curtime;
		}

		// Holding the sprint key while moving forward
		if ( m_nButtons & IN_SPEED )
			bTrigger = true;

		if ( bTrigger && bCanSprint )
			MC_StartSprint();
	}
	else if ( !bCanSprint )
	{
		MC_StopSprint();
	}

	// Keep the speed pinned every frame; HL2 code elsewhere (StopSprinting,
	// suit pickup) likes to reset it to its own values.
	SetMaxSpeed( IsSprinting() ? mc_sprint_speed.GetFloat() : mc_walk_speed.GetFloat() );
	return true;
}

void CHL2_Player::MC_StartSprint( void )
{
	m_fIsSprinting = true;
	m_flMCSprintStartTime = gpGlobals->curtime;
	m_flMCBlockedTime = 0.0f;
}

void CHL2_Player::MC_StopSprint( void )
{
	m_fIsSprinting = false;
	m_flMCBlockedTime = 0.0f;
}

//-----------------------------------------------------------------------------
// Called after movement every command.
//-----------------------------------------------------------------------------
void CHL2_Player::MC_PostThink( void )
{
	if ( !MC_IsEnabled() || !IsAlive() )
	{
		m_bMCHasLastOrigin = false;
		return;
	}

	// Attacking costs exhaustion (once per trigger pull)
	if ( ( m_afButtonPressed & ( IN_ATTACK | IN_ATTACK2 ) ) && GetActiveWeapon() )
	{
		MC_AddExhaustion( MC_EXHAUST_ATTACK );
	}

	// Stop sprinting when running into a wall (Minecraft's horizontalCollision check)
	if ( IsSprinting() && ( GetFlags() & FL_ONGROUND ) )
	{
		const float flSpeed = GetAbsVelocity().Length2D();
		if ( gpGlobals->curtime - m_flMCSprintStartTime > 0.3f && flSpeed < mc_walk_speed.GetFloat() * 0.5f )
		{
			m_flMCBlockedTime += gpGlobals->frametime;
			if ( m_flMCBlockedTime > 0.1f )
				MC_StopSprint();
		}
		else
		{
			m_flMCBlockedTime = 0.0f;
		}
	}

	// Run Minecraft's 20 Hz game tick. Clamp so a hitch can't run hundreds of ticks.
	m_flMCTickAccum += clamp( gpGlobals->frametime, 0.0f, 0.25f );
	while ( m_flMCTickAccum >= MC_TICK_INTERVAL )
	{
		m_flMCTickAccum -= MC_TICK_INTERVAL;
		MC_Tick();
	}
}

void CHL2_Player::MC_Tick( void )
{
	m_HL2Local.m_iMCArmor = clamp( ArmorValue(), 0, 511 );
	MC_MovementExhaustionTick();
	MC_FoodTick();
	MC_AirTick();
}

//-----------------------------------------------------------------------------
// Exhaustion from distance moved this tick.
//-----------------------------------------------------------------------------
void CHL2_Player::MC_MovementExhaustionTick( void )
{
	const Vector &vecOrigin = GetAbsOrigin();

	if ( !m_bMCHasLastOrigin || IsInAVehicle() )
	{
		m_vecMCLastOrigin = vecOrigin;
		m_bMCHasLastOrigin = !IsInAVehicle();
		return;
	}

	Vector vecDelta = vecOrigin - m_vecMCLastOrigin;
	m_vecMCLastOrigin = vecOrigin;

	// Ignore teleports and level transitions (more than ~5 blocks in one tick)
	if ( vecDelta.LengthSqr() > ( 200.0f * 200.0f ) )
		return;

	if ( GetWaterLevel() >= 2 )
	{
		// Swimming: 0.01 per block travelled in any direction
		MC_AddExhaustion( MC_EXHAUST_SWIM_PER_BLOCK * vecDelta.Length() / MC_UNITS_PER_BLOCK );
	}
	else if ( ( GetFlags() & FL_ONGROUND ) && IsSprinting() )
	{
		// Sprinting: 0.1 per block travelled horizontally. Walking is free.
		MC_AddExhaustion( MC_EXHAUST_SPRINT_PER_BLOCK * vecDelta.Length2D() / MC_UNITS_PER_BLOCK );
	}
}

//-----------------------------------------------------------------------------
// Minecraft FoodData.tick(): burn exhaustion, regenerate, starve.
//-----------------------------------------------------------------------------
void CHL2_Player::MC_FoodTick( void )
{
	if ( !mc_hunger.GetBool() )
	{
		m_HL2Local.m_iMCFood = MC_MAX_FOOD;
		m_HL2Local.m_flMCSaturation = MC_START_SATURATION;
		m_HL2Local.m_flMCExhaustion = 0.0f;
		return;
	}

	// Burn exhaustion: every 4.0 removes one saturation, or one food once saturation is gone.
	if ( m_HL2Local.m_flMCExhaustion > 4.0f )
	{
		m_HL2Local.m_flMCExhaustion = m_HL2Local.m_flMCExhaustion - 4.0f;

		if ( m_HL2Local.m_flMCSaturation > 0.0f )
		{
			m_HL2Local.m_flMCSaturation = MAX( m_HL2Local.m_flMCSaturation - 1.0f, 0.0f );
		}
		else
		{
			m_HL2Local.m_iMCFood = MAX( m_HL2Local.m_iMCFood - 1, 0 );
		}

		if ( mc_debug_food.GetBool() )
		{
			Msg( "[MC] food %d  saturation %.1f\n", m_HL2Local.m_iMCFood.Get(), m_HL2Local.m_flMCSaturation.Get() );
		}
	}

	const bool bRegen = mc_natural_regen.GetBool();
	const bool bHurt = GetHealth() > 0 && GetHealth() < GetMaxHealth();
	const int iSkill = g_pGameRules ? g_pGameRules->GetSkillLevel() : SKILL_MEDIUM;

	if ( bRegen && m_HL2Local.m_flMCSaturation > 0.0f && bHurt && m_HL2Local.m_iMCFood >= MC_MAX_FOOD )
	{
		// Saturated regeneration: fast, paid for out of saturation
		if ( ++m_iMCFoodTickTimer >= 10 )
		{
			float flAmount = MIN( m_HL2Local.m_flMCSaturation.Get(), 6.0f );
			MC_Heal( flAmount / 6.0f );
			MC_AddExhaustion( flAmount );
			m_iMCFoodTickTimer = 0;
		}
	}
	else if ( bRegen && m_HL2Local.m_iMCFood >= 18 && bHurt )
	{
		// Normal regeneration: half a heart every 4 seconds
		if ( ++m_iMCFoodTickTimer >= 80 )
		{
			MC_Heal( 1.0f );
			MC_AddExhaustion( MC_EXHAUST_REGEN );
			m_iMCFoodTickTimer = 0;
		}
	}
	else if ( m_HL2Local.m_iMCFood <= 0 )
	{
		// Starving: half a heart every 4 seconds. Easy stops at 5 hearts, Normal at half a heart, Hard kills.
		if ( ++m_iMCFoodTickTimer >= 80 )
		{
			const float flMCHealth = GetHealth() / MC_HL2HP_PER_MCHP;
			if ( flMCHealth > 10.0f || iSkill == SKILL_HARD || ( flMCHealth > 1.0f && iSkill == SKILL_MEDIUM ) )
			{
				MC_DamageBypassingArmor( MC_HL2HP_PER_MCHP, DMG_GENERIC );
			}
			m_iMCFoodTickTimer = 0;
		}
	}
	else
	{
		m_iMCFoodTickTimer = 0;
	}
}

//-----------------------------------------------------------------------------
// Air: mirror HL2's drowning timer onto a 300 tick scale for the bubble HUD.
//-----------------------------------------------------------------------------
void CHL2_Player::MC_AirTick( void )
{
	if ( GetWaterLevel() == 3 && !CanBreatheUnderwater() )
	{
		// HL2 drowns you when m_AirFinished passes (12 s in HL2, set in WaterMove).
		const float flLeft = PlayerDrownTime() - gpGlobals->curtime;
		const float flAirTime = 12.0f;
		int iAir = (int)( MC_MAX_AIR * clamp( flLeft / flAirTime, 0.0f, 1.0f ) );
		m_HL2Local.m_iMCAir = iAir;
	}
	else
	{
		// Refill 4 per tick, like Minecraft
		m_HL2Local.m_iMCAir = MIN( m_HL2Local.m_iMCAir + 4, MC_MAX_AIR );
	}
}

//-----------------------------------------------------------------------------
// Events
//-----------------------------------------------------------------------------
void CHL2_Player::MC_OnJump( void )
{
	if ( !MC_IsEnabled() )
		return;

	MC_AddExhaustion( IsSprinting() ? MC_EXHAUST_SPRINT_JUMP : MC_EXHAUST_JUMP );
}

void CHL2_Player::MC_OnLand( float flFallVelocity )
{
	if ( !MC_IsEnabled() || !mc_fall_damage.GetBool() || !IsAlive() )
		return;

	// Landing in water, or riding something, never hurts.
	if ( GetWaterLevel() > 0 || IsInAVehicle() || GetMoveType() == MOVETYPE_LADDER )
		return;

	// Map scripts can request no fall damage (same input HL2 honours).
	if ( m_flTimeIgnoreFallDamage > gpGlobals->curtime )
		return;

	// Distance fallen from impact speed: h = v^2 / 2g
	const float flGravity = MC_CurrentGravity( this );
	if ( flGravity <= 0.0f || flFallVelocity <= 0.0f )
		return;

	const float flBlocks = ( flFallVelocity * flFallVelocity ) / ( 2.0f * flGravity ) / MC_UNITS_PER_BLOCK;
	const float flMCDamage = ceilf( flBlocks - mc_safe_fall_blocks.GetFloat() );
	if ( flMCDamage <= 0.0f )
		return;

	CTakeDamageInfo info( GetContainingEntity( INDEXENT( 0 ) ), GetContainingEntity( INDEXENT( 0 ) ),
						  flMCDamage * MC_HL2HP_PER_MCHP, DMG_FALL );
	TakeDamage( info );
	EmitSound( "Player.FallDamage" );
}

void CHL2_Player::MC_OnTakeDamage( const CTakeDamageInfo &info )
{
	if ( !MC_IsEnabled() || s_bMCSelfDamage )
		return;

	// Taking a hit costs 0.1 exhaustion (falling and drowning don't, per Minecraft's damage types).
	if ( info.GetDamage() > 0.0f && !( info.GetDamageType() & ( DMG_FALL | DMG_DROWN ) ) )
	{
		MC_AddExhaustion( MC_EXHAUST_DAMAGE );
	}
}

//-----------------------------------------------------------------------------
// Experience for kills. Hostiles give 5 like most Minecraft mobs, small
// critters 1-3, big enemies more. Friendly NPCs give nothing.
//-----------------------------------------------------------------------------
struct MCXPEntry_t
{
	const char *pszClass;
	int iMin;
	int iMax;
};

static const MCXPEntry_t s_MCXPTable[] =
{
	{ "npc_crow",				1,	3 },
	{ "npc_pigeon",				1,	3 },
	{ "npc_seagull",			1,	3 },
	{ "npc_headcrab",			5,	5 },
	{ "npc_headcrab_fast",		5,	5 },
	{ "npc_headcrab_black",		5,	5 },
	{ "npc_headcrab_poison",	5,	5 },
	{ "npc_manhack",			3,	3 },
	{ "npc_cscanner",			3,	3 },
	{ "npc_clawscanner",		3,	3 },
	{ "npc_rollermine",			5,	5 },
	{ "npc_combine_s",			5,	7 },
	{ "npc_metropolice",		5,	5 },
	{ "npc_zombine",			7,	7 },
	{ "npc_antlion",			5,	5 },
	{ "npc_antlion_worker",		5,	5 },
	{ "npc_barnacle",			5,	5 },
	{ "npc_ichthyosaur",		10,	10 },
	{ "npc_hunter",				20,	20 },
	{ "npc_antlionguard",		50,	50 },
	{ "npc_strider",			50,	50 },
	{ "npc_combinegunship",		50,	50 },
	{ "npc_helicopter",			50,	50 },
	{ "npc_combinedropship",	50,	50 },
	{ "npc_advisor",			100, 100 },
};

void CHL2_Player::MC_OnKilledOther( CBaseEntity *pVictim, const CTakeDamageInfo &info )
{
	if ( !MC_IsEnabled() || !mc_xp.GetBool() || !pVictim )
		return;

	CAI_BaseNPC *pNPC = pVictim->MyNPCPointer();
	if ( !pNPC )
		return;

	// No XP for killing friends (Minecraft villagers give none either)
	if ( pNPC->IRelationType( this ) == D_LI )
		return;

	int iXP = 5;
	const char *pszClass = pVictim->GetClassname();
	for ( int i = 0; i < ARRAYSIZE( s_MCXPTable ); i++ )
	{
		if ( FClassnameIs( pVictim, s_MCXPTable[i].pszClass ) )
		{
			iXP = RandomInt( s_MCXPTable[i].iMin, s_MCXPTable[i].iMax );
			break;
		}
	}

	if ( mc_debug_food.GetBool() )
		Msg( "[MC] +%d XP for %s\n", iXP, pszClass );

	MC_AddXP( iXP );
}

void CHL2_Player::MC_AddXP( int iXP )
{
	int iTotal = MAX( m_HL2Local.m_iMCXPTotal + iXP, 0 );
	int iOldLevel = m_HL2Local.m_iMCXPLevel;

	int iLevel;
	float flProgress;
	MC_XPLevelFromTotal( iTotal, iLevel, flProgress );

	m_HL2Local.m_iMCXPTotal = iTotal;
	m_HL2Local.m_iMCXPLevel = iLevel;
	m_HL2Local.m_flMCXPProgress = flProgress;

	// Ding every 5 levels, like the level-up chime
	if ( iLevel > iOldLevel && ( iLevel % 5 ) == 0 )
	{
		EmitSound( "HL2Player.PickupWeapon" );	// precached by CHL2_Player
	}
}

//-----------------------------------------------------------------------------
// Food
//-----------------------------------------------------------------------------
void CHL2_Player::MC_AddExhaustion( float flExhaustion )
{
	if ( !MC_IsEnabled() || !mc_hunger.GetBool() || flExhaustion <= 0.0f )
		return;

	m_HL2Local.m_flMCExhaustion = MIN( m_HL2Local.m_flMCExhaustion + flExhaustion, MC_MAX_EXHAUSTION );
}

bool CHL2_Player::MC_Eat( int iFood, float flSaturationModifier )
{
	if ( m_HL2Local.m_iMCFood >= MC_MAX_FOOD )
		return false;

	int iNewFood = MIN( m_HL2Local.m_iMCFood + iFood, MC_MAX_FOOD );
	float flNewSat = MIN( m_HL2Local.m_flMCSaturation + iFood * flSaturationModifier * 2.0f, (float)iNewFood );

	m_HL2Local.m_iMCFood = iNewFood;
	m_HL2Local.m_flMCSaturation = flNewSat;
	return true;	// the pickup plays its own sound
}

void CHL2_Player::MC_SetFood( int iFood, float flSaturation )
{
	m_HL2Local.m_iMCFood = clamp( iFood, 0, MC_MAX_FOOD );
	m_HL2Local.m_flMCSaturation = clamp( flSaturation, 0.0f, (float)m_HL2Local.m_iMCFood );
}

//-----------------------------------------------------------------------------
// Health helpers
//-----------------------------------------------------------------------------
void CHL2_Player::MC_Heal( float flMCHealth )
{
	m_flMCHealAccum += flMCHealth * MC_HL2HP_PER_MCHP;

	int iWhole = (int)m_flMCHealAccum;
	if ( iWhole > 0 )
	{
		TakeHealth( iWhole, DMG_GENERIC );
		m_flMCHealAccum -= iWhole;
	}
}

void CHL2_Player::MC_DamageBypassingArmor( float flHL2Damage, int iDamageType )
{
	// Attacker and inflictor = self + DMG_GENERIC skips HL2's skill scaling.
	// Starvation also ignores armor in Minecraft, so park the suit battery for the hit.
	int iArmor = ArmorValue();
	SetArmorValue( 0 );

	s_bMCSelfDamage = true;
	CTakeDamageInfo info( this, this, flHL2Damage, iDamageType );
	TakeDamage( info );
	s_bMCSelfDamage = false;

	if ( IsAlive() )
		SetArmorValue( iArmor );
}

//-----------------------------------------------------------------------------
// Pickups: called by item_healthkit / item_healthvial
//-----------------------------------------------------------------------------
bool MC_HealthPickup( CBasePlayer *pPlayer, float flHL2Health, int iFood, float flSaturationModifier )
{
	if ( MC_IsEnabled() && mc_food_pickups.GetBool() )
	{
		CHL2_Player *pHL2 = dynamic_cast< CHL2_Player * >( pPlayer );
		if ( pHL2 )
			return pHL2->MC_Eat( iFood, flSaturationModifier );
	}

	return pPlayer->TakeHealth( flHL2Health, DMG_GENERIC ) != 0;
}

//-----------------------------------------------------------------------------
// Console commands (cheats) for testing
//-----------------------------------------------------------------------------
CON_COMMAND_F( mc_setfood, "mc_setfood <food 0-20> [saturation]", FCVAR_CHEAT )
{
	CHL2_Player *pPlayer = dynamic_cast< CHL2_Player * >( UTIL_GetCommandClient() );
	if ( !pPlayer || args.ArgC() < 2 )
		return;

	int iFood = atoi( args[1] );
	float flSat = args.ArgC() > 2 ? atof( args[2] ) : pPlayer->MC_GetSaturation();
	pPlayer->MC_SetFood( iFood, flSat );
}

CON_COMMAND_F( mc_givexp, "mc_givexp <amount>", FCVAR_CHEAT )
{
	CHL2_Player *pPlayer = dynamic_cast< CHL2_Player * >( UTIL_GetCommandClient() );
	if ( !pPlayer || args.ArgC() < 2 )
		return;

	pPlayer->MC_AddXP( atoi( args[1] ) );
}
