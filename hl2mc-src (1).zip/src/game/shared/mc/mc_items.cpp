//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Item registry. Values follow Minecraft Java Edition.
//
//=============================================================================//

#include "cbase.h"
#include "mc/mc_items.h"

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"

#define BLOCK( id, name, disp, top, side, bottom, hard, tool, tier, drop, surf, cutout ) \
	{ id, MC_KIND_BLOCK, name, disp, top, side, bottom, hard, tool, tier, drop, surf, cutout, MC_TOOL_NONE, 0, 1.0f, 1.0f, 4.0f, 0 }

#define TOOL( id, name, disp, type, tier, speed, dmg, aspd, dur ) \
	{ id, MC_KIND_TOOL, name, disp, NULL, NULL, NULL, 0.0f, MC_TOOL_NONE, 0, MC_ITEM_NONE, NULL, false, type, tier, speed, dmg, aspd, dur }

static const MCItemDef_t s_ItemNone =
	{ MC_ITEM_NONE, MC_KIND_NONE, "air", "", NULL, NULL, NULL, 0.0f, MC_TOOL_NONE, 0, MC_ITEM_NONE, NULL, false, MC_TOOL_NONE, 0, 1.0f, 1.0f, 4.0f, 0 };

static const MCItemDef_t s_Items[] =
{
	//     id                       name             display            top                 side                 bottom          hard  best tool        tier drop                    surface     cutout
	BLOCK( MC_ITEM_GRASS_BLOCK,  "grass_block",  "Grass Block",  "grass_block_top", "grass_block_side", "dirt",         0.6f, MC_TOOL_SHOVEL,  0, MC_ITEM_DIRT,         "dirt",     false ),
	BLOCK( MC_ITEM_DIRT,         "dirt",         "Dirt",         "dirt",            "dirt",             "dirt",         0.5f, MC_TOOL_SHOVEL,  0, MC_ITEM_DIRT,         "dirt",     false ),
	BLOCK( MC_ITEM_STONE,        "stone",        "Stone",        "stone",           "stone",            "stone",        1.5f, MC_TOOL_PICKAXE, 1, MC_ITEM_COBBLESTONE,  "concrete", false ),
	BLOCK( MC_ITEM_COBBLESTONE,  "cobblestone",  "Cobblestone",  "cobblestone",     "cobblestone",      "cobblestone",  2.0f, MC_TOOL_PICKAXE, 1, MC_ITEM_COBBLESTONE,  "concrete", false ),
	BLOCK( MC_ITEM_OAK_PLANKS,   "oak_planks",   "Oak Planks",   "oak_planks",      "oak_planks",       "oak_planks",   2.0f, MC_TOOL_AXE,     0, MC_ITEM_OAK_PLANKS,   "wood",     false ),
	BLOCK( MC_ITEM_OAK_LOG,      "oak_log",      "Oak Log",      "oak_log_top",     "oak_log",          "oak_log_top",  2.0f, MC_TOOL_AXE,     0, MC_ITEM_OAK_LOG,      "wood",     false ),
	BLOCK( MC_ITEM_SAND,         "sand",         "Sand",         "sand",            "sand",             "sand",         0.5f, MC_TOOL_SHOVEL,  0, MC_ITEM_SAND,         "sand",     false ),
	BLOCK( MC_ITEM_GRAVEL,       "gravel",       "Gravel",       "gravel",          "gravel",           "gravel",       0.6f, MC_TOOL_SHOVEL,  0, MC_ITEM_GRAVEL,       "gravel",   false ),
	BLOCK( MC_ITEM_GLASS,        "glass",        "Glass",        "glass",           "glass",            "glass",        0.3f, MC_TOOL_NONE,    0, MC_ITEM_NONE,         "glass",    true  ),
	BLOCK( MC_ITEM_BRICKS,       "bricks",       "Bricks",       "bricks",          "bricks",           "bricks",       2.0f, MC_TOOL_PICKAXE, 1, MC_ITEM_BRICKS,       "brick",    false ),
	BLOCK( MC_ITEM_STONE_BRICKS, "stone_bricks", "Stone Bricks", "stone_bricks",    "stone_bricks",     "stone_bricks", 1.5f, MC_TOOL_PICKAXE, 1, MC_ITEM_STONE_BRICKS, "concrete", false ),
	BLOCK( MC_ITEM_OAK_LEAVES,   "oak_leaves",   "Oak Leaves",   "oak_leaves",      "oak_leaves",       "oak_leaves",   0.2f, MC_TOOL_NONE,    0, MC_ITEM_NONE,         "dirt",     true  ),

	//    id                          name               display            type             tier speed dmg   atk/s dur
	TOOL( MC_ITEM_WOODEN_PICKAXE,  "wooden_pickaxe",  "Wooden Pickaxe",  MC_TOOL_PICKAXE, 1, 2.0f, 2.0f, 1.2f, 59 ),
	TOOL( MC_ITEM_WOODEN_AXE,      "wooden_axe",      "Wooden Axe",      MC_TOOL_AXE,     1, 2.0f, 7.0f, 0.8f, 59 ),
	TOOL( MC_ITEM_WOODEN_SHOVEL,   "wooden_shovel",   "Wooden Shovel",   MC_TOOL_SHOVEL,  1, 2.0f, 2.5f, 1.0f, 59 ),
	TOOL( MC_ITEM_WOODEN_SWORD,    "wooden_sword",    "Wooden Sword",    MC_TOOL_SWORD,   1, 1.0f, 4.0f, 1.6f, 59 ),
	TOOL( MC_ITEM_STONE_PICKAXE,   "stone_pickaxe",   "Stone Pickaxe",   MC_TOOL_PICKAXE, 2, 4.0f, 3.0f, 1.2f, 131 ),
	TOOL( MC_ITEM_STONE_AXE,       "stone_axe",       "Stone Axe",       MC_TOOL_AXE,     2, 4.0f, 9.0f, 0.8f, 131 ),
	TOOL( MC_ITEM_STONE_SHOVEL,    "stone_shovel",    "Stone Shovel",    MC_TOOL_SHOVEL,  2, 4.0f, 3.5f, 1.0f, 131 ),
	TOOL( MC_ITEM_STONE_SWORD,     "stone_sword",     "Stone Sword",     MC_TOOL_SWORD,   2, 1.0f, 5.0f, 1.6f, 131 ),
	TOOL( MC_ITEM_IRON_PICKAXE,    "iron_pickaxe",    "Iron Pickaxe",    MC_TOOL_PICKAXE, 3, 6.0f, 4.0f, 1.2f, 250 ),
	TOOL( MC_ITEM_IRON_AXE,        "iron_axe",        "Iron Axe",        MC_TOOL_AXE,     3, 6.0f, 9.0f, 0.9f, 250 ),
	TOOL( MC_ITEM_IRON_SHOVEL,     "iron_shovel",     "Iron Shovel",     MC_TOOL_SHOVEL,  3, 6.0f, 4.5f, 1.0f, 250 ),
	TOOL( MC_ITEM_IRON_SWORD,      "iron_sword",      "Iron Sword",      MC_TOOL_SWORD,   3, 1.0f, 6.0f, 1.6f, 250 ),
	TOOL( MC_ITEM_DIAMOND_PICKAXE, "diamond_pickaxe", "Diamond Pickaxe", MC_TOOL_PICKAXE, 4, 8.0f, 5.0f, 1.2f, 1561 ),
	TOOL( MC_ITEM_DIAMOND_AXE,     "diamond_axe",     "Diamond Axe",     MC_TOOL_AXE,     4, 8.0f, 9.0f, 1.0f, 1561 ),
	TOOL( MC_ITEM_DIAMOND_SHOVEL,  "diamond_shovel",  "Diamond Shovel",  MC_TOOL_SHOVEL,  4, 8.0f, 5.5f, 1.0f, 1561 ),
	TOOL( MC_ITEM_DIAMOND_SWORD,   "diamond_sword",   "Diamond Sword",   MC_TOOL_SWORD,   4, 1.0f, 7.0f, 1.6f, 1561 ),
};

// HL2 weapons tracked in the inventory (item id = MC_ITEM_WEAPON_FIRST + index)
static const char *s_WeaponClasses[] =
{
	"weapon_crowbar",
	"weapon_physcannon",
	"weapon_stunstick",
	"weapon_pistol",
	"weapon_357",
	"weapon_smg1",
	"weapon_ar2",
	"weapon_shotgun",
	"weapon_crossbow",
	"weapon_frag",
	"weapon_rpg",
	"weapon_bugbait",
	"weapon_alyxgun",
	"weapon_annabelle",
	"weapon_citizenpackage",
	"weapon_citizensuitcase",
	"weapon_physgun",
	"weapon_slam",
};

static const MCItemDef_t s_WeaponDef =
	{ MC_ITEM_WEAPON_FIRST, MC_KIND_WEAPON, "weapon", "Weapon", NULL, NULL, NULL, 0.0f, MC_TOOL_NONE, 0, MC_ITEM_NONE, NULL, false, MC_TOOL_NONE, 0, 1.0f, 1.0f, 4.0f, 0 };

//-----------------------------------------------------------------------------
static const MCItemDef_t *s_pLookup[MC_ITEM_COUNT];
static bool s_bLookupBuilt = false;

static void MC_BuildLookup( void )
{
	if ( s_bLookupBuilt )
		return;
	for ( int i = 0; i < MC_ITEM_COUNT; i++ )
		s_pLookup[i] = &s_ItemNone;
	for ( int i = 0; i < ARRAYSIZE( s_Items ); i++ )
		s_pLookup[ s_Items[i].id ] = &s_Items[i];
	for ( int i = 0; i < ARRAYSIZE( s_WeaponClasses ) && MC_ITEM_WEAPON_FIRST + i <= MC_ITEM_WEAPON_LAST; i++ )
		s_pLookup[ MC_ITEM_WEAPON_FIRST + i ] = &s_WeaponDef;
	s_bLookupBuilt = true;
}

const MCItemDef_t *MC_GetItem( int iItem )
{
	MC_BuildLookup();
	if ( iItem < 0 || iItem >= MC_ITEM_COUNT )
		return &s_ItemNone;
	return s_pLookup[iItem];
}

bool MC_IsBlock( int iItem )		{ return MC_GetItem( iItem )->kind == MC_KIND_BLOCK; }
bool MC_IsTool( int iItem )			{ return MC_GetItem( iItem )->kind == MC_KIND_TOOL; }
bool MC_IsWeaponItem( int iItem )	{ return MC_GetItem( iItem )->kind == MC_KIND_WEAPON; }

int MC_GetMaxStack( int iItem )
{
	switch ( MC_GetItem( iItem )->kind )
	{
	case MC_KIND_BLOCK:	return 64;
	case MC_KIND_NONE:	return 0;
	default:			return 1;
	}
}

int MC_FindItemByName( const char *pszName )
{
	if ( !pszName || !pszName[0] )
		return MC_ITEM_NONE;
	if ( !Q_strnicmp( pszName, "minecraft:", 10 ) )
		pszName += 10;
	for ( int i = 0; i < ARRAYSIZE( s_Items ); i++ )
	{
		if ( !Q_stricmp( s_Items[i].pszName, pszName ) )
			return s_Items[i].id;
	}
	return MC_ITEM_NONE;
}

int MC_WeaponItemForClass( const char *pszClassname )
{
	if ( !pszClassname )
		return MC_ITEM_NONE;
	for ( int i = 0; i < ARRAYSIZE( s_WeaponClasses ); i++ )
	{
		if ( !Q_stricmp( s_WeaponClasses[i], pszClassname ) )
			return MC_ITEM_WEAPON_FIRST + i;
	}
	return MC_ITEM_NONE;
}

const char *MC_WeaponClassForItem( int iItem )
{
	int i = iItem - MC_ITEM_WEAPON_FIRST;
	if ( i < 0 || i >= ARRAYSIZE( s_WeaponClasses ) )
		return NULL;
	return s_WeaponClasses[i];
}

//-----------------------------------------------------------------------------
// Mining
//-----------------------------------------------------------------------------
bool MC_CanHarvest( int iBlock, int iHeldItem )
{
	const MCItemDef_t *pBlock = MC_GetItem( iBlock );
	if ( pBlock->iRequiredTier <= 0 )
		return true;

	const MCItemDef_t *pTool = MC_GetItem( iHeldItem );
	return pTool->kind == MC_KIND_TOOL && pTool->eToolType == pBlock->eBestTool && pTool->iTier >= pBlock->iRequiredTier;
}

float MC_GetBreakSeconds( int iBlock, int iHeldItem, bool bOnGround, bool bUnderwater )
{
	const MCItemDef_t *pBlock = MC_GetItem( iBlock );
	if ( pBlock->flHardness <= 0.0f )
		return 0.0f;

	const MCItemDef_t *pTool = MC_GetItem( iHeldItem );

	float flSpeed = 1.0f;
	if ( pTool->kind == MC_KIND_TOOL )
	{
		if ( pBlock->eBestTool != MC_TOOL_NONE && pTool->eToolType == pBlock->eBestTool )
			flSpeed = pTool->flMiningSpeed;
		else if ( pTool->eToolType == MC_TOOL_SWORD && iBlock == MC_ITEM_OAK_LEAVES )
			flSpeed = 1.5f;
	}

	if ( !bOnGround )
		flSpeed /= 5.0f;
	if ( bUnderwater )
		flSpeed /= 5.0f;

	float flDamagePerTick = flSpeed / pBlock->flHardness / ( MC_CanHarvest( iBlock, iHeldItem ) ? 30.0f : 100.0f );
	if ( flDamagePerTick >= 1.0f )
		return 0.0f;

	int iTicks = (int)ceilf( 1.0f / flDamagePerTick );
	return iTicks * 0.05f;
}

//-----------------------------------------------------------------------------
// Creative inventory contents
//-----------------------------------------------------------------------------
int MC_GetCreativeItemCount( void )
{
	return ARRAYSIZE( s_Items );
}

int MC_GetCreativeItem( int iIndex )
{
	if ( iIndex < 0 || iIndex >= ARRAYSIZE( s_Items ) )
		return MC_ITEM_NONE;
	return s_Items[iIndex].id;
}
