//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Item registry shared by client and server: blocks, tools and the
//			HL2 weapons that live in the Minecraft inventory.
//
//			Block hardness, tool speeds, tiers, damage and durability follow
//			Minecraft Java Edition's published values.
//
//=============================================================================//

#ifndef MC_ITEMS_H
#define MC_ITEMS_H
#ifdef _WIN32
#pragma once
#endif

#define MC_INV_SLOTS			36		// 0-8 hotbar, 9-35 main inventory
#define MC_BLOCK_SIZE			40.0f	// one block in Hammer units
#define MC_BLOCK_HALF			20.0f

enum MCItemKind_t
{
	MC_KIND_NONE = 0,
	MC_KIND_BLOCK,
	MC_KIND_TOOL,
	MC_KIND_WEAPON,		// an HL2 weapon the player is carrying
};

enum MCToolType_t
{
	MC_TOOL_NONE = 0,
	MC_TOOL_PICKAXE,
	MC_TOOL_AXE,
	MC_TOOL_SHOVEL,
	MC_TOOL_SWORD,
};

// Item ids. These are saved and networked; only append.
enum MCItemId_t
{
	MC_ITEM_NONE = 0,

	// Blocks
	MC_ITEM_GRASS_BLOCK = 1,
	MC_ITEM_DIRT,
	MC_ITEM_STONE,
	MC_ITEM_COBBLESTONE,
	MC_ITEM_OAK_PLANKS,
	MC_ITEM_OAK_LOG,
	MC_ITEM_SAND,
	MC_ITEM_GRAVEL,
	MC_ITEM_GLASS,
	MC_ITEM_BRICKS,
	MC_ITEM_STONE_BRICKS,
	MC_ITEM_OAK_LEAVES,
	MC_ITEM_BLOCK_LAST = MC_ITEM_OAK_LEAVES,

	// Tools (4 tiers x 4 types)
	MC_ITEM_WOODEN_PICKAXE = 20,
	MC_ITEM_WOODEN_AXE,
	MC_ITEM_WOODEN_SHOVEL,
	MC_ITEM_WOODEN_SWORD,
	MC_ITEM_STONE_PICKAXE,
	MC_ITEM_STONE_AXE,
	MC_ITEM_STONE_SHOVEL,
	MC_ITEM_STONE_SWORD,
	MC_ITEM_IRON_PICKAXE,
	MC_ITEM_IRON_AXE,
	MC_ITEM_IRON_SHOVEL,
	MC_ITEM_IRON_SWORD,
	MC_ITEM_DIAMOND_PICKAXE,
	MC_ITEM_DIAMOND_AXE,
	MC_ITEM_DIAMOND_SHOVEL,
	MC_ITEM_DIAMOND_SWORD,
	MC_ITEM_TOOL_LAST = MC_ITEM_DIAMOND_SWORD,

	// HL2 weapons: MC_ITEM_WEAPON_FIRST + index into the weapon table
	MC_ITEM_WEAPON_FIRST = 100,
	MC_ITEM_WEAPON_LAST = 127,

	MC_ITEM_COUNT = 128
};

struct MCItemDef_t
{
	int				id;
	MCItemKind_t	kind;
	const char		*pszName;		// internal / texture name, e.g. "oak_planks"
	const char		*pszDisplay;	// shown to the player

	// Blocks
	const char		*pszTexTop;		// sprite names produced by mc_extract_textures.py
	const char		*pszTexSide;
	const char		*pszTexBottom;
	float			flHardness;
	MCToolType_t	eBestTool;
	int				iRequiredTier;	// 0 = drops with anything, 1 = needs any pickaxe...
	int				iDrop;			// what breaking it gives (MC_ITEM_NONE for nothing)
	const char		*pszSurface;	// HL2 surface property for sounds
	bool			bCutout;		// alpha-tested (glass, leaves)

	// Tools
	MCToolType_t	eToolType;
	int				iTier;			// 1 wood, 2 stone, 3 iron, 4 diamond
	float			flMiningSpeed;
	float			flAttackDamage;	// Minecraft health points
	float			flAttackSpeed;	// attacks per second
	int				iMaxDurability;
};

const MCItemDef_t	*MC_GetItem( int iItem );		// never NULL; MC_ITEM_NONE def for unknown ids
int					MC_GetMaxStack( int iItem );
bool				MC_IsBlock( int iItem );
bool				MC_IsTool( int iItem );
bool				MC_IsWeaponItem( int iItem );
int					MC_FindItemByName( const char *pszName );	// MC_ITEM_NONE if not found

// HL2 weapons that can sit in the inventory
int					MC_WeaponItemForClass( const char *pszClassname );	// MC_ITEM_NONE if not tracked
const char			*MC_WeaponClassForItem( int iItem );					// NULL if not a weapon item

// Mining: seconds to break a block with the given held item (Minecraft's formula)
float				MC_GetBreakSeconds( int iBlock, int iHeldItem, bool bOnGround, bool bUnderwater );
bool				MC_CanHarvest( int iBlock, int iHeldItem );

// Items listed in the Creative inventory, in display order
int					MC_GetCreativeItemCount( void );
int					MC_GetCreativeItem( int iIndex );

#endif // MC_ITEMS_H
