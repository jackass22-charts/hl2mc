//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Constants, replicated convars and helpers shared by client and server.
//
// Everything here is an independent re-implementation of publicly documented
// Minecraft (Java Edition) gameplay rules. No Mojang code is used.
//
//=============================================================================//

#ifndef MC_SHARED_H
#define MC_SHARED_H
#ifdef _WIN32
#pragma once
#endif

#include "convar.h"

//-----------------------------------------------------------------------------
// Scale. 1 block = 40 Hammer units, so the HL2 player hull (72 units tall)
// is 1.8 blocks, the same height as a Minecraft player.
//-----------------------------------------------------------------------------
#define MC_UNITS_PER_BLOCK		40.0f
#define MC_TICK_INTERVAL		0.05f		// Minecraft runs 20 game ticks per second

// Health: HL2 keeps its 100 point scale so weapon balance is untouched.
// 100 HL2 health = 20 Minecraft health points = 10 hearts.
#define MC_HL2HP_PER_MCHP		5.0f

#define MC_MAX_FOOD				20
#define MC_MAX_SATURATION		20.0f
#define MC_MAX_EXHAUSTION		40.0f
#define MC_START_SATURATION		5.0f
#define MC_SPRINT_MIN_FOOD		6			// sprinting needs food > 6 (more than 3 shanks)
#define MC_MAX_AIR				300			// 15 seconds of air in ticks
#define MC_HOTBAR_SLOTS			9

// Exhaustion costs (per Minecraft Java rules)
#define MC_EXHAUST_SPRINT_PER_BLOCK		0.1f
#define MC_EXHAUST_SWIM_PER_BLOCK		0.01f
#define MC_EXHAUST_JUMP					0.05f
#define MC_EXHAUST_SPRINT_JUMP			0.2f
#define MC_EXHAUST_ATTACK				0.1f
#define MC_EXHAUST_DAMAGE				0.1f
#define MC_EXHAUST_REGEN				6.0f

//-----------------------------------------------------------------------------
// Replicated settings (movement code runs on both client and server, so these
// must match on both sides for prediction to work).
//-----------------------------------------------------------------------------
extern ConVar mc_enable;
extern ConVar mc_jump_height;
extern ConVar mc_sneak_edge_guard;
extern ConVar mc_sprintjump_boost;
extern ConVar mc_sprintjump_speed;
extern ConVar mc_inventory;

inline bool MC_IsEnabled()
{
	return mc_enable.GetBool();
}

//-----------------------------------------------------------------------------
// Experience. Level curve from Minecraft Java 1.8+.
//-----------------------------------------------------------------------------
inline int MC_XPToNextLevel( int iLevel )
{
	if ( iLevel >= 30 )
		return 112 + ( iLevel - 30 ) * 9;
	if ( iLevel >= 15 )
		return 37 + ( iLevel - 15 ) * 5;
	return 7 + iLevel * 2;
}

inline void MC_XPLevelFromTotal( int iTotalXP, int &iLevel, float &flProgress )
{
	iLevel = 0;
	int iRemaining = iTotalXP < 0 ? 0 : iTotalXP;
	while ( iLevel < 21863 && iRemaining >= MC_XPToNextLevel( iLevel ) )
	{
		iRemaining -= MC_XPToNextLevel( iLevel );
		iLevel++;
	}
	flProgress = (float)iRemaining / (float)MC_XPToNextLevel( iLevel );
}

#endif // MC_SHARED_H
