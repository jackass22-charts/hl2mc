//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Server entities: placed blocks (mc_block) and dropped items (mc_item).
//
//=============================================================================//

#ifndef MC_ENTITIES_H
#define MC_ENTITIES_H
#ifdef _WIN32
#pragma once
#endif

class CBaseEntity;
class CBasePlayer;

// Blocks
CBaseEntity	*MC_SpawnBlock( const Vector &vecCenter, int iItem );
int			MC_GetBlockItem( CBaseEntity *pEntity );		// MC_ITEM_NONE if not a block
bool		MC_IsBlockEntity( CBaseEntity *pEntity );
int			MC_CountBlocks( void );

// Dropped items
CBaseEntity	*MC_SpawnDroppedItem( const Vector &vecOrigin, const Vector &vecVelocity, int iItem, int iCount, int iDamage, float flPickupDelay );

// Called from CBreakableProp::Break (props.cpp)
void		MC_OnPropBroken( CBaseEntity *pProp, CBaseEntity *pBreaker );

#endif // MC_ENTITIES_H
