//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: The Minecraft inventory on the server: 36 slots (0-8 hotbar,
//			9-35 main), the stack held by the mouse while the inventory screen
//			is open, Minecraft's click rules, Creative mode, and keeping HL2's
//			weapons in the inventory so they live on the hotbar like items.
//
//=============================================================================//

#include "cbase.h"
#include "hl2_player.h"
#include "in_buttons.h"
#include "mc/mc_shared.h"
#include "mc/mc_items.h"
#include "mc/mc_entities.h"

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"


static inline bool MC_InvActive( void )
{
	return MC_IsEnabled() && mc_inventory.GetBool();
}

//-----------------------------------------------------------------------------
// Slot helpers
//-----------------------------------------------------------------------------
void CHL2_Player::MC_SetSlot( int iSlot, int iItem, int iCount, int iDamage )
{
	if ( iSlot < 0 || iSlot >= MC_INV_SLOTS )
		return;

	if ( iItem == MC_ITEM_NONE || iCount <= 0 )
	{
		iItem = MC_ITEM_NONE;
		iCount = 0;
		iDamage = 0;
	}
	m_HL2Local.m_iMCInvItem.Set( iSlot, iItem );
	m_HL2Local.m_iMCInvCount.Set( iSlot, iCount );
	m_HL2Local.m_iMCInvDamage.Set( iSlot, iDamage );
}

int CHL2_Player::MC_FindItemSlot( int iItem ) const
{
	for ( int i = 0; i < MC_INV_SLOTS; i++ )
	{
		if ( m_HL2Local.m_iMCInvItem[i] == iItem )
			return i;
	}
	return -1;
}

void CHL2_Player::MC_ClearInventory( void )
{
	for ( int i = 0; i < MC_INV_SLOTS; i++ )
	{
		// Weapons stay; the sync re-adds them anyway
		if ( !MC_IsWeaponItem( m_HL2Local.m_iMCInvItem[i] ) )
			MC_SetSlot( i, MC_ITEM_NONE, 0, 0 );
	}
	m_HL2Local.m_iMCCursorItem = 0;
	m_HL2Local.m_iMCCursorCount = 0;
	m_HL2Local.m_iMCCursorDamage = 0;
}

// Adds to existing stacks first, then empty slots (hotbar before main inventory, like Minecraft).
int CHL2_Player::MC_AddItem( int iItem, int iCount, int iDamage )
{
	const int iMax = MC_GetMaxStack( iItem );
	if ( iMax <= 0 || iCount <= 0 )
		return iCount;

	if ( iMax > 1 )
	{
		for ( int i = 0; i < MC_INV_SLOTS && iCount > 0; i++ )
		{
			if ( m_HL2Local.m_iMCInvItem[i] != iItem )
				continue;
			int iRoom = iMax - m_HL2Local.m_iMCInvCount[i];
			int iMove = MIN( iRoom, iCount );
			if ( iMove > 0 )
			{
				m_HL2Local.m_iMCInvCount.Set( i, m_HL2Local.m_iMCInvCount[i] + iMove );
				iCount -= iMove;
			}
		}
	}

	for ( int i = 0; i < MC_INV_SLOTS && iCount > 0; i++ )
	{
		if ( m_HL2Local.m_iMCInvItem[i] != MC_ITEM_NONE )
			continue;
		int iMove = MIN( iMax, iCount );
		MC_SetSlot( i, iItem, iMove, iDamage );
		iCount -= iMove;
	}

	return iCount;
}

//-----------------------------------------------------------------------------
// Hand weapon and HL2 weapon sync
//-----------------------------------------------------------------------------
void CHL2_Player::MC_EnsureHand( void )
{
	if ( !Weapon_OwnsThisType( "weapon_mc_hand" ) )
	{
		GiveNamedItem( "weapon_mc_hand" );
	}
}

bool CHL2_Player::MC_IsHandActive( void )
{
	CBaseCombatWeapon *pActive = GetActiveWeapon();
	return pActive == NULL || pActive->ClassMatches( "weapon_mc_hand" );
}

void CHL2_Player::MC_SyncWeapons( void )
{
	// 1. Weapon items for weapons we no longer carry disappear (HL2 scripts strip weapons sometimes)
	for ( int i = 0; i < MC_INV_SLOTS; i++ )
	{
		const char *pszClass = MC_WeaponClassForItem( m_HL2Local.m_iMCInvItem[i] );
		if ( pszClass && !Weapon_OwnsThisType( pszClass ) )
			MC_SetSlot( i, MC_ITEM_NONE, 0, 0 );
	}
	{
		const char *pszClass = MC_WeaponClassForItem( m_HL2Local.m_iMCCursorItem );
		if ( pszClass && !Weapon_OwnsThisType( pszClass ) )
		{
			m_HL2Local.m_iMCCursorItem = 0;
			m_HL2Local.m_iMCCursorCount = 0;
		}
	}

	// 2. New weapons get a slot: first free hotbar slot, otherwise the main inventory
	for ( int i = 0; i < WeaponCount(); i++ )
	{
		CBaseCombatWeapon *pWeapon = GetWeapon( i );
		if ( !pWeapon )
			continue;
		int iItem = MC_WeaponItemForClass( pWeapon->GetClassname() );
		if ( iItem == MC_ITEM_NONE )
			continue;
		if ( MC_FindItemSlot( iItem ) >= 0 || m_HL2Local.m_iMCCursorItem == iItem )
			continue;
		MC_AddItem( iItem, 1, 0 );
	}

	// 3. If HL2 switched weapons on its own (pickup, script, lastinv), follow it
	CBaseCombatWeapon *pActive = GetActiveWeapon();
	if ( pActive && !pActive->ClassMatches( "weapon_mc_hand" ) )
	{
		int iItem = MC_WeaponItemForClass( pActive->GetClassname() );
		int iSlot = iItem != MC_ITEM_NONE ? MC_FindItemSlot( iItem ) : -1;
		if ( iSlot >= 0 && iSlot < 9 )
		{
			m_HL2Local.m_iMCSelected = iSlot;
		}
		else if ( iSlot >= 9 )
		{
			// Bring it to the hotbar by swapping with the selected slot
			int iSel = m_HL2Local.m_iMCSelected;
			int a = m_HL2Local.m_iMCInvItem[iSel], b = m_HL2Local.m_iMCInvCount[iSel], c = m_HL2Local.m_iMCInvDamage[iSel];
			MC_SetSlot( iSel, iItem, 1, 0 );
			MC_SetSlot( iSlot, a, b, c );
		}
		m_iMCAppliedItem = MC_GetHeldItem();
	}
}

// Make the active weapon match the selected hotbar slot
void CHL2_Player::MC_ApplySelection( bool bForce )
{
	int iHeld = MC_GetHeldItem();
	if ( !bForce && iHeld == m_iMCAppliedItem )
		return;

	const char *pszClass = MC_WeaponClassForItem( iHeld );
	if ( pszClass )
	{
		CBaseCombatWeapon *pWeapon = Weapon_OwnsThisType( pszClass );
		if ( pWeapon && pWeapon != GetActiveWeapon() )
		{
			if ( !pWeapon->CanBeSelected() || !Weapon_Switch( pWeapon ) )
			{
				EmitSound( "Player.DenyWeaponSelection" );
			}
		}
	}
	else
	{
		CBaseCombatWeapon *pHand = Weapon_OwnsThisType( "weapon_mc_hand" );
		if ( pHand && pHand != GetActiveWeapon() )
			Weapon_Switch( pHand );
	}

	MC_StopMining();
	m_iMCAppliedItem = iHeld;
}

void CHL2_Player::MC_SelectSlot( int iSlot )
{
	if ( iSlot < 0 || iSlot > 8 )
		return;
	m_HL2Local.m_iMCSelected = iSlot;
	MC_ApplySelection( true );
}

void CHL2_Player::MC_InventoryTick( void )
{
	if ( !MC_InvActive() || !IsAlive() )
		return;

	MC_EnsureHand();
	MC_SyncWeapons();
	MC_ApplySelection( false );
}

//-----------------------------------------------------------------------------
// Inventory screen clicks (Minecraft rules)
//   left:  pick up / put down / merge / swap
//   right: pick up half / put down one
//   shift: move the stack between hotbar and main inventory
//-----------------------------------------------------------------------------
void CHL2_Player::MC_InventoryClick( int iSlot, int iButton, bool bShift )
{
	if ( iSlot < 0 || iSlot >= MC_INV_SLOTS )
		return;

	int iItem = m_HL2Local.m_iMCInvItem[iSlot];
	int iCount = m_HL2Local.m_iMCInvCount[iSlot];
	int iDamage = m_HL2Local.m_iMCInvDamage[iSlot];

	int cItem = m_HL2Local.m_iMCCursorItem;
	int cCount = m_HL2Local.m_iMCCursorCount;
	int cDamage = m_HL2Local.m_iMCCursorDamage;

	if ( bShift )
	{
		if ( iItem == MC_ITEM_NONE )
			return;

		// Hotbar -> main inventory, or main -> hotbar
		int iStart = iSlot < 9 ? 9 : 0;
		int iEnd = iSlot < 9 ? MC_INV_SLOTS : 9;
		int iMax = MC_GetMaxStack( iItem );

		for ( int i = iStart; i < iEnd && iCount > 0 && iMax > 1; i++ )
		{
			if ( m_HL2Local.m_iMCInvItem[i] != iItem )
				continue;
			int iMove = MIN( iMax - m_HL2Local.m_iMCInvCount[i], iCount );
			if ( iMove > 0 )
			{
				m_HL2Local.m_iMCInvCount.Set( i, m_HL2Local.m_iMCInvCount[i] + iMove );
				iCount -= iMove;
			}
		}
		for ( int i = iStart; i < iEnd && iCount > 0; i++ )
		{
			if ( m_HL2Local.m_iMCInvItem[i] != MC_ITEM_NONE )
				continue;
			MC_SetSlot( i, iItem, iCount, iDamage );
			iCount = 0;
		}
		MC_SetSlot( iSlot, iItem, iCount, iDamage );
		return;
	}

	const int iMaxStack = MC_GetMaxStack( iItem != MC_ITEM_NONE ? iItem : cItem );

	if ( cItem == MC_ITEM_NONE )
	{
		if ( iItem == MC_ITEM_NONE )
			return;

		// Pick up all (left) or half rounded up (right)
		int iTake = ( iButton == 1 ) ? ( iCount + 1 ) / 2 : iCount;
		m_HL2Local.m_iMCCursorItem = iItem;
		m_HL2Local.m_iMCCursorCount = iTake;
		m_HL2Local.m_iMCCursorDamage = iDamage;
		MC_SetSlot( iSlot, iItem, iCount - iTake, iDamage );
		return;
	}

	if ( iItem == MC_ITEM_NONE || ( iItem == cItem && iMaxStack > 1 ) )
	{
		// Put down all (left) or one (right), up to the stack limit
		int iRoom = iMaxStack - ( iItem == MC_ITEM_NONE ? 0 : iCount );
		int iPut = MIN( iRoom, ( iButton == 1 ) ? 1 : cCount );
		if ( iPut <= 0 )
			return;
		MC_SetSlot( iSlot, cItem, ( iItem == MC_ITEM_NONE ? 0 : iCount ) + iPut, cDamage );
		cCount -= iPut;
		m_HL2Local.m_iMCCursorCount = cCount;
		if ( cCount <= 0 )
		{
			m_HL2Local.m_iMCCursorItem = 0;
			m_HL2Local.m_iMCCursorDamage = 0;
		}
		return;
	}

	// Different items: swap
	MC_SetSlot( iSlot, cItem, cCount, cDamage );
	m_HL2Local.m_iMCCursorItem = iItem;
	m_HL2Local.m_iMCCursorCount = iCount;
	m_HL2Local.m_iMCCursorDamage = iDamage;
}

// Creative palette: take a full stack (left), one (right), or straight into the inventory (shift).
// Clicking the palette while holding something deletes it, like Minecraft.
void CHL2_Player::MC_CreativePick( int iItem, int iButton, bool bShift )
{
	if ( !MC_IsCreative() )
		return;

	if ( m_HL2Local.m_iMCCursorItem != MC_ITEM_NONE && !MC_IsWeaponItem( m_HL2Local.m_iMCCursorItem ) )
	{
		m_HL2Local.m_iMCCursorItem = 0;
		m_HL2Local.m_iMCCursorCount = 0;
		m_HL2Local.m_iMCCursorDamage = 0;
		return;
	}

	if ( MC_GetItem( iItem )->kind == MC_KIND_NONE || MC_IsWeaponItem( iItem ) )
		return;

	int iCount = ( iButton == 1 ) ? 1 : MC_GetMaxStack( iItem );

	if ( bShift )
	{
		MC_AddItem( iItem, iCount, 0 );
		return;
	}

	if ( m_HL2Local.m_iMCCursorItem == MC_ITEM_NONE )
	{
		m_HL2Local.m_iMCCursorItem = iItem;
		m_HL2Local.m_iMCCursorCount = iCount;
		m_HL2Local.m_iMCCursorDamage = 0;
	}
}

void CHL2_Player::MC_DropItemEntity( int iItem, int iCount, int iDamage, bool bThrow )
{
	if ( iItem == MC_ITEM_NONE || iCount <= 0 )
		return;

	Vector vecForward;
	EyeVectors( &vecForward );
	Vector vecOrigin = EyePosition() - Vector( 0, 0, 12 ) + vecForward * 12.0f;
	Vector vecVel = bThrow ? vecForward * 200.0f + Vector( 0, 0, 60 ) : vec3_origin;

	// Weapons drop as the real HL2 weapon
	const char *pszClass = MC_WeaponClassForItem( iItem );
	if ( pszClass )
	{
		CBaseCombatWeapon *pWeapon = Weapon_OwnsThisType( pszClass );
		if ( pWeapon && !pWeapon->ClassMatches( "weapon_physcannon" ) )
			Weapon_Drop( pWeapon, NULL, &vecVel );
		return;
	}

	MC_SpawnDroppedItem( vecOrigin, vecVel, iItem, iCount, iDamage, 2.0f );
}

// Clicked outside the inventory window: drop the held stack (left) or one item (right)
void CHL2_Player::MC_DropCursor( int iButton )
{
	int cItem = m_HL2Local.m_iMCCursorItem;
	int cCount = m_HL2Local.m_iMCCursorCount;
	if ( cItem == MC_ITEM_NONE || cCount <= 0 )
		return;

	int iDrop = ( iButton == 1 ) ? 1 : cCount;
	MC_DropItemEntity( cItem, iDrop, m_HL2Local.m_iMCCursorDamage, true );

	cCount -= iDrop;
	m_HL2Local.m_iMCCursorCount = cCount;
	if ( cCount <= 0 || MC_IsWeaponItem( cItem ) )
	{
		m_HL2Local.m_iMCCursorItem = 0;
		m_HL2Local.m_iMCCursorCount = 0;
		m_HL2Local.m_iMCCursorDamage = 0;
	}
}

// Closing the screen puts the held stack back, dropping whatever doesn't fit
void CHL2_Player::MC_CloseInventory( void )
{
	int cItem = m_HL2Local.m_iMCCursorItem;
	int cCount = m_HL2Local.m_iMCCursorCount;
	int cDamage = m_HL2Local.m_iMCCursorDamage;
	m_HL2Local.m_iMCCursorItem = 0;
	m_HL2Local.m_iMCCursorCount = 0;
	m_HL2Local.m_iMCCursorDamage = 0;

	if ( cItem == MC_ITEM_NONE )
		return;

	int iLeft = MC_AddItem( cItem, cCount, cDamage );
	if ( iLeft > 0 )
		MC_DropItemEntity( cItem, iLeft, cDamage, true );
}

//-----------------------------------------------------------------------------
// Game mode
//-----------------------------------------------------------------------------
void CHL2_Player::MC_SetGameMode( int iMode )
{
	iMode = clamp( iMode, 0, 1 );
	m_HL2Local.m_iMCGameMode = iMode;

	if ( iMode == 1 )
	{
		AddFlag( FL_GODMODE );
		SetHealth( MAX( GetHealth(), 100 ) );
		m_HL2Local.m_iMCFood = MC_MAX_FOOD;
		m_HL2Local.m_flMCSaturation = MC_START_SATURATION;
		ClientPrint( this, HUD_PRINTTALK, "Set own game mode to Creative Mode" );
	}
	else
	{
		RemoveFlag( FL_GODMODE );
		m_HL2Local.m_bMCFlying = false;
		ClientPrint( this, HUD_PRINTTALK, "Set own game mode to Survival Mode" );
	}
	MC_StopMining();
}

//-----------------------------------------------------------------------------
// Console commands. The client sends these; in singleplayer
// UTIL_GetCommandClient() is the local player.
//-----------------------------------------------------------------------------
static CHL2_Player *MC_CommandPlayer( void )
{
	if ( !MC_InvActive() )
		return NULL;
	CHL2_Player *pPlayer = dynamic_cast< CHL2_Player * >( UTIL_GetCommandClient() );
	if ( !pPlayer || !pPlayer->IsAlive() )
		return NULL;
	return pPlayer;
}

CON_COMMAND( mc_select, "mc_select <0-8>: select a hotbar slot" )
{
	CHL2_Player *pPlayer = MC_CommandPlayer();
	if ( pPlayer && args.ArgC() > 1 )
		pPlayer->MC_SelectSlot( atoi( args[1] ) );
}

CON_COMMAND( mc_inv_click, "mc_inv_click <slot> <button 0/1> <shift 0/1>" )
{
	CHL2_Player *pPlayer = MC_CommandPlayer();
	if ( pPlayer && args.ArgC() > 3 )
		pPlayer->MC_InventoryClick( atoi( args[1] ), atoi( args[2] ), atoi( args[3] ) != 0 );
}

CON_COMMAND( mc_inv_pick, "mc_inv_pick <item> <button 0/1> <shift 0/1> (Creative)" )
{
	CHL2_Player *pPlayer = MC_CommandPlayer();
	if ( pPlayer && args.ArgC() > 3 )
		pPlayer->MC_CreativePick( atoi( args[1] ), atoi( args[2] ), atoi( args[3] ) != 0 );
}

CON_COMMAND( mc_inv_drop, "mc_inv_drop <button 0/1>: drop the held stack" )
{
	CHL2_Player *pPlayer = MC_CommandPlayer();
	if ( pPlayer )
		pPlayer->MC_DropCursor( args.ArgC() > 1 ? atoi( args[1] ) : 0 );
}

CON_COMMAND( mc_inv_close, "Close the inventory (returns the held stack)" )
{
	CHL2_Player *pPlayer = MC_CommandPlayer();
	if ( pPlayer )
		pPlayer->MC_CloseInventory();
}

CON_COMMAND( mc_drop_held, "Drop one of the held item (Q in Minecraft)" )
{
	CHL2_Player *pPlayer = MC_CommandPlayer();
	if ( !pPlayer )
		return;
	int iSlot = pPlayer->MC_GetSelectedSlot();
	int iItem = pPlayer->MC_GetSlotItem( iSlot );
	if ( iItem == MC_ITEM_NONE || MC_IsWeaponItem( iItem ) )
		return;
	int iCount = pPlayer->MC_GetSlotCount( iSlot );
	bool bAll = args.ArgC() > 1 && atoi( args[1] ) != 0;
	int iDrop = bAll ? iCount : 1;
	pPlayer->MC_DropItemEntity( iItem, iDrop, 0, true );
	pPlayer->MC_SetSlot( iSlot, iItem, iCount - iDrop, 0 );
}

static void MC_GameModeCommand( const CCommand &args )
{
	CHL2_Player *pPlayer = MC_CommandPlayer();
	if ( !pPlayer )
		return;

	if ( args.ArgC() < 2 )
	{
		Msg( "Usage: gamemode <survival|creative>  (current: %s)\n", pPlayer->MC_IsCreative() ? "creative" : "survival" );
		return;
	}

	const char *psz = args[1];
	int iMode = -1;
	if ( !Q_stricmp( psz, "survival" ) || !Q_stricmp( psz, "s" ) || !Q_stricmp( psz, "0" ) )
		iMode = 0;
	else if ( !Q_stricmp( psz, "creative" ) || !Q_stricmp( psz, "c" ) || !Q_stricmp( psz, "1" ) )
		iMode = 1;

	if ( iMode < 0 )
	{
		Msg( "Unknown game mode '%s'. Use survival or creative.\n", psz );
		return;
	}
	pPlayer->MC_SetGameMode( iMode );
}

static ConCommand mc_gamemode_cmd( "gamemode", MC_GameModeCommand, "gamemode <survival|creative>: switch Minecraft game mode" );
static ConCommand mc_gamemode_alias( "mc_gamemode", MC_GameModeCommand, "mc_gamemode <survival|creative>: switch Minecraft game mode" );

CON_COMMAND( mc_give, "mc_give <item> [count]  e.g. mc_give oak_planks 64, mc_give diamond_pickaxe (Creative, or sv_cheats 1)" )
{
	CHL2_Player *pPlayer = MC_CommandPlayer();
	if ( !pPlayer )
		return;

	static ConVarRef sv_cheats( "sv_cheats" );
	if ( !pPlayer->MC_IsCreative() && !sv_cheats.GetBool() )
	{
		Msg( "mc_give needs Creative mode or sv_cheats 1.\n" );
		return;
	}

	if ( args.ArgC() < 2 )
	{
		Msg( "Items:" );
		for ( int i = 0; i < MC_GetCreativeItemCount(); i++ )
			Msg( " %s", MC_GetItem( MC_GetCreativeItem( i ) )->pszName );
		Msg( "\n" );
		return;
	}

	int iItem = MC_FindItemByName( args[1] );
	if ( iItem == MC_ITEM_NONE )
	{
		Msg( "Unknown item '%s'. Type mc_give with no arguments for the list.\n", args[1] );
		return;
	}

	int iCount = args.ArgC() > 2 ? MAX( atoi( args[2] ), 1 ) : MC_GetMaxStack( iItem );
	int iLeft = pPlayer->MC_AddItem( iItem, iCount, 0 );
	if ( iLeft > 0 )
		pPlayer->MC_DropItemEntity( iItem, iLeft, 0, false );
}

CON_COMMAND( mc_clear, "Clear the Minecraft inventory (keeps HL2 weapons)" )
{
	CHL2_Player *pPlayer = MC_CommandPlayer();
	if ( pPlayer )
		pPlayer->MC_ClearInventory();
}
