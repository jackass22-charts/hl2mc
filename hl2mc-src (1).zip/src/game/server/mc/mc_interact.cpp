//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: What the hand does: left click hits things and mines blocks,
//			right click places the held block. Mining time, tool tiers,
//			attack cooldown and tool wear follow Minecraft Java Edition.
//
//=============================================================================//

#include "cbase.h"
#include "hl2_player.h"
#include "in_buttons.h"
#include "physics_shared.h"
#include "mc/mc_shared.h"
#include "mc/mc_items.h"
#include "mc/mc_entities.h"

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"


// Reach in units (Minecraft: 4.5 blocks for blocks in Survival, 5 in Creative; 3 for hitting entities)
#define MC_REACH_BLOCK_SURVIVAL		( 4.5f * MC_BLOCK_SIZE )
#define MC_REACH_BLOCK_CREATIVE		( 5.0f * MC_BLOCK_SIZE )
#define MC_REACH_ENTITY				( 3.0f * MC_BLOCK_SIZE )
#define MC_EXHAUST_BREAK_BLOCK		0.005f

//-----------------------------------------------------------------------------
// Ignore the player and dropped items when aiming
//-----------------------------------------------------------------------------
class CMCAimFilter : public CTraceFilterSimple
{
public:
	CMCAimFilter( CBaseEntity *pPlayer ) : CTraceFilterSimple( pPlayer, COLLISION_GROUP_NONE ) {}

	virtual bool ShouldHitEntity( IHandleEntity *pHandleEntity, int contentsMask )
	{
		CBaseEntity *pEnt = EntityFromEntityHandle( pHandleEntity );
		if ( pEnt && pEnt->ClassMatches( "mc_item" ) )
			return false;
		return CTraceFilterSimple::ShouldHitEntity( pHandleEntity, contentsMask );
	}
};

static void MC_AimTrace( CBasePlayer *pPlayer, float flReach, trace_t &tr )
{
	Vector vecForward;
	pPlayer->EyeVectors( &vecForward );
	Vector vecStart = pPlayer->EyePosition();
	CMCAimFilter filter( pPlayer );
	UTIL_TraceLine( vecStart, vecStart + vecForward * flReach, MASK_SHOT | CONTENTS_GRATE, &filter, &tr );
}

//-----------------------------------------------------------------------------
// Sounds from the HL2 surface the block is made of
//-----------------------------------------------------------------------------
enum MCSurfaceSound_t { MC_SOUND_HIT, MC_SOUND_BREAK, MC_SOUND_PLACE };

static void MC_PlayBlockSound( const Vector &vecPos, int iBlock, MCSurfaceSound_t eWhich )
{
	const char *pszSurface = MC_GetItem( iBlock )->pszSurface;
	int iSurface = physprops->GetSurfaceIndex( pszSurface ? pszSurface : "default" );
	if ( iSurface < 0 )
		iSurface = physprops->GetSurfaceIndex( "default" );

	const surfacedata_t *pData = physprops->GetSurfaceData( iSurface );
	if ( !pData )
		return;

	unsigned short hSound = 0;
	switch ( eWhich )
	{
	case MC_SOUND_HIT:		hSound = pData->sounds.impactSoft; break;
	case MC_SOUND_BREAK:	hSound = pData->sounds.breakSound ? pData->sounds.breakSound : pData->sounds.impactHard; break;
	case MC_SOUND_PLACE:	hSound = pData->sounds.impactHard; break;
	}

	const char *pszSound = physprops->GetString( hSound );
	if ( !pszSound || !pszSound[0] )
		return;

	CPASAttenuationFilter filter( vecPos );
	CBaseEntity::EmitSound( filter, 0, pszSound, &vecPos );
}

//-----------------------------------------------------------------------------
// Tool wear
//-----------------------------------------------------------------------------
void CHL2_Player::MC_DamageHeldTool( int iAmount )
{
	if ( MC_IsCreative() )
		return;

	int iSlot = m_HL2Local.m_iMCSelected;
	int iItem = m_HL2Local.m_iMCInvItem[iSlot];
	const MCItemDef_t *pDef = MC_GetItem( iItem );
	if ( pDef->kind != MC_KIND_TOOL || pDef->iMaxDurability <= 0 )
		return;

	int iDamage = m_HL2Local.m_iMCInvDamage[iSlot] + iAmount;
	if ( iDamage >= pDef->iMaxDurability )
	{
		MC_SetSlot( iSlot, MC_ITEM_NONE, 0, 0 );
		EmitSound( "Weapon_Crowbar.Melee_HitWorld" );
	}
	else
	{
		m_HL2Local.m_iMCInvDamage.Set( iSlot, iDamage );
	}
}

//-----------------------------------------------------------------------------
// Melee: fist or tool, with the 1.9+ attack cooldown
//-----------------------------------------------------------------------------
bool CHL2_Player::MC_TryMeleeAttack( void )
{
	trace_t tr;
	MC_AimTrace( this, MC_IsCreative() ? MC_REACH_BLOCK_CREATIVE : MC_REACH_ENTITY, tr );

	CBaseEntity *pTarget = tr.m_pEnt;
	if ( tr.fraction >= 1.0f || !pTarget || pTarget->IsWorld() || MC_IsBlockEntity( pTarget ) )
		return false;
	if ( pTarget->m_takedamage == DAMAGE_NO )
		return false;

	// Entities are only reachable within 3 blocks in Survival
	if ( !MC_IsCreative() && ( tr.endpos - tr.startpos ).Length() > MC_REACH_ENTITY )
		return false;

	const MCItemDef_t *pTool = MC_GetItem( MC_GetHeldItem() );
	float flDamage = 1.0f;			// fist
	float flAttackSpeed = 4.0f;
	if ( pTool->kind == MC_KIND_TOOL )
	{
		flDamage = pTool->flAttackDamage;
		flAttackSpeed = pTool->flAttackSpeed;
	}

	// Attacking before the cooldown finishes does less damage
	float flProgress = clamp( ( gpGlobals->curtime - m_flMCLastAttackTime ) * flAttackSpeed, 0.0f, 1.0f );
	flDamage *= 0.2f + 0.8f * flProgress * flProgress;
	m_flMCLastAttackTime = gpGlobals->curtime;

	Vector vecForward;
	EyeVectors( &vecForward );

	CTakeDamageInfo info( this, this, flDamage * MC_HL2HP_PER_MCHP, DMG_CLUB );
	CalculateMeleeDamageForce( &info, vecForward, tr.endpos );
	ClearMultiDamage();
	pTarget->DispatchTraceAttack( info, vecForward, &tr );
	ApplyMultiDamage();

	EmitSound( "Weapon_Crowbar.Melee_Hit" );
	MC_Swing();

	if ( pTool->kind == MC_KIND_TOOL )
		MC_DamageHeldTool( pTool->eToolType == MC_TOOL_SWORD ? 1 : 2 );

	return true;
}

//-----------------------------------------------------------------------------
// Mining
//-----------------------------------------------------------------------------
void CHL2_Player::MC_StopMining( void )
{
	m_HL2Local.m_hMCBreakTarget.Set( NULL );
	m_HL2Local.m_flMCBreakProgress = 0.0f;
}

void CHL2_Player::MC_UpdateMining( bool bHeld )
{
	if ( !bHeld || gpGlobals->curtime < m_flMCNextBreakTime )
	{
		if ( !bHeld )
			MC_StopMining();
		return;
	}

	trace_t tr;
	MC_AimTrace( this, MC_IsCreative() ? MC_REACH_BLOCK_CREATIVE : MC_REACH_BLOCK_SURVIVAL, tr );
	CBaseEntity *pBlock = tr.m_pEnt;
	if ( tr.fraction >= 1.0f || !MC_IsBlockEntity( pBlock ) )
	{
		MC_StopMining();
		return;
	}

	if ( pBlock != m_HL2Local.m_hMCBreakTarget.Get() )
	{
		m_HL2Local.m_hMCBreakTarget.Set( pBlock );
		m_HL2Local.m_flMCBreakProgress = 0.0f;
		m_flMCMineStart = gpGlobals->curtime;
		m_flMCNextMineSound = 0.0f;
	}

	const int iBlock = MC_GetBlockItem( pBlock );
	const int iHeld = MC_GetHeldItem();

	float flSeconds = 0.0f;
	if ( !MC_IsCreative() )
	{
		bool bOnGround = ( GetFlags() & FL_ONGROUND ) != 0;
		bool bUnderwater = GetWaterLevel() == 3;
		flSeconds = MC_GetBreakSeconds( iBlock, iHeld, bOnGround, bUnderwater );
	}

	// Swing and hit sound every 4 ticks while digging
	if ( gpGlobals->curtime >= m_flMCNextMineSound )
	{
		MC_Swing();
		if ( flSeconds > 0.0f )
			MC_PlayBlockSound( pBlock->GetAbsOrigin(), iBlock, MC_SOUND_HIT );
		m_flMCNextMineSound = gpGlobals->curtime + 0.2f;
	}

	float flProgress = flSeconds > 0.0f ? ( gpGlobals->curtime - m_flMCMineStart ) / flSeconds : 1.0f;
	if ( flProgress < 1.0f )
	{
		m_HL2Local.m_flMCBreakProgress = flProgress;
		return;
	}

	// Broken
	Vector vecCenter = pBlock->GetAbsOrigin();
	MC_PlayBlockSound( vecCenter, iBlock, MC_SOUND_BREAK );

	if ( !MC_IsCreative() )
	{
		if ( MC_CanHarvest( iBlock, iHeld ) )
		{
			int iDrop = MC_GetItem( iBlock )->iDrop;
			if ( iDrop != MC_ITEM_NONE )
			{
				Vector vecVel( RandomFloat( -20, 20 ), RandomFloat( -20, 20 ), 60.0f );
				MC_SpawnDroppedItem( vecCenter, vecVel, iDrop, 1, 0, 0.3f );
			}
		}
		if ( MC_GetItem( iBlock )->flHardness > 0.0f )
			MC_DamageHeldTool( MC_GetItem( iHeld )->eToolType == MC_TOOL_SWORD ? 2 : 1 );
		MC_AddExhaustion( MC_EXHAUST_BREAK_BLOCK );
	}

	UTIL_Remove( pBlock );
	MC_StopMining();

	// Minecraft waits 5 ticks before the next block starts breaking
	m_flMCNextBreakTime = gpGlobals->curtime + 0.25f;
}

//-----------------------------------------------------------------------------
// Placing
//-----------------------------------------------------------------------------
static int MC_DominantAxis( const Vector &v )
{
	float ax = fabsf( v.x ), ay = fabsf( v.y ), az = fabsf( v.z );
	if ( az >= ax && az >= ay )
		return 2;
	return ax >= ay ? 0 : 1;
}

static float MC_SnapToGrid( float f )
{
	return floorf( f / MC_BLOCK_SIZE ) * MC_BLOCK_SIZE + MC_BLOCK_HALF;
}

bool CHL2_Player::MC_TryPlaceBlock( void )
{
	const int iHeld = MC_GetHeldItem();
	if ( !MC_IsBlock( iHeld ) )
		return false;

	trace_t tr;
	MC_AimTrace( this, MC_IsCreative() ? MC_REACH_BLOCK_CREATIVE : MC_REACH_BLOCK_SURVIVAL, tr );
	if ( tr.fraction >= 1.0f || tr.startsolid )
		return false;

	const int iAxis = MC_DominantAxis( tr.plane.normal );
	const float flSign = tr.plane.normal[iAxis] >= 0.0f ? 1.0f : -1.0f;

	Vector vecCenter;
	if ( MC_IsBlockEntity( tr.m_pEnt ) )
	{
		// Next to another block: exactly one block over on the face we clicked
		vecCenter = tr.m_pEnt->GetAbsOrigin();
		vecCenter[iAxis] += flSign * MC_BLOCK_SIZE;
	}
	else
	{
		// Against HL2 geometry: flush with the surface, snapped to the world grid sideways
		vecCenter = tr.endpos;
		vecCenter[iAxis] += flSign * MC_BLOCK_HALF;
		for ( int i = 0; i < 3; i++ )
		{
			if ( i != iAxis )
				vecCenter[i] = MC_SnapToGrid( vecCenter[i] );
		}
	}

	// The space must be free (shrunk slightly so blocks can sit flush on floors and walls)
	const Vector vecHalf( MC_BLOCK_HALF - 0.5f, MC_BLOCK_HALF - 0.5f, MC_BLOCK_HALF - 0.5f );
	trace_t trSpace;
	UTIL_TraceHull( vecCenter, vecCenter, -vecHalf, vecHalf, MASK_SOLID | CONTENTS_PLAYERCLIP | CONTENTS_MONSTERCLIP, NULL, COLLISION_GROUP_NONE, &trSpace );
	if ( trSpace.startsolid || trSpace.allsolid )
		return false;

	// No blocks inside the player or NPCs
	CBaseEntity *pList[32];
	int iCount = UTIL_EntitiesInBox( pList, ARRAYSIZE( pList ), vecCenter - vecHalf, vecCenter + vecHalf, FL_CLIENT | FL_NPC );
	for ( int i = 0; i < iCount; i++ )
	{
		if ( pList[i] && pList[i]->IsAlive() )
			return false;
	}

	if ( !MC_SpawnBlock( vecCenter, iHeld ) )
		return false;

	MC_PlayBlockSound( vecCenter, iHeld, MC_SOUND_PLACE );

	if ( !MC_IsCreative() )
	{
		int iSlot = m_HL2Local.m_iMCSelected;
		MC_SetSlot( iSlot, iHeld, m_HL2Local.m_iMCInvCount[iSlot] - 1, 0 );
	}
	return true;
}

//-----------------------------------------------------------------------------
// Called every command from MC_PostThink
//-----------------------------------------------------------------------------
void CHL2_Player::MC_HandThink( void )
{
	if ( !MC_IsEnabled() || !mc_inventory.GetBool() || !IsAlive() )
		return;

	if ( !MC_IsHandActive() || IsInAVehicle() || GetUseEntity() )
	{
		MC_StopMining();
		return;
	}

	const bool bAttackPressed = ( m_afButtonPressed & IN_ATTACK ) != 0;
	const bool bAttackHeld = ( m_nButtons & IN_ATTACK ) != 0;
	const bool bUseHeld = ( m_nButtons & IN_ATTACK2 ) != 0;

	// Left click: hit whatever's in front of you, otherwise dig
	bool bHitEntity = false;
	if ( bAttackPressed )
	{
		bHitEntity = MC_TryMeleeAttack();
		if ( !bHitEntity )
			MC_Swing();
	}

	MC_UpdateMining( bAttackHeld && !bHitEntity );

	// Right click: place, repeating every 4 ticks while held
	if ( bUseHeld )
	{
		if ( gpGlobals->curtime >= m_flMCNextUseTime )
		{
			if ( MC_TryPlaceBlock() )
				MC_Swing();
			m_flMCNextUseTime = gpGlobals->curtime + 0.2f;
		}
	}
	else
	{
		m_flMCNextUseTime = 0.0f;
	}
}
