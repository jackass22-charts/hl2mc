//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: The "hand" the player holds when the selected hotbar slot is empty,
//			a block or a tool. It has no model of its own: the client draws
//			Steve's arm or the held item (mc/mc_hand_render.cpp), and mining,
//			placing and melee are handled by CHL2_Player (mc/mc_interact.cpp).
//
//=============================================================================//

#include "cbase.h"
#include "basehlcombatweapon.h"
#include "hl2_player.h"
#include "baseviewmodel_shared.h"

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"

class CWeaponMCHand : public CBaseHLCombatWeapon
{
	DECLARE_CLASS( CWeaponMCHand, CBaseHLCombatWeapon );
public:
	DECLARE_SERVERCLASS();
	DECLARE_DATADESC();

	virtual void	Precache( void );
	virtual void	Spawn( void );
	virtual bool	Deploy( void );
	virtual bool	Holster( CBaseCombatWeapon *pSwitchingTo );
	virtual void	ItemPostFrame( void );
	virtual void	PrimaryAttack( void ) {}
	virtual void	SecondaryAttack( void ) {}
	virtual bool	HasAnyAmmo( void ) { return true; }
	virtual bool	VisibleInWeaponSelection( void ) { return false; }
	virtual bool	CanBeSelected( void ) { return true; }
	virtual bool	CanLower( void ) { return false; }
	virtual void	Drop( const Vector &vecVelocity ) { UTIL_Remove( this ); }

private:
	void			HideViewModel( bool bHide );
};

LINK_ENTITY_TO_CLASS( weapon_mc_hand, CWeaponMCHand );
PRECACHE_WEAPON_REGISTER( weapon_mc_hand );

IMPLEMENT_SERVERCLASS_ST( CWeaponMCHand, DT_WeaponMCHand )
END_SEND_TABLE()

BEGIN_DATADESC( CWeaponMCHand )
END_DATADESC()

void CWeaponMCHand::Precache( void )
{
	BaseClass::Precache();
}

void CWeaponMCHand::Spawn( void )
{
	BaseClass::Spawn();
	AddEffects( EF_NODRAW );
}

void CWeaponMCHand::HideViewModel( bool bHide )
{
	CBasePlayer *pOwner = ToBasePlayer( GetOwner() );
	if ( !pOwner )
		return;

	CBaseViewModel *vm = pOwner->GetViewModel( m_nViewModelIndex, false );
	if ( !vm )
		return;

	if ( bHide )
	{
		vm->SetWeaponModel( GetViewModel( m_nViewModelIndex ), this );
		vm->AddEffects( EF_NODRAW );
	}
	else
	{
		vm->RemoveEffects( EF_NODRAW );
	}
}

bool CWeaponMCHand::Deploy( void )
{
	CBasePlayer *pOwner = ToBasePlayer( GetOwner() );
	if ( !pOwner || !pOwner->IsAlive() )
		return false;

	// No model, no deploy animation: the arm is drawn by the client
	HideViewModel( true );
	AddEffects( EF_NODRAW );

	m_flNextPrimaryAttack = gpGlobals->curtime;
	m_flNextSecondaryAttack = gpGlobals->curtime;
	pOwner->SetNextAttack( gpGlobals->curtime );
	return true;
}

bool CWeaponMCHand::Holster( CBaseCombatWeapon *pSwitchingTo )
{
	HideViewModel( false );
	return BaseClass::Holster( pSwitchingTo );
}

void CWeaponMCHand::ItemPostFrame( void )
{
	// Input is handled by CHL2_Player::MC_HandThink so it also works while
	// the HL2 code would normally block weapon use (e.g. no suit yet).
	CBasePlayer *pOwner = ToBasePlayer( GetOwner() );
	if ( pOwner )
	{
		CBaseViewModel *vm = pOwner->GetViewModel( m_nViewModelIndex, false );
		if ( vm && !vm->IsEffectActive( EF_NODRAW ) )
			vm->AddEffects( EF_NODRAW );
	}
}
