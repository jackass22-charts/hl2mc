//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Server entities
//			mc_block - a placed 40-unit block. Solid to players, NPCs, bullets
//			           and physics props. Drawn by the client (c_mc_entities.cpp).
//			mc_item  - a dropped item stack that the player picks up by walking
//			           into it.
//			Plus: HL2 props drop Minecraft materials when they break.
//
//=============================================================================//

#include "cbase.h"
#include "hl2_player.h"
#include "physics_shared.h"
#include "vcollide_parse.h"
#include "decals.h"
#include "mc/mc_shared.h"
#include "mc/mc_items.h"
#include "mc/mc_entities.h"

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"

ConVar mc_max_blocks( "mc_max_blocks", "700", FCVAR_NOTIFY, "Most placed blocks allowed at once (each one is an entity; Source has a 2048 entity limit)." );
ConVar mc_prop_drops( "mc_prop_drops", "1", FCVAR_NOTIFY, "Breaking HL2 props drops Minecraft materials (wood -> planks, concrete -> cobblestone...)." );

//=============================================================================
// mc_block
//=============================================================================
class CMCBlock : public CBaseEntity
{
	DECLARE_CLASS( CMCBlock, CBaseEntity );
public:
	DECLARE_SERVERCLASS();
	DECLARE_DATADESC();

	CMCBlock();

	virtual void	Spawn( void );
	virtual void	Activate( void );
	virtual int		UpdateTransmitState( void ) { return SetTransmitState( FL_EDICT_PVSCHECK ); }
	virtual int		ObjectCaps( void ) { return BaseClass::ObjectCaps() & ~FCAP_ACROSS_TRANSITION; }

	void			SetBlockItem( int iItem ) { m_iBlockItem = iItem; }
	int				GetBlockItem( void ) const { return m_iBlockItem; }

	static int		s_iCount;

private:
	void			CreatePhysics( void );
	CNetworkVar( int, m_iBlockItem );
};

int CMCBlock::s_iCount = 0;

LINK_ENTITY_TO_CLASS( mc_block, CMCBlock );

IMPLEMENT_SERVERCLASS_ST( CMCBlock, DT_MCBlock )
	SendPropInt( SENDINFO( m_iBlockItem ), 8, SPROP_UNSIGNED ),
END_SEND_TABLE()

BEGIN_DATADESC( CMCBlock )
	DEFINE_FIELD( m_iBlockItem, FIELD_INTEGER ),
END_DATADESC()

CMCBlock::CMCBlock()
{
	m_iBlockItem = MC_ITEM_STONE;
}

void CMCBlock::Spawn( void )
{
	BaseClass::Spawn();
	SetMoveType( MOVETYPE_NONE );
	SetSolid( SOLID_BBOX );
	UTIL_SetSize( this, Vector( -MC_BLOCK_HALF, -MC_BLOCK_HALF, -MC_BLOCK_HALF ), Vector( MC_BLOCK_HALF, MC_BLOCK_HALF, MC_BLOCK_HALF ) );
	SetCollisionGroup( COLLISION_GROUP_NONE );
	m_takedamage = DAMAGE_NO;
	CreatePhysics();
}

void CMCBlock::Activate( void )
{
	BaseClass::Activate();
	// Restored from a save: rebuild the physics box
	if ( !VPhysicsGetObject() )
		CreatePhysics();
}

void CMCBlock::CreatePhysics( void )
{
	// A static physics box so props and ragdolls collide with the block
	solid_t solid;
	PhysGetDefaultAABBSolid( solid );
	const char *pszSurface = MC_GetItem( m_iBlockItem )->pszSurface;
	Q_strncpy( solid.surfaceprop, pszSurface ? pszSurface : "default", sizeof( solid.surfaceprop ) );
	solid.params.volume = MC_BLOCK_SIZE * MC_BLOCK_SIZE * MC_BLOCK_SIZE;

	CPhysCollide *pCollide = PhysCreateBbox( Vector( -MC_BLOCK_HALF, -MC_BLOCK_HALF, -MC_BLOCK_HALF ), Vector( MC_BLOCK_HALF, MC_BLOCK_HALF, MC_BLOCK_HALF ) );
	if ( !pCollide )
		return;

	IPhysicsObject *pObj = PhysModelCreateCustom( this, pCollide, GetAbsOrigin(), vec3_angle, "mc_block", true, &solid );
	if ( pObj )
		VPhysicsSetObject( pObj );
}

// Count blocks by walking the entity list (cheap enough; only on placement)
int MC_CountBlocks( void )
{
	int iCount = 0;
	CBaseEntity *pEnt = NULL;
	while ( ( pEnt = gEntList.FindEntityByClassname( pEnt, "mc_block" ) ) != NULL )
		iCount++;
	return iCount;
}

CBaseEntity *MC_SpawnBlock( const Vector &vecCenter, int iItem )
{
	if ( !MC_IsBlock( iItem ) )
		return NULL;

	if ( MC_CountBlocks() >= mc_max_blocks.GetInt() )
	{
		CBasePlayer *pPlayer = UTIL_GetLocalPlayer();
		if ( pPlayer )
			ClientPrint( pPlayer, HUD_PRINTCENTER, "Block limit reached (mc_max_blocks)" );
		return NULL;
	}

	CMCBlock *pBlock = static_cast< CMCBlock * >( CreateEntityByName( "mc_block" ) );
	if ( !pBlock )
		return NULL;

	pBlock->SetBlockItem( iItem );
	pBlock->SetAbsOrigin( vecCenter );
	pBlock->SetAbsAngles( vec3_angle );
	DispatchSpawn( pBlock );
	return pBlock;
}

bool MC_IsBlockEntity( CBaseEntity *pEntity )
{
	return pEntity && pEntity->ClassMatches( "mc_block" );
}

int MC_GetBlockItem( CBaseEntity *pEntity )
{
	if ( !MC_IsBlockEntity( pEntity ) )
		return MC_ITEM_NONE;
	return static_cast< CMCBlock * >( pEntity )->GetBlockItem();
}

//=============================================================================
// mc_item - a dropped stack
//=============================================================================
class CMCItem : public CBaseEntity
{
	DECLARE_CLASS( CMCItem, CBaseEntity );
public:
	DECLARE_SERVERCLASS();
	DECLARE_DATADESC();

	virtual void	Spawn( void );
	virtual int		UpdateTransmitState( void ) { return SetTransmitState( FL_EDICT_PVSCHECK ); }
	void			ItemThink( void );

	CNetworkVar( int, m_iItem );
	CNetworkVar( int, m_iCount );
	int				m_iDamage;
	float			m_flPickupTime;
	float			m_flDespawnTime;
};

LINK_ENTITY_TO_CLASS( mc_item, CMCItem );

IMPLEMENT_SERVERCLASS_ST( CMCItem, DT_MCItem )
	SendPropInt( SENDINFO( m_iItem ), 8, SPROP_UNSIGNED ),
	SendPropInt( SENDINFO( m_iCount ), 7, SPROP_UNSIGNED ),
END_SEND_TABLE()

BEGIN_DATADESC( CMCItem )
	DEFINE_FIELD( m_iItem, FIELD_INTEGER ),
	DEFINE_FIELD( m_iCount, FIELD_INTEGER ),
	DEFINE_FIELD( m_iDamage, FIELD_INTEGER ),
	DEFINE_FIELD( m_flPickupTime, FIELD_TIME ),
	DEFINE_FIELD( m_flDespawnTime, FIELD_TIME ),
	DEFINE_THINKFUNC( ItemThink ),
END_DATADESC()

void CMCItem::Spawn( void )
{
	BaseClass::Spawn();
	SetMoveType( MOVETYPE_FLYGRAVITY, MOVECOLLIDE_FLY_BOUNCE );
	SetSolid( SOLID_BBOX );
	UTIL_SetSize( this, Vector( -4, -4, 0 ), Vector( 4, 4, 8 ) );
	SetCollisionGroup( COLLISION_GROUP_DEBRIS );
	SetElasticity( 0.1f );
	SetFriction( 1.0f );
	SetGravity( 1.0f );
	m_flDespawnTime = gpGlobals->curtime + 300.0f;	// 5 minutes, like Minecraft
	SetThink( &CMCItem::ItemThink );
	SetNextThink( gpGlobals->curtime + 0.1f );
}

void CMCItem::ItemThink( void )
{
	SetNextThink( gpGlobals->curtime + 0.1f );

	if ( gpGlobals->curtime > m_flDespawnTime || m_iCount <= 0 )
	{
		UTIL_Remove( this );
		return;
	}

	// Slow to a stop once on the ground
	if ( GetFlags() & FL_ONGROUND )
		SetAbsVelocity( GetAbsVelocity() * 0.5f );

	if ( gpGlobals->curtime < m_flPickupTime || !MC_IsEnabled() )
		return;

	CHL2_Player *pPlayer = dynamic_cast< CHL2_Player * >( UTIL_GetLocalPlayer() );
	if ( !pPlayer || !pPlayer->IsAlive() )
		return;

	// Minecraft picks items up within the player's box grown by one block sideways and half a block up/down
	Vector vecPlayer = pPlayer->GetAbsOrigin();
	Vector vecItem = GetAbsOrigin();
	Vector2D vecDelta( vecItem.x - vecPlayer.x, vecItem.y - vecPlayer.y );
	if ( vecDelta.Length() > 16.0f + MC_BLOCK_SIZE || vecItem.z < vecPlayer.z - 20.0f || vecItem.z > vecPlayer.z + 72.0f + 20.0f )
		return;

	int iLeft = pPlayer->MC_AddItem( m_iItem, m_iCount, m_iDamage );
	if ( iLeft < m_iCount )
	{
		pPlayer->EmitSound( "HL2Player.PickupWeapon" );
		m_iCount = iLeft;
		if ( iLeft <= 0 )
			UTIL_Remove( this );
	}
}

CBaseEntity *MC_SpawnDroppedItem( const Vector &vecOrigin, const Vector &vecVelocity, int iItem, int iCount, int iDamage, float flPickupDelay )
{
	if ( iItem == MC_ITEM_NONE || iCount <= 0 )
		return NULL;

	CMCItem *pItem = static_cast< CMCItem * >( CreateEntityByName( "mc_item" ) );
	if ( !pItem )
		return NULL;

	pItem->m_iItem = iItem;
	pItem->m_iCount = iCount;
	pItem->m_iDamage = iDamage;
	pItem->m_flPickupTime = gpGlobals->curtime + flPickupDelay;
	pItem->SetAbsOrigin( vecOrigin );
	DispatchSpawn( pItem );
	pItem->SetAbsVelocity( vecVelocity );
	return pItem;
}

//=============================================================================
// HL2 props drop Minecraft materials when broken
//=============================================================================
void MC_OnPropBroken( CBaseEntity *pProp, CBaseEntity *pBreaker )
{
	if ( !MC_IsEnabled() || !mc_prop_drops.GetBool() || !pProp )
		return;

	IPhysicsObject *pObj = pProp->VPhysicsGetObject();
	if ( !pObj )
		return;

	const surfacedata_t *pSurface = physprops->GetSurfaceData( pObj->GetMaterialIndex() );
	if ( !pSurface )
		return;

	int iItem = MC_ITEM_NONE;
	int iMin = 1, iMax = 2;
	switch ( pSurface->game.material )
	{
	case CHAR_TEX_WOOD:		iItem = MC_ITEM_OAK_PLANKS; iMin = 1; iMax = 3; break;
	case CHAR_TEX_CONCRETE:
	case CHAR_TEX_TILE:		iItem = MC_ITEM_COBBLESTONE; break;
	case CHAR_TEX_DIRT:		iItem = MC_ITEM_DIRT; break;
	case CHAR_TEX_SAND:		iItem = MC_ITEM_SAND; break;
	case CHAR_TEX_FOLIAGE:	iItem = MC_ITEM_OAK_LEAVES; iMax = 1; break;
	default:				return;
	}

	// Supply crates are bigger
	if ( pProp->ClassMatches( "item_item_crate" ) )
	{
		iMin += 1;
		iMax += 2;
	}

	int iCount = RandomInt( iMin, iMax );
	Vector vecVel( RandomFloat( -60, 60 ), RandomFloat( -60, 60 ), RandomFloat( 80, 140 ) );
	MC_SpawnDroppedItem( pProp->WorldSpaceCenter(), vecVel, iItem, iCount, 0, 0.5f );
}
