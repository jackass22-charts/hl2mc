//========= Copyright Valve Corporation, All rights reserved. ============//
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================//

#ifndef HL2_PLAYERLOCALDATA_H
#define HL2_PLAYERLOCALDATA_H
#ifdef _WIN32
#pragma once
#endif

#include "networkvar.h"

#include "hl_movedata.h"
#include "mc/mc_items.h"

//-----------------------------------------------------------------------------
// Purpose: Player specific data for HL2 ( sent only to local player, too )
//-----------------------------------------------------------------------------
class CHL2PlayerLocalData
{
public:
	// Save/restore
	DECLARE_SIMPLE_DATADESC();
	DECLARE_CLASS_NOBASE( CHL2PlayerLocalData );
	DECLARE_EMBEDDED_NETWORKVAR();

	CHL2PlayerLocalData();

	CNetworkVar( float, m_flSuitPower );
	CNetworkVar( bool,	m_bZooming );
	CNetworkVar( int,	m_bitsActiveDevices );
	CNetworkVar( int,	m_iSquadMemberCount );
	CNetworkVar( int,	m_iSquadMedicCount );
	CNetworkVar( bool,	m_fSquadInFollowMode );
	CNetworkVar( bool,	m_bWeaponLowered );
	CNetworkVar( EHANDLE, m_hAutoAimTarget );
	CNetworkVar( Vector, m_vecAutoAimPoint );
	CNetworkVar( bool,	m_bDisplayReticle );
	CNetworkVar( bool,	m_bStickyAutoAim );
	CNetworkVar( bool,	m_bAutoAimTarget );
#ifdef HL2_EPISODIC
	CNetworkVar( float, m_flFlashBattery );
	CNetworkVar( Vector, m_vecLocatorOrigin );
#endif

	// HL2:MC - Minecraft-style survival stats (sent to the local player for the HUD)
	CNetworkVar( int,	m_iMCFood );			// 0..20 (each shank on the HUD is 2)
	CNetworkVar( float, m_flMCSaturation );		// 0..food
	CNetworkVar( float, m_flMCExhaustion );		// 0..40, every 4.0 costs one saturation/food point
	CNetworkVar( int,	m_iMCXPTotal );
	CNetworkVar( int,	m_iMCXPLevel );
	CNetworkVar( float, m_flMCXPProgress );		// 0..1 progress to next level
	CNetworkVar( int,	m_iMCAir );				// 0..300 ticks of breath
	CNetworkVar( int,	m_iMCArmor );			// suit battery, mirrored for the armor bar

	// HL2:MC - inventory (0-8 hotbar, 9-35 main), the stack held by the mouse, and interaction state
	CNetworkArray( int, m_iMCInvItem, MC_INV_SLOTS );
	CNetworkArray( int, m_iMCInvCount, MC_INV_SLOTS );
	CNetworkArray( int, m_iMCInvDamage, MC_INV_SLOTS );	// tool wear
	CNetworkVar( int,	m_iMCCursorItem );
	CNetworkVar( int,	m_iMCCursorCount );
	CNetworkVar( int,	m_iMCCursorDamage );
	CNetworkVar( int,	m_iMCSelected );		// selected hotbar slot 0-8
	CNetworkVar( int,	m_iMCGameMode );		// 0 survival, 1 creative
	CNetworkVar( bool,	m_bMCFlying );			// creative flight
	CNetworkVar( EHANDLE, m_hMCBreakTarget );	// block being mined
	CNetworkVar( float, m_flMCBreakProgress );	// 0..1
	CNetworkVar( int,	m_iMCSwingCount );		// bumps every arm swing, for the first-person animation

	// Ladder related data
	CNetworkVar( EHANDLE, m_hLadder );
	LadderMove_t			m_LadderMove;
};

EXTERN_SEND_TABLE(DT_HL2Local);


#endif // HL2_PLAYERLOCALDATA_H
