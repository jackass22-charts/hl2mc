//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: The inventory screen (E). Survival shows Minecraft's inventory
//			window; Creative shows an item palette above your inventory.
//			Clicks follow Minecraft: left picks up / places / swaps, right
//			splits or places one, shift moves between hotbar and inventory,
//			clicking outside drops. The server owns the actual inventory.
//
//=============================================================================//

#include "cbase.h"
#include "c_basehlplayer.h"
#include "ienginevgui.h"
#include "mc/mc_shared.h"
#include "mc/mc_items.h"
#include "mc/mc_sprites.h"
#include "mc/mc_itemicons.h"
#include <vgui_controls/Panel.h>
#include <vgui_controls/Controls.h>
#include <vgui/ISurface.h>
#include <vgui/IInput.h>

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"

using namespace vgui;

#define MC_INV_W		176
#define MC_INV_H		166
#define MC_CREATIVE_W	176
#define MC_CREATIVE_H	222

struct MCSlotPos_t
{
	int iSlot;		// inventory slot, or -1 - palette index for the creative palette
	int x, y;		// item position inside the window
};

class CMCInventoryPanel : public vgui::Panel
{
	DECLARE_CLASS_SIMPLE( CMCInventoryPanel, vgui::Panel );
public:
	CMCInventoryPanel( vgui::VPANEL parent );

	void			Open( void );
	void			Close( bool bTellServer );
	bool			IsOpen( void ) { return IsVisible(); }

	virtual void	Paint( void );
	virtual void	OnThink( void );
	virtual void	OnMousePressed( MouseCode code );
	virtual void	OnMouseDoublePressed( MouseCode code ) { OnMousePressed( code ); }
	virtual void	OnKeyCodePressed( KeyCode code );

private:
	void			BuildSlots( bool bCreative );
	void			GetWindow( const MCGui_t &gui, int &x0, int &y0, int &w, int &h );
	int				SlotAt( int gx, int gy, int x0, int y0 );	// index into m_Slots, -1 if none
	void			PaintTooltip( const char *pszText, int gx, int gy, const MCGui_t &gui );

	CUtlVector< MCSlotPos_t > m_Slots;
	bool			m_bCreative;
};

static CMCInventoryPanel *s_pInventory = NULL;

CMCInventoryPanel::CMCInventoryPanel( vgui::VPANEL parent ) : BaseClass( NULL, "MCInventory" )
{
	SetParent( parent );
	SetVisible( false );
	SetPaintBackgroundEnabled( false );
	SetMouseInputEnabled( false );
	SetKeyBoardInputEnabled( false );
	m_bCreative = false;
}

void CMCInventoryPanel::BuildSlots( bool bCreative )
{
	m_Slots.RemoveAll();
	m_bCreative = bCreative;

	if ( bCreative )
	{
		// Palette: 6 rows of 9 (Minecraft's large chest layout)
		for ( int i = 0; i < 54; i++ )
		{
			MCSlotPos_t s = { -1 - i, 8 + ( i % 9 ) * 18, 18 + ( i / 9 ) * 18 };
			m_Slots.AddToTail( s );
		}
		for ( int i = 9; i < MC_INV_SLOTS; i++ )
		{
			MCSlotPos_t s = { i, 8 + ( ( i - 9 ) % 9 ) * 18, 140 + ( ( i - 9 ) / 9 ) * 18 };
			m_Slots.AddToTail( s );
		}
		for ( int i = 0; i < 9; i++ )
		{
			MCSlotPos_t s = { i, 8 + i * 18, 198 };
			m_Slots.AddToTail( s );
		}
	}
	else
	{
		for ( int i = 9; i < MC_INV_SLOTS; i++ )
		{
			MCSlotPos_t s = { i, 8 + ( ( i - 9 ) % 9 ) * 18, 84 + ( ( i - 9 ) / 9 ) * 18 };
			m_Slots.AddToTail( s );
		}
		for ( int i = 0; i < 9; i++ )
		{
			MCSlotPos_t s = { i, 8 + i * 18, 142 };
			m_Slots.AddToTail( s );
		}
	}
}

void CMCInventoryPanel::Open( void )
{
	C_BaseHLPlayer *pPlayer = dynamic_cast< C_BaseHLPlayer * >( C_BasePlayer::GetLocalPlayer() );
	BuildSlots( pPlayer && pPlayer->MC_IsCreative() );

	SetBounds( 0, 0, ScreenWidth(), ScreenHeight() );
	SetVisible( true );
	MakePopup( false, false );
	SetMouseInputEnabled( true );
	SetKeyBoardInputEnabled( true );
	RequestFocus();
	MoveToFront();
}

void CMCInventoryPanel::Close( bool bTellServer )
{
	if ( !IsVisible() )
		return;
	SetVisible( false );
	SetMouseInputEnabled( false );
	SetKeyBoardInputEnabled( false );
	if ( bTellServer )
		engine->ClientCmd( "mc_inv_close\n" );
}

void CMCInventoryPanel::GetWindow( const MCGui_t &gui, int &x0, int &y0, int &w, int &h )
{
	w = m_bCreative ? MC_CREATIVE_W : MC_INV_W;
	h = m_bCreative ? MC_CREATIVE_H : MC_INV_H;
	x0 = ( gui.w - w ) / 2;
	y0 = ( gui.h - h ) / 2;
}

int CMCInventoryPanel::SlotAt( int gx, int gy, int x0, int y0 )
{
	for ( int i = 0; i < m_Slots.Count(); i++ )
	{
		int sx = x0 + m_Slots[i].x - 1;
		int sy = y0 + m_Slots[i].y - 1;
		if ( gx >= sx && gx < sx + 18 && gy >= sy && gy < sy + 18 )
			return i;
	}
	return -1;
}

void CMCInventoryPanel::OnThink( void )
{
	// Close if we died, got in a vehicle or the feature was turned off
	C_BasePlayer *pPlayer = C_BasePlayer::GetLocalPlayer();
	if ( !pPlayer || !pPlayer->IsAlive() || !MC_IsEnabled() || !mc_inventory.GetBool() )
		Close( true );
}

void CMCInventoryPanel::OnKeyCodePressed( KeyCode code )
{
	if ( code == KEY_E || code == KEY_ESCAPE || code == KEY_TAB || code == KEY_I )
	{
		Close( true );
		return;
	}
	BaseClass::OnKeyCodePressed( code );
}

void CMCInventoryPanel::OnMousePressed( MouseCode code )
{
	if ( code != MOUSE_LEFT && code != MOUSE_RIGHT )
		return;

	const MCGui_t gui = MC_GetGui();
	int mx, my;
	vgui::input()->GetCursorPos( mx, my );
	const int gx = mx / gui.scale, gy = my / gui.scale;

	int x0, y0, w, h;
	GetWindow( gui, x0, y0, w, h );

	const int iButton = ( code == MOUSE_RIGHT ) ? 1 : 0;
	const bool bShift = vgui::input()->IsKeyDown( KEY_LSHIFT ) || vgui::input()->IsKeyDown( KEY_RSHIFT );

	int iHit = SlotAt( gx, gy, x0, y0 );
	if ( iHit >= 0 )
	{
		const MCSlotPos_t &slot = m_Slots[iHit];
		if ( slot.iSlot >= 0 )
		{
			engine->ClientCmd( VarArgs( "mc_inv_click %d %d %d\n", slot.iSlot, iButton, bShift ? 1 : 0 ) );
		}
		else
		{
			int iPalette = -1 - slot.iSlot;
			int iItem = MC_GetCreativeItem( iPalette );
			engine->ClientCmd( VarArgs( "mc_inv_pick %d %d %d\n", iItem, iButton, bShift ? 1 : 0 ) );
		}
		return;
	}

	// Outside the window: drop the held stack
	if ( gx < x0 || gy < y0 || gx >= x0 + w || gy >= y0 + h )
		engine->ClientCmd( VarArgs( "mc_inv_drop %d\n", iButton ) );
}

void CMCInventoryPanel::PaintTooltip( const char *pszText, int gx, int gy, const MCGui_t &gui )
{
	CMCSprites &sprites = CMCSprites::Get();
	int tw = sprites.TextWidth( pszText, gui );
	int x = gx + 12, y = gy - 12;
	if ( x + tw + 4 > gui.w )
		x = gx - tw - 16;

	// Minecraft's tooltip: near-black box with a purple border
	CMCSprites::FillRect( x - 3, y - 4, tw + 6, 16, gui, Color( 16, 0, 16, 240 ) );
	const Color border( 80, 0, 255, 120 );
	CMCSprites::FillRect( x - 3, y - 3, tw + 6, 1, gui, border );
	CMCSprites::FillRect( x - 3, y + 10, tw + 6, 1, gui, border );
	CMCSprites::FillRect( x - 3, y - 3, 1, 14, gui, border );
	CMCSprites::FillRect( x + tw + 2, y - 3, 1, 14, gui, border );
	sprites.DrawString( pszText, x, y, gui, Color( 255, 255, 255, 255 ), true );
}

void CMCInventoryPanel::Paint( void )
{
	C_BaseHLPlayer *pPlayer = dynamic_cast< C_BaseHLPlayer * >( C_BasePlayer::GetLocalPlayer() );
	if ( !pPlayer )
		return;

	// Rebuild if the game mode changed while open
	if ( pPlayer->MC_IsCreative() != m_bCreative )
		BuildSlots( pPlayer->MC_IsCreative() );

	const MCGui_t gui = MC_GetGui();
	CMCSprites &sprites = CMCSprites::Get();

	// Dim the game behind the window, like Minecraft
	surface()->DrawSetColor( Color( 16, 16, 16, 150 ) );
	surface()->DrawFilledRect( 0, 0, ScreenWidth(), ScreenHeight() );

	int x0, y0, w, h;
	GetWindow( gui, x0, y0, w, h );

	const char *pszBackground = m_bCreative ? "gui_generic_54" : "gui_inventory";
	if ( !sprites.DrawSprite( pszBackground, x0, y0, gui ) )
	{
		// Placeholder window
		CMCSprites::FillRect( x0, y0, w, h, gui, Color( 198, 198, 198, 255 ) );
		for ( int i = 0; i < m_Slots.Count(); i++ )
			CMCSprites::FillRect( x0 + m_Slots[i].x - 1, y0 + m_Slots[i].y - 1, 18, 18, gui, Color( 139, 139, 139, 255 ) );
	}

	sprites.DrawString( m_bCreative ? "Creative" : "Crafting", x0 + ( m_bCreative ? 8 : 97 ), y0 + ( m_bCreative ? 6 : 8 ), gui, Color( 64, 64, 64, 255 ), false );
	sprites.DrawString( "Inventory", x0 + 8, y0 + ( m_bCreative ? 129 : 73 ), gui, Color( 64, 64, 64, 255 ), false );

	int mx, my;
	vgui::input()->GetCursorPos( mx, my );
	const int gx = mx / gui.scale, gy = my / gui.scale;
	const int iHover = SlotAt( gx, gy, x0, y0 );

	for ( int i = 0; i < m_Slots.Count(); i++ )
	{
		const MCSlotPos_t &slot = m_Slots[i];
		int x = x0 + slot.x, y = y0 + slot.y;

		int iItem, iCount, iDamage;
		if ( slot.iSlot >= 0 )
		{
			iItem = pPlayer->m_HL2Local.m_iMCInvItem[slot.iSlot];
			iCount = pPlayer->m_HL2Local.m_iMCInvCount[slot.iSlot];
			iDamage = pPlayer->m_HL2Local.m_iMCInvDamage[slot.iSlot];
		}
		else
		{
			iItem = MC_GetCreativeItem( -1 - slot.iSlot );
			iCount = 1;
			iDamage = 0;
		}

		if ( iItem != MC_ITEM_NONE )
		{
			MC_DrawItemIcon( iItem, x, y, gui, pPlayer );
			MC_DrawItemDecorations( iItem, MC_IsWeaponItem( iItem ) ? 1 : iCount, iDamage, x, y, gui );
		}

		if ( i == iHover )
			CMCSprites::FillRect( x, y, 16, 16, gui, Color( 255, 255, 255, 128 ) );
	}

	// The stack on the mouse
	const int cItem = pPlayer->m_HL2Local.m_iMCCursorItem;
	if ( cItem != MC_ITEM_NONE )
	{
		MC_DrawItemIcon( cItem, gx - 8, gy - 8, gui, pPlayer );
		MC_DrawItemDecorations( cItem, MC_IsWeaponItem( cItem ) ? 1 : pPlayer->m_HL2Local.m_iMCCursorCount, pPlayer->m_HL2Local.m_iMCCursorDamage, gx - 8, gy - 8, gui );
	}
	else if ( iHover >= 0 )
	{
		const MCSlotPos_t &slot = m_Slots[iHover];
		int iItem = slot.iSlot >= 0 ? pPlayer->m_HL2Local.m_iMCInvItem[slot.iSlot] : MC_GetCreativeItem( -1 - slot.iSlot );
		if ( iItem != MC_ITEM_NONE )
		{
			char szName[64];
			MC_GetItemDisplayName( iItem, szName, sizeof( szName ) );
			PaintTooltip( szName, gx, gy, gui );
		}
	}
}

//-----------------------------------------------------------------------------
CON_COMMAND( mc_inventory_toggle, "Open or close the Minecraft inventory (E)." )
{
	if ( !MC_IsEnabled() || !mc_inventory.GetBool() )
		return;

	C_BasePlayer *pPlayer = C_BasePlayer::GetLocalPlayer();
	if ( !pPlayer || !pPlayer->IsAlive() )
		return;

	if ( !s_pInventory )
		s_pInventory = new CMCInventoryPanel( enginevgui->GetPanel( PANEL_CLIENTDLL ) );

	if ( s_pInventory->IsOpen() )
		s_pInventory->Close( true );
	else
		s_pInventory->Open();
}
