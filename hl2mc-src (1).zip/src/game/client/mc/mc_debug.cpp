//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: F3 debug screen. Coordinates are shown in blocks using Minecraft's
//			axes: X = Hammer X (east), Y = Hammer Z (up), Z = -Hammer Y (south).
//
//=============================================================================//

#include "cbase.h"
#include "hud.h"
#include "hudelement.h"
#include "hud_macros.h"
#include "iclientmode.h"
#include "c_basehlplayer.h"
#include "mc/mc_shared.h"
#include "mc/mc_sprites.h"
#include <vgui_controls/Panel.h>
#include <vgui/ISurface.h>

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"

using namespace vgui;

ConVar mc_debug_screen( "mc_debug_screen", "0", 0, "Show the F3 debug screen." );

CON_COMMAND( mc_debug_toggle, "Toggle the F3 debug screen." )
{
	mc_debug_screen.SetValue( !mc_debug_screen.GetBool() );
}

class CHudMCDebug : public CHudElement, public vgui::Panel
{
	DECLARE_CLASS_SIMPLE( CHudMCDebug, vgui::Panel );

public:
	CHudMCDebug( const char *pElementName ) : CHudElement( pElementName ), BaseClass( NULL, "HudMCDebug" )
	{
		SetParent( g_pClientMode->GetViewport() );
		SetHiddenBits( 0 );
		SetPaintBackgroundEnabled( false );
		SetMouseInputEnabled( false );
		SetKeyBoardInputEnabled( false );
		m_flFps = 60.0f;
	}

	virtual void ApplySchemeSettings( vgui::IScheme *pScheme )
	{
		BaseClass::ApplySchemeSettings( pScheme );
		SetBgColor( Color( 0, 0, 0, 0 ) );
		SetPaintBackgroundEnabled( false );
	}

	virtual bool ShouldDraw( void )
	{
		return mc_debug_screen.GetBool() && CHudElement::ShouldDraw();
	}

	virtual void OnThink( void )
	{
		SetBounds( 0, 0, ScreenWidth(), ScreenHeight() );

		if ( gpGlobals->absoluteframetime > 0.0f )
			m_flFps = m_flFps * 0.9f + ( 1.0f / gpGlobals->absoluteframetime ) * 0.1f;
	}

	virtual void Paint( void );

private:
	void Line( CUtlVector< CUtlString > &lines, const char *pszFormat, ... );
	void DrawColumn( const CUtlVector< CUtlString > &lines, bool bRight, const MCGui_t &gui );

	float m_flFps;
};

DECLARE_HUDELEMENT( CHudMCDebug );

void CHudMCDebug::Line( CUtlVector< CUtlString > &lines, const char *pszFormat, ... )
{
	char szBuf[256];
	va_list args;
	va_start( args, pszFormat );
	Q_vsnprintf( szBuf, sizeof( szBuf ), pszFormat, args );
	va_end( args );
	lines.AddToTail( CUtlString( szBuf ) );
}

void CHudMCDebug::DrawColumn( const CUtlVector< CUtlString > &lines, bool bRight, const MCGui_t &gui )
{
	CMCSprites &sprites = CMCSprites::Get();
	const Color bg( 0x50, 0x50, 0x50, 0x90 );
	const Color fg( 0xE0, 0xE0, 0xE0, 255 );

	for ( int i = 0; i < lines.Count(); i++ )
	{
		const char *psz = lines[i].Get();
		if ( !psz[0] )
			continue;

		const int w = sprites.TextWidth( psz, gui );
		const int top = 2 + 9 * i;
		const int x = bRight ? gui.w - 2 - w : 2;

		CMCSprites::FillRect( x - 1, top - 1, w + 1, 9, gui, bg );
		sprites.DrawString( psz, x, top, gui, fg, false );
	}
}

void CHudMCDebug::Paint( void )
{
	C_BaseHLPlayer *pPlayer = dynamic_cast< C_BaseHLPlayer * >( C_BasePlayer::GetLocalPlayer() );
	if ( !pPlayer )
		return;

	const MCGui_t gui = MC_GetGui();
	CUtlVector< CUtlString > left, right;

	const Vector &pos = pPlayer->GetAbsOrigin();
	const float bx = pos.x / MC_UNITS_PER_BLOCK;
	const float by = pos.z / MC_UNITS_PER_BLOCK;
	const float bz = -pos.y / MC_UNITS_PER_BLOCK;

	QAngle angEye = pPlayer->EyeAngles();
	const float flMCYaw = AngleNormalize( -angEye.y - 90.0f );
	static const char *s_pszDir[] = { "south", "west", "north", "east" };
	static const char *s_pszAxis[] = { "positive Z", "negative X", "negative Z", "positive X" };
	const int iDir = ( (int)floorf( flMCYaw / 90.0f + 0.5f ) ) & 3;

	Line( left, "Half-Life 2 (Minecraft mechanics)" );
	Line( left, "%d fps", (int)( m_flFps + 0.5f ) );
	Line( left, "" );
	Line( left, "XYZ: %.3f / %.5f / %.3f", bx, by, bz );
	Line( left, "Block: %d %d %d", (int)floorf( bx ), (int)floorf( by ), (int)floorf( bz ) );
	Line( left, "Facing: %s (Towards %s) (%.1f / %.1f)", s_pszDir[iDir], s_pszAxis[iDir], flMCYaw, angEye.x );
	Line( left, "" );

	char szMap[MAX_PATH];
	Q_FileBase( engine->GetLevelName(), szMap, sizeof( szMap ) );
	Line( left, "Map: %s", szMap );

	const Vector vel = pPlayer->GetAbsVelocity();
	Line( left, "Speed: %.2f blocks/s%s%s", vel.Length2D() / MC_UNITS_PER_BLOCK,
		  pPlayer->m_fIsSprinting ? " [sprinting]" : "",
		  ( pPlayer->GetFlags() & FL_DUCKING ) ? " [sneaking]" : "" );
	Line( left, "Health: %d/%d (%.1f hearts)  Armor: %d", pPlayer->GetHealth(), 100,
		  pPlayer->GetHealth() / ( MC_HL2HP_PER_MCHP * 2.0f ), pPlayer->m_HL2Local.m_iMCArmor );
	Line( left, "Food: %d  Saturation: %.1f  Exhaustion: %.2f", pPlayer->m_HL2Local.m_iMCFood,
		  pPlayer->m_HL2Local.m_flMCSaturation, pPlayer->m_HL2Local.m_flMCExhaustion );
	Line( left, "XP: level %d, %d%% to next (%d total)", pPlayer->m_HL2Local.m_iMCXPLevel,
		  (int)( pPlayer->m_HL2Local.m_flMCXPProgress * 100.0f ), pPlayer->m_HL2Local.m_iMCXPTotal );
	Line( left, "Air: %d/%d", pPlayer->m_HL2Local.m_iMCAir, MC_MAX_AIR );

	// Right column
	static ConVarRef skill( "skill" );
	static const char *s_pszSkill[] = { "Easy", "Easy", "Normal", "Hard" };
	Line( right, "Difficulty: %s", s_pszSkill[clamp( skill.GetInt(), 0, 3 )] );
	Line( right, "GUI scale: %d", gui.scale );
	Line( right, "Display: %dx%d", ScreenWidth(), ScreenHeight() );
	Line( right, "Mechanics: %s", MC_IsEnabled() ? "Minecraft" : "Half-Life 2" );

	// What the crosshair is on, within 5 blocks
	Vector vecForward;
	AngleVectors( angEye, &vecForward );
	const Vector vecStart = pPlayer->EyePosition();
	trace_t tr;
	UTIL_TraceLine( vecStart, vecStart + vecForward * ( 5.0f * MC_UNITS_PER_BLOCK ), MASK_SHOT, pPlayer, COLLISION_GROUP_NONE, &tr );
	if ( tr.fraction < 1.0f )
	{
		const Vector p = tr.endpos - tr.plane.normal * 0.5f;
		Line( right, "" );
		Line( right, "Targeted Block: %d, %d, %d", (int)floorf( p.x / MC_UNITS_PER_BLOCK ),
			  (int)floorf( p.z / MC_UNITS_PER_BLOCK ), (int)floorf( -p.y / MC_UNITS_PER_BLOCK ) );
		if ( tr.surface.name && tr.surface.name[0] )
			Line( right, "%s", tr.surface.name );

		if ( tr.m_pEnt && !tr.m_pEnt->IsWorld() && tr.m_pEnt->GetModel() )
		{
			Line( right, "" );
			Line( right, "Targeted Entity" );
			Line( right, "%s", modelinfo->GetModelName( tr.m_pEnt->GetModel() ) );
		}
	}

	DrawColumn( left, false, gui );
	DrawColumn( right, true, gui );
}
