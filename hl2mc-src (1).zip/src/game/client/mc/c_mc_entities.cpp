//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Client side of mc_block (placed blocks, with break cracks) and
//			mc_item (dropped items that bob and spin).
//
//=============================================================================//

#include "cbase.h"
#include "c_basehlplayer.h"
#include "mc/mc_shared.h"
#include "mc/mc_items.h"
#include "mc/mc_render.h"

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"

//=============================================================================
// C_MCBlock
//=============================================================================
class C_MCBlock : public C_BaseEntity
{
	DECLARE_CLASS( C_MCBlock, C_BaseEntity );
public:
	DECLARE_CLIENTCLASS();

	C_MCBlock() : m_iBlockItem( MC_ITEM_STONE ) {}

	virtual bool			ShouldDraw( void ) { return !IsDormant(); }
	virtual RenderGroup_t	GetRenderGroup( void ) { return RENDER_GROUP_OPAQUE_ENTITY; }
	virtual bool			IsTransparent( void ) { return false; }
	virtual ShadowType_t	ShadowCastType( void ) { return SHADOWS_NONE; }
	virtual bool			ShouldReceiveProjectedTextures( int flags ) { return false; }

	virtual void GetRenderBounds( Vector &mins, Vector &maxs )
	{
		mins.Init( -MC_BLOCK_HALF - 1, -MC_BLOCK_HALF - 1, -MC_BLOCK_HALF - 1 );
		maxs.Init( MC_BLOCK_HALF + 1, MC_BLOCK_HALF + 1, MC_BLOCK_HALF + 1 );
	}

	virtual int DrawModel( int flags );

	int m_iBlockItem;
};

IMPLEMENT_CLIENTCLASS_DT( C_MCBlock, DT_MCBlock, CMCBlock )
	RecvPropInt( RECVINFO( m_iBlockItem ) ),
END_RECV_TABLE()

int C_MCBlock::DrawModel( int flags )
{
	const Vector &vecCenter = GetAbsOrigin();

	unsigned char rgb[3];
	MC_GetLightColor( vecCenter, 1.0f, rgb );
	MC_DrawBlock( vecCenter, MC_BLOCK_HALF, m_iBlockItem, rgb );

	// Cracks while the local player is mining this block
	C_BaseHLPlayer *pPlayer = dynamic_cast< C_BaseHLPlayer * >( C_BasePlayer::GetLocalPlayer() );
	if ( pPlayer && pPlayer->m_HL2Local.m_hMCBreakTarget.Get() == this )
	{
		float flProgress = pPlayer->m_HL2Local.m_flMCBreakProgress;
		if ( flProgress > 0.0f )
			MC_DrawCracks( vecCenter, MC_BLOCK_HALF + 0.15f, (int)( flProgress * 10.0f ) );
	}
	return 1;
}

//=============================================================================
// C_MCItem
//=============================================================================
class C_MCItem : public C_BaseEntity
{
	DECLARE_CLASS( C_MCItem, C_BaseEntity );
public:
	DECLARE_CLIENTCLASS();

	C_MCItem() : m_iItem( 0 ), m_iCount( 0 ), m_flSpawnTime( -1.0f ) {}

	virtual bool			ShouldDraw( void ) { return !IsDormant() && m_iItem != MC_ITEM_NONE; }
	virtual RenderGroup_t	GetRenderGroup( void ) { return RENDER_GROUP_OPAQUE_ENTITY; }
	virtual bool			IsTransparent( void ) { return false; }
	virtual ShadowType_t	ShadowCastType( void ) { return SHADOWS_NONE; }
	virtual bool			ShouldReceiveProjectedTextures( int flags ) { return false; }

	virtual void GetRenderBounds( Vector &mins, Vector &maxs )
	{
		mins.Init( -12, -12, -2 );
		maxs.Init( 12, 12, 24 );
	}

	virtual int DrawModel( int flags );

	int		m_iItem;
	int		m_iCount;
	float	m_flSpawnTime;
};

IMPLEMENT_CLIENTCLASS_DT( C_MCItem, DT_MCItem, CMCItem )
	RecvPropInt( RECVINFO( m_iItem ) ),
	RecvPropInt( RECVINFO( m_iCount ) ),
END_RECV_TABLE()

int C_MCItem::DrawModel( int flags )
{
	if ( m_flSpawnTime < 0.0f )
		m_flSpawnTime = gpGlobals->curtime - RandomFloat( 0.0f, 3.0f );

	// Minecraft: a quarter-size item, bobbing and turning slowly
	const float flAge = gpGlobals->curtime - m_flSpawnTime;
	const float flBob = sinf( flAge * 2.0f ) * 2.0f + 2.0f;
	const float flSpin = flAge * 57.0f;
	const float flSize = MC_IsBlock( m_iItem ) ? MC_BLOCK_SIZE * 0.25f : MC_BLOCK_SIZE * 0.5f;

	Vector vecCenter = GetAbsOrigin() + Vector( 0, 0, flSize * 0.5f + 2.0f + flBob );

	unsigned char rgb[3];
	MC_GetLightColor( vecCenter, 1.0f, rgb );

	// Stacks show a couple of copies like Minecraft
	int iCopies = m_iCount > 32 ? 3 : ( m_iCount > 1 ? 2 : 1 );
	for ( int i = 0; i < iCopies; i++ )
	{
		Vector vecOffset( i * 2.0f, i * 1.5f, i * 2.5f );
		MCMatrix_t xform =
			MCMatrix_t::Basis( Vector( 1, 0, 0 ), Vector( 0, 0, 1 ), Vector( 0, -1, 0 ), vecCenter + vecOffset ) *
			MCMatrix_t::RotY( flSpin ) *
			MCMatrix_t::Scale( flSize );
		MC_DrawItemModel( xform, m_iItem, rgb );
	}
	return 1;
}
