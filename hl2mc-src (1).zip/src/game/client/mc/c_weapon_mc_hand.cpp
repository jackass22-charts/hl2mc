//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Client side of weapon_mc_hand. Never drawn as a model; the arm and
//			held item are drawn by mc_hand_render.cpp.
//
//=============================================================================//

#include "cbase.h"
#include "c_basehlcombatweapon.h"
#include "c_weapon__stubs.h"

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"

class C_WeaponMCHand : public C_BaseHLCombatWeapon
{
	DECLARE_CLASS( C_WeaponMCHand, C_BaseHLCombatWeapon );
public:
	DECLARE_PREDICTABLE();
	DECLARE_CLIENTCLASS();

	C_WeaponMCHand() {}

	virtual bool	VisibleInWeaponSelection( void ) { return false; }
	virtual bool	ShouldDraw( void ) { return false; }
	virtual bool	ShouldDrawPickup( void ) { return false; }	// no pickup icon when the hand is (re)given
	virtual bool	HasAnyAmmo( void ) { return true; }
	virtual void	ItemPostFrame( void ) {}
	virtual void	PrimaryAttack( void ) {}
	virtual void	SecondaryAttack( void ) {}

private:
	C_WeaponMCHand( const C_WeaponMCHand & );
};

STUB_WEAPON_CLASS_IMPLEMENT( weapon_mc_hand, C_WeaponMCHand );

IMPLEMENT_CLIENTCLASS_DT( C_WeaponMCHand, DT_WeaponMCHand, CWeaponMCHand )
END_RECV_TABLE()
