//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Drawing items in GUI slots (hotbar, inventory screen): isometric
//			block icons, tool sprites, HL2 weapon glyphs, stack counts and
//			durability bars.
//
//=============================================================================//

#ifndef MC_ITEMICONS_H
#define MC_ITEMICONS_H
#ifdef _WIN32
#pragma once
#endif

#include "mc/mc_sprites.h"

class C_BasePlayer;

// 16x16 icon with its top-left at GUI position (x, y)
void		MC_DrawItemIcon( int iItem, int x, int y, const MCGui_t &gui, C_BasePlayer *pPlayer, int iAlpha = 255 );

// Stack count and tool wear bar, drawn over the icon
void		MC_DrawItemDecorations( int iItem, int iCount, int iDamage, int x, int y, const MCGui_t &gui );

// Name shown when switching to the item and in tooltips
void		MC_GetItemDisplayName( int iItem, char *pszOut, int iSize );

#endif // MC_ITEMICONS_H
