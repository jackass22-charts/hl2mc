//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Small immediate-mode helpers for drawing textured boxes and quads
//			(blocks, dropped items, the first-person arm and held items) with
//			the textures that mc_extract_textures.py converts.
//
//=============================================================================//

#ifndef MC_RENDER_H
#define MC_RENDER_H
#ifdef _WIN32
#pragma once
#endif

#include "materialsystem/imaterial.h"

// Box faces in box-local space, which is y-up like Minecraft (x right, y up, z toward the viewer)
enum MCFace_t
{
	MC_FACE_POS_X = 0,
	MC_FACE_NEG_X,
	MC_FACE_POS_Y,	// top
	MC_FACE_NEG_Y,	// bottom
	MC_FACE_POS_Z,
	MC_FACE_NEG_Z,
	MC_FACE_COUNT
};

// Row-major 4x4 transform (same convention as the preview script)
struct MCMatrix_t
{
	float m[4][4];

	static MCMatrix_t Identity( void );
	static MCMatrix_t Translate( float x, float y, float z );
	static MCMatrix_t Scale( float s );
	static MCMatrix_t RotX( float flDegrees );
	static MCMatrix_t RotY( float flDegrees );
	static MCMatrix_t RotZ( float flDegrees );
	static MCMatrix_t Basis( const Vector &x, const Vector &y, const Vector &z, const Vector &origin );

	MCMatrix_t operator*( const MCMatrix_t &b ) const;
	Vector Transform( const Vector &p ) const;
	Vector Rotate( const Vector &v ) const;
};

struct MCFaceUV_t
{
	float u0, v0, u1, v1;	// v0 = top edge of the face as drawn
};

// Material for a world texture (mc/block/<name>, mc/item/<name>, mc/entity/skin...).
// Returns NULL if the player hasn't extracted that texture.
IMaterial	*MC_GetMaterial( const char *pszPath );

// Light at a point as a 0-255 brightness color (gamma corrected, with a small ambient floor)
void		MC_GetLightColor( const Vector &vecPos, float flScale, unsigned char out[3] );

// Draw a box in world space through a transform from box-local space.
// pMaterials/pUVs are per face (MCFace_t order); NULL material skips the face.
void		MC_DrawBox( const MCMatrix_t &xform, const Vector &mins, const Vector &maxs,
						IMaterial * const *pMaterials, const MCFaceUV_t *pUVs,
						const unsigned char rgb[3], bool bShadeFaces );

// Axis-aligned world block (top/side/bottom textures), with Minecraft's face shading
void		MC_DrawBlock( const Vector &vecCenter, float flHalfSize, int iItem, const unsigned char rgb[3] );

// The break-progress cracks over a block (stage 0-9)
void		MC_DrawCracks( const Vector &vecCenter, float flHalfSize, int iStage );

// A flat, double-sided textured square (item sprites)
void		MC_DrawQuad( const MCMatrix_t &xform, IMaterial *pMaterial, const unsigned char rgb[3] );

// Draw an item as it looks in the world: a mini block or a flat sprite
void		MC_DrawItemModel( const MCMatrix_t &xform, int iItem, const unsigned char rgb[3] );

#endif // MC_RENDER_H
