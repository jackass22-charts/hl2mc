//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Minecraft-style HUD.
//			- CHudMCStatus:    hearts, armor (suit battery), hunger, air bubbles, XP bar + level
//			- CHudMCHotbar:    9-slot hotbar of your weapons with ammo as stack counts,
//			                   selected-item name, plus the hotbar console commands
//			- CHudMCCrosshair: the crosshair
//
//			Layout follows Minecraft's GUI pixel grid (see MC_GetGui). Sprites come
//			from the player's own Minecraft install via mc_extract_textures.py;
//			without them the HUD falls back to plain placeholder shapes.
//
//=============================================================================//

#include "cbase.h"
#include "hud.h"
#include "hudelement.h"
#include "hud_macros.h"
#include "iclientmode.h"
#include "iinput.h"
#include "c_basehlplayer.h"
#include "mc/mc_shared.h"
#include "mc/mc_sprites.h"
#include "mc/mc_items.h"
#include "mc/mc_itemicons.h"
#include <vgui_controls/Panel.h>
#include <vgui/ISurface.h>
#include <vgui/ILocalize.h>

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"

using namespace vgui;

ConVar mc_hud( "mc_hud", "1", FCVAR_ARCHIVE, "Use the Minecraft-style HUD (hides the HL2 health, suit, ammo, weapon selection and crosshair)." );
ConVar mc_hud_icon_color( "mc_hud_icon_color", "255 236 160", FCVAR_ARCHIVE, "Tint for HL2 weapon icons in the hotbar (R G B)." );

static inline bool MC_HudActive( void )
{
	return MC_IsEnabled() && mc_hud.GetBool();
}

// Deterministic per-tick "random" so jitter changes 20 times a second, like the game, not every frame
static inline int MC_TickRand( int iTick, int iSalt, int iRange )
{
	unsigned int h = (unsigned int)iTick * 2654435761u ^ (unsigned int)( iSalt + 1 ) * 2246822519u;
	h ^= h >> 13;
	h *= 3266489917u;
	h ^= h >> 16;
	return (int)( h % (unsigned int)iRange );
}

static inline int MC_CurrentTick( void )
{
	return (int)( gpGlobals->curtime / MC_TICK_INTERVAL );
}

//-----------------------------------------------------------------------------
// Draw a sprite, or a flat placeholder if the player hasn't extracted textures.
//-----------------------------------------------------------------------------
static void MC_Sprite( const char *pszName, int x, int y, const MCGui_t &gui, int w, int h, Color placeholder, float flFraction = 1.0f )
{
	if ( CMCSprites::Get().DrawSprite( pszName, x, y, gui, Color( 255, 255, 255, 255 ), flFraction ) )
		return;

	if ( placeholder.a() > 0 )
	{
		int pw = (int)( w * clamp( flFraction, 0.0f, 1.0f ) );
		if ( pw > 0 )
			CMCSprites::FillRect( x, y, pw, h, gui, placeholder );
	}
}

//=============================================================================
// Hotbar selection.
// With the Minecraft inventory (mc_inventory 1) the hotbar is inventory slots
// 0-8 and selection happens on the server. Without it, the hotbar lists the
// HL2 weapons directly.
//=============================================================================
static int MC_WeaponSort( C_BaseCombatWeapon * const *a, C_BaseCombatWeapon * const *b )
{
	if ( (*a)->GetSlot() != (*b)->GetSlot() )
		return (*a)->GetSlot() - (*b)->GetSlot();
	return (*a)->GetPosition() - (*b)->GetPosition();
}

static void MC_GetWeapons( C_BasePlayer *pPlayer, CUtlVector< C_BaseCombatWeapon * > &list )
{
	list.RemoveAll();
	if ( !pPlayer )
		return;

	for ( int i = 0; i < pPlayer->WeaponCount(); i++ )
	{
		C_BaseCombatWeapon *pWeapon = pPlayer->GetWeapon( i );
		if ( pWeapon && pWeapon->VisibleInWeaponSelection() )
			list.AddToTail( pWeapon );
	}
	list.Sort( MC_WeaponSort );
}

static void MC_WeaponModeSelect( int iIndex, int iDir )
{
	C_BasePlayer *pPlayer = C_BasePlayer::GetLocalPlayer();
	CUtlVector< C_BaseCombatWeapon * > list;
	MC_GetWeapons( pPlayer, list );
	if ( !pPlayer || list.Count() == 0 )
		return;

	if ( iDir != 0 )
	{
		int iStart = list.Find( pPlayer->GetActiveWeapon() );
		if ( iStart < 0 )
			iStart = iDir > 0 ? -1 : 0;
		iIndex = ( iStart + iDir + list.Count() ) % list.Count();
	}

	if ( list.IsValidIndex( iIndex ) && list[iIndex]->CanBeSelected() )
		::input->MakeWeaponSelection( list[iIndex] );
}

static int MC_SelectedSlot( void )
{
	C_BaseHLPlayer *pPlayer = dynamic_cast< C_BaseHLPlayer * >( C_BasePlayer::GetLocalPlayer() );
	return pPlayer ? clamp( pPlayer->m_HL2Local.m_iMCSelected, 0, 8 ) : 0;
}

CON_COMMAND( mc_hotbar, "Select hotbar slot 1-9." )
{
	if ( args.ArgC() < 2 )
		return;
	int iSlot = atoi( args[1] ) - 1;
	if ( iSlot < 0 || iSlot > 8 )
		return;

	if ( mc_inventory.GetBool() )
		engine->ClientCmd( VarArgs( "mc_select %d\n", iSlot ) );
	else
		MC_WeaponModeSelect( iSlot, 0 );
}

static void MC_HotbarStep( int iDir )
{
	if ( mc_inventory.GetBool() )
		engine->ClientCmd( VarArgs( "mc_select %d\n", ( MC_SelectedSlot() + iDir + 9 ) % 9 ) );
	else
		MC_WeaponModeSelect( 0, iDir );
}

CON_COMMAND( mc_hotbar_next, "Select the next hotbar slot (mouse wheel down)." ) { MC_HotbarStep( 1 ); }
CON_COMMAND( mc_hotbar_prev, "Select the previous hotbar slot (mouse wheel up)." ) { MC_HotbarStep( -1 ); }

//=============================================================================
// Status bars: hearts, armor, food, air, experience
//=============================================================================
class CHudMCStatus : public CHudElement, public vgui::Panel
{
	DECLARE_CLASS_SIMPLE( CHudMCStatus, vgui::Panel );

public:
	CHudMCStatus( const char *pElementName );

	virtual void	Init( void );
	virtual void	Reset( void );
	virtual bool	ShouldDraw( void );
	virtual void	OnThink( void );
	virtual void	Paint( void );
	virtual void	ApplySchemeSettings( vgui::IScheme *pScheme );

private:
	void	PaintHearts( C_BaseHLPlayer *pPlayer, const MCGui_t &gui, int left, int top, int iTick );
	void	PaintArmor( C_BaseHLPlayer *pPlayer, const MCGui_t &gui, int left, int top );
	void	PaintFood( C_BaseHLPlayer *pPlayer, const MCGui_t &gui, int right, int top, int iTick );
	void	PaintAir( C_BaseHLPlayer *pPlayer, const MCGui_t &gui, int right, int top );
	void	PaintExperience( C_BaseHLPlayer *pPlayer, const MCGui_t &gui );

	int		m_iLastHealth;		// MC health points last frame
	int		m_iDisplayHealth;	// health shown by the blinking "lost" hearts
	float	m_flLastHealthTime;
	float	m_flBlinkUntil;
};

DECLARE_HUDELEMENT( CHudMCStatus );

CHudMCStatus::CHudMCStatus( const char *pElementName ) : CHudElement( pElementName ), BaseClass( NULL, "HudMCStatus" )
{
	SetParent( g_pClientMode->GetViewport() );
	SetHiddenBits( HIDEHUD_HEALTH | HIDEHUD_PLAYERDEAD );
	SetPaintBackgroundEnabled( false );
	SetMouseInputEnabled( false );
	SetKeyBoardInputEnabled( false );
}

void CHudMCStatus::Init( void )
{
	Reset();
}

void CHudMCStatus::Reset( void )
{
	m_iLastHealth = -1;
	m_iDisplayHealth = 0;
	m_flLastHealthTime = 0.0f;
	m_flBlinkUntil = 0.0f;
}

void CHudMCStatus::ApplySchemeSettings( vgui::IScheme *pScheme )
{
	BaseClass::ApplySchemeSettings( pScheme );
	SetBgColor( Color( 0, 0, 0, 0 ) );
	SetPaintBackgroundEnabled( false );
}

bool CHudMCStatus::ShouldDraw( void )
{
	// Creative mode has no health, hunger or XP bars
	C_BaseHLPlayer *pPlayer = dynamic_cast< C_BaseHLPlayer * >( C_BasePlayer::GetLocalPlayer() );
	if ( pPlayer && pPlayer->MC_IsCreative() )
		return false;
	return MC_HudActive() && CHudElement::ShouldDraw();
}

void CHudMCStatus::OnThink( void )
{
	SetBounds( 0, 0, ScreenWidth(), ScreenHeight() );

	C_BasePlayer *pPlayer = C_BasePlayer::GetLocalPlayer();
	if ( !pPlayer )
		return;

	const int iHealth = (int)ceilf( MAX( pPlayer->GetHealth(), 0 ) / MC_HL2HP_PER_MCHP );
	const float flNow = gpGlobals->curtime;

	if ( m_iLastHealth < 0 || flNow < m_flLastHealthTime )	// first frame or level load
	{
		m_iLastHealth = m_iDisplayHealth = iHealth;
		m_flLastHealthTime = flNow;
	}

	// Taking damage makes the hearts flash for a second, showing what you lost
	if ( iHealth < m_iLastHealth )
	{
		m_flLastHealthTime = flNow;
		m_flBlinkUntil = flNow + 1.0f;
	}

	if ( flNow - m_flLastHealthTime > 1.0f )
	{
		m_iDisplayHealth = iHealth;
		m_flLastHealthTime = flNow;
	}

	m_iLastHealth = iHealth;
}

void CHudMCStatus::Paint( void )
{
	C_BaseHLPlayer *pPlayer = dynamic_cast< C_BaseHLPlayer * >( C_BasePlayer::GetLocalPlayer() );
	if ( !pPlayer )
		return;

	const MCGui_t gui = MC_GetGui();
	const int iTick = MC_CurrentTick();
	const int cx = gui.w / 2;
	const int top = gui.h - 39;

	PaintExperience( pPlayer, gui );
	PaintHearts( pPlayer, gui, cx - 91, top, iTick );
	PaintArmor( pPlayer, gui, cx - 91, top - 10 );
	PaintFood( pPlayer, gui, cx + 91, top, iTick );
	PaintAir( pPlayer, gui, cx + 91, top - 10 );
}

void CHudMCStatus::PaintHearts( C_BaseHLPlayer *pPlayer, const MCGui_t &gui, int left, int top, int iTick )
{
	const int iHealth = (int)ceilf( MAX( pPlayer->GetHealth(), 0 ) / MC_HL2HP_PER_MCHP );
	// The client doesn't receive the player's max health in HL2, so use the HL2 maximum (100 = 20 points = 10 hearts)
	const int iHearts = 10;

	// Blink in 3-tick halves while the flash lasts
	const int iBlinkTicks = (int)( ( m_flBlinkUntil - gpGlobals->curtime ) / MC_TICK_INTERVAL );
	const bool bBlink = iBlinkTicks > 0 && ( ( iBlinkTicks / 3 ) % 2 ) == 1;

	for ( int i = 0; i < iHearts; i++ )
	{
		const int x = left + i * 8;
		int y = top;

		// Low health: hearts jiggle
		if ( iHealth <= 4 )
			y += MC_TickRand( iTick, i, 2 );

		const int j = i * 2;

		MC_Sprite( bBlink ? "heart_container_blinking" : "heart_container", x, y, gui, 9, 9,
				   bBlink ? Color( 255, 255, 255, 200 ) : Color( 30, 0, 0, 200 ) );

		if ( bBlink && j < m_iDisplayHealth )
		{
			const bool bHalf = j + 1 == m_iDisplayHealth;
			MC_Sprite( bHalf ? "heart_half_blinking" : "heart_full_blinking", x, y, gui, bHalf ? 5 : 9, 9, Color( 255, 200, 200, 255 ) );
		}

		if ( j < iHealth )
		{
			const bool bHalf = j + 1 == iHealth;
			MC_Sprite( bHalf ? "heart_half" : "heart_full", x, y, gui, bHalf ? 5 : 9, 9, Color( 220, 20, 20, 255 ) );
		}
	}
}

void CHudMCStatus::PaintArmor( C_BaseHLPlayer *pPlayer, const MCGui_t &gui, int left, int top )
{
	// The HEV suit battery is the armor bar: 100 battery = 20 armor points
	const int iArmor = (int)ceilf( MAX( pPlayer->m_HL2Local.m_iMCArmor, 0 ) / MC_HL2HP_PER_MCHP );
	if ( iArmor <= 0 )
		return;

	for ( int i = 0; i < 10; i++ )
	{
		const int x = left + i * 8;
		const int j = i * 2 + 1;

		if ( j < iArmor )
			MC_Sprite( "armor_full", x, top, gui, 9, 9, Color( 200, 200, 210, 255 ) );
		else if ( j == iArmor )
			MC_Sprite( "armor_half", x, top, gui, 5, 9, Color( 200, 200, 210, 255 ) );
		else
			MC_Sprite( "armor_empty", x, top, gui, 9, 9, Color( 40, 40, 40, 160 ) );
	}
}

void CHudMCStatus::PaintFood( C_BaseHLPlayer *pPlayer, const MCGui_t &gui, int right, int top, int iTick )
{
	const int iFood = pPlayer->m_HL2Local.m_iMCFood;
	const float flSat = pPlayer->m_HL2Local.m_flMCSaturation;

	for ( int i = 0; i < 10; i++ )
	{
		const int x = right - i * 8 - 9;
		int y = top;

		// Out of saturation: the bar shakes, faster the hungrier you are
		if ( flSat <= 0.0f && ( iTick % ( iFood * 3 + 1 ) ) == 0 )
			y += MC_TickRand( iTick, 100 + i, 3 ) - 1;

		MC_Sprite( "food_empty", x, y, gui, 9, 9, Color( 30, 20, 10, 200 ) );

		const int j = i * 2 + 1;
		if ( j < iFood )
			MC_Sprite( "food_full", x, y, gui, 9, 9, Color( 190, 120, 50, 255 ) );
		else if ( j == iFood )
			MC_Sprite( "food_half", x, y, gui, 5, 9, Color( 190, 120, 50, 255 ) );
	}
}

void CHudMCStatus::PaintAir( C_BaseHLPlayer *pPlayer, const MCGui_t &gui, int right, int top )
{
	const int iAir = clamp( pPlayer->m_HL2Local.m_iMCAir, 0, MC_MAX_AIR );
	const bool bUnderwater = pPlayer->GetWaterLevel() == 3;
	if ( !bUnderwater && iAir >= MC_MAX_AIR )
		return;

	const int iFull = (int)ceil( ( iAir - 2 ) * 10.0 / MC_MAX_AIR );
	const int iPopping = (int)ceil( iAir * 10.0 / MC_MAX_AIR ) - iFull;
	const bool bHasEmpty = CMCSprites::Get().Has( "air_empty" );

	for ( int i = 0; i < 10; i++ )
	{
		const int x = right - i * 8 - 9;
		if ( i < iFull )
			MC_Sprite( "air", x, top, gui, 9, 9, Color( 80, 160, 255, 255 ) );
		else if ( i < iFull + iPopping )
			MC_Sprite( "air_bursting", x, top, gui, 9, 9, Color( 160, 210, 255, 255 ) );
		else if ( bHasEmpty )
			MC_Sprite( "air_empty", x, top, gui, 9, 9, Color( 0, 0, 0, 0 ) );
	}
}

void CHudMCStatus::PaintExperience( C_BaseHLPlayer *pPlayer, const MCGui_t &gui )
{
	const int cx = gui.w / 2;
	const int iLevel = pPlayer->m_HL2Local.m_iMCXPLevel;
	const float flProgress = pPlayer->m_HL2Local.m_flMCXPProgress;

	// Bar
	const int y = gui.h - 32 + 3;
	MC_Sprite( "xp_bar_background", cx - 91, y, gui, 182, 5, Color( 20, 20, 20, 200 ) );
	const int iFilled = (int)( flProgress * 183.0f );
	if ( iFilled > 0 )
		MC_Sprite( "xp_bar_progress", cx - 91, y, gui, 182, 5, Color( 128, 255, 32, 255 ), MIN( iFilled, 182 ) / 182.0f );

	// Level number: green with a 1px black outline
	if ( iLevel > 0 )
	{
		char szLevel[16];
		Q_snprintf( szLevel, sizeof( szLevel ), "%d", iLevel );

		CMCSprites &sprites = CMCSprites::Get();
		const int tx = ( gui.w - sprites.TextWidth( szLevel, gui ) ) / 2;
		const int ty = gui.h - 31 - 4;
		const Color black( 0, 0, 0, 255 );
		sprites.DrawString( szLevel, tx + 1, ty, gui, black, false );
		sprites.DrawString( szLevel, tx - 1, ty, gui, black, false );
		sprites.DrawString( szLevel, tx, ty + 1, gui, black, false );
		sprites.DrawString( szLevel, tx, ty - 1, gui, black, false );
		sprites.DrawString( szLevel, tx, ty, gui, Color( 0x80, 0xFF, 0x20, 255 ), false );
	}
}

//=============================================================================
// Hotbar
//=============================================================================
class CHudMCHotbar : public CHudElement, public vgui::Panel
{
	DECLARE_CLASS_SIMPLE( CHudMCHotbar, vgui::Panel );

public:
	CHudMCHotbar( const char *pElementName );

	virtual void	Reset( void );
	virtual bool	ShouldDraw( void );
	virtual void	OnThink( void );
	virtual void	Paint( void );
	virtual void	ApplySchemeSettings( vgui::IScheme *pScheme );

private:
	void	PaintItemName( const MCGui_t &gui, bool bCreative );
	void	PaintWeaponMode( C_BasePlayer *pPlayer, const MCGui_t &gui );

	int		m_iLastHeld;
	EHANDLE	m_hLastWeapon;
	float	m_flNameShownAt;
	char	m_szName[64];
};

DECLARE_HUDELEMENT( CHudMCHotbar );

CHudMCHotbar::CHudMCHotbar( const char *pElementName ) : CHudElement( pElementName ), BaseClass( NULL, "HudMCHotbar" )
{
	SetParent( g_pClientMode->GetViewport() );
	SetHiddenBits( HIDEHUD_WEAPONSELECTION | HIDEHUD_PLAYERDEAD );
	SetPaintBackgroundEnabled( false );
	SetMouseInputEnabled( false );
	SetKeyBoardInputEnabled( false );
	Reset();
}

void CHudMCHotbar::Reset( void )
{
	m_iLastHeld = -1;
	m_hLastWeapon = NULL;
	m_flNameShownAt = -100.0f;
	m_szName[0] = 0;
}

void CHudMCHotbar::ApplySchemeSettings( vgui::IScheme *pScheme )
{
	BaseClass::ApplySchemeSettings( pScheme );
	SetBgColor( Color( 0, 0, 0, 0 ) );
	SetPaintBackgroundEnabled( false );
}

bool CHudMCHotbar::ShouldDraw( void )
{
	return MC_HudActive() && CHudElement::ShouldDraw();
}

void CHudMCHotbar::OnThink( void )
{
	SetBounds( 0, 0, ScreenWidth(), ScreenHeight() );

	C_BaseHLPlayer *pPlayer = dynamic_cast< C_BaseHLPlayer * >( C_BasePlayer::GetLocalPlayer() );
	if ( !pPlayer )
		return;

	// Show the held item's name for 2 seconds after it changes
	if ( mc_inventory.GetBool() )
	{
		int iHeld = pPlayer->m_HL2Local.m_iMCInvItem[ MC_SelectedSlot() ];
		if ( iHeld != m_iLastHeld )
		{
			m_iLastHeld = iHeld;
			if ( iHeld != MC_ITEM_NONE )
			{
				MC_GetItemDisplayName( iHeld, m_szName, sizeof( m_szName ) );
				m_flNameShownAt = gpGlobals->curtime;
			}
			else
			{
				m_flNameShownAt = -100.0f;
			}
		}
	}
	else
	{
		C_BaseCombatWeapon *pActive = pPlayer->GetActiveWeapon();
		if ( pActive && pActive != m_hLastWeapon.Get() )
		{
			MC_GetItemDisplayName( MC_WeaponItemForClass( pActive->GetName() ), m_szName, sizeof( m_szName ) );
			m_flNameShownAt = gpGlobals->curtime;
		}
		m_hLastWeapon = pActive;
	}
}

void CHudMCHotbar::PaintItemName( const MCGui_t &gui, bool bCreative )
{
	// 2 seconds total, fading over the last half second
	const float flAge = gpGlobals->curtime - m_flNameShownAt;
	if ( flAge < 0.0f || flAge > 2.0f || !m_szName[0] )
		return;

	int iAlpha = clamp( (int)( ( 2.0f - flAge ) / 0.5f * 255.0f ), 0, 255 );
	if ( iAlpha < 5 )
		return;

	CMCSprites &sprites = CMCSprites::Get();
	const int x = ( gui.w - sprites.TextWidth( m_szName, gui ) ) / 2;
	const int y = gui.h - 59 + ( bCreative ? 14 : 0 );	// Creative has no status bars, so the name sits lower
	sprites.DrawString( m_szName, x, y, gui, Color( 255, 255, 255, iAlpha ), true );
}

static int MC_WeaponAmmoCount( C_BasePlayer *pPlayer, C_BaseCombatWeapon *pWeapon )
{
	if ( !pWeapon || !pWeapon->UsesPrimaryAmmo() )
		return -1;
	int iCount = pPlayer->GetAmmoCount( pWeapon->GetPrimaryAmmoType() );
	if ( pWeapon->UsesClipsForAmmo1() )
		iCount += MAX( pWeapon->Clip1(), 0 );
	return iCount;
}

void CHudMCHotbar::Paint( void )
{
	C_BaseHLPlayer *pPlayer = dynamic_cast< C_BaseHLPlayer * >( C_BasePlayer::GetLocalPlayer() );
	if ( !pPlayer )
		return;

	const MCGui_t gui = MC_GetGui();
	const int cx = gui.w / 2;

	if ( !mc_inventory.GetBool() )
	{
		PaintWeaponMode( pPlayer, gui );
		PaintItemName( gui, false );
		return;
	}

	// Bar and selection frame
	MC_Sprite( "hotbar", cx - 91, gui.h - 22, gui, 182, 22, Color( 0, 0, 0, 120 ) );

	const int iSelected = MC_SelectedSlot();
	const int sx = cx - 91 - 1 + iSelected * 20;
	const int sy = gui.h - 22 - 1;
	if ( !CMCSprites::Get().DrawSprite( "hotbar_selection", sx, sy, gui ) )
	{
		const Color white( 255, 255, 255, 255 );
		CMCSprites::FillRect( sx, sy, 24, 1, gui, white );
		CMCSprites::FillRect( sx, sy + 23, 24, 1, gui, white );
		CMCSprites::FillRect( sx, sy, 1, 24, gui, white );
		CMCSprites::FillRect( sx + 23, sy, 1, 24, gui, white );
	}

	// Items in slots 0-8
	for ( int iSlot = 0; iSlot < 9; iSlot++ )
	{
		const int iItem = pPlayer->m_HL2Local.m_iMCInvItem[iSlot];
		if ( iItem == MC_ITEM_NONE )
			continue;

		const int x = cx - 90 + iSlot * 20 + 2;
		const int y = gui.h - 16 - 3;
		MC_DrawItemIcon( iItem, x, y, gui, pPlayer );

		int iCount = pPlayer->m_HL2Local.m_iMCInvCount[iSlot];
		const char *pszClass = MC_WeaponClassForItem( iItem );
		if ( pszClass )
		{
			// Weapons show their ammo where a stack count would be
			int iAmmo = MC_WeaponAmmoCount( pPlayer, pPlayer->Weapon_OwnsThisType( pszClass ) );
			iCount = iAmmo;
			if ( iAmmo == 0 )
			{
				CMCSprites::Get().DrawString( "0", x + 19 - 2 - CMCSprites::Get().TextWidth( "0", gui ), y + 9, gui, Color( 255, 85, 85, 255 ), true );
				continue;
			}
		}
		MC_DrawItemDecorations( iItem, iCount, pPlayer->m_HL2Local.m_iMCInvDamage[iSlot], x, y, gui );
	}

	PaintItemName( gui, pPlayer->MC_IsCreative() );
}

// mc_inventory 0: the hotbar just lists the HL2 weapons
void CHudMCHotbar::PaintWeaponMode( C_BasePlayer *pPlayer, const MCGui_t &gui )
{
	const int cx = gui.w / 2;
	CUtlVector< C_BaseCombatWeapon * > list;
	MC_GetWeapons( pPlayer, list );

	MC_Sprite( "hotbar", cx - 91, gui.h - 22, gui, 182, 22, Color( 0, 0, 0, 120 ) );

	int iActive = list.Find( pPlayer->GetActiveWeapon() );
	if ( iActive >= 0 && iActive < 9 )
		CMCSprites::Get().DrawSprite( "hotbar_selection", cx - 91 - 1 + iActive * 20, gui.h - 22 - 1, gui );

	for ( int i = 0; i < 9 && i < list.Count(); i++ )
	{
		const int x = cx - 90 + i * 20 + 2;
		const int y = gui.h - 16 - 3;
		int iItem = MC_WeaponItemForClass( list[i]->GetName() );
		if ( iItem != MC_ITEM_NONE )
			MC_DrawItemIcon( iItem, x, y, gui, pPlayer );
		int iAmmo = MC_WeaponAmmoCount( pPlayer, list[i] );
		if ( iAmmo >= 0 )
			MC_DrawItemDecorations( MC_ITEM_NONE, iAmmo, 0, x, y, gui );
	}
}


//=============================================================================
// Crosshair
//=============================================================================
class CHudMCCrosshair : public CHudElement, public vgui::Panel
{
	DECLARE_CLASS_SIMPLE( CHudMCCrosshair, vgui::Panel );

public:
	CHudMCCrosshair( const char *pElementName ) : CHudElement( pElementName ), BaseClass( NULL, "HudMCCrosshair" )
	{
		SetParent( g_pClientMode->GetViewport() );
		SetHiddenBits( HIDEHUD_PLAYERDEAD | HIDEHUD_CROSSHAIR );
		SetPaintBackgroundEnabled( false );
		SetMouseInputEnabled( false );
		SetKeyBoardInputEnabled( false );
	}

	virtual void ApplySchemeSettings( vgui::IScheme *pScheme )
	{
		BaseClass::ApplySchemeSettings( pScheme );
		SetBgColor( Color( 0, 0, 0, 0 ) );
		SetPaintBackgroundEnabled( false );
	}

	virtual bool ShouldDraw( void )
	{
		static ConVarRef crosshair( "crosshair" );
		if ( !MC_HudActive() || !crosshair.GetBool() || !CHudElement::ShouldDraw() )
			return false;

		// Hide while zoomed or driving, like HL2's own crosshair
		C_BaseHLPlayer *pPlayer = dynamic_cast< C_BaseHLPlayer * >( C_BasePlayer::GetLocalPlayer() );
		if ( !pPlayer || pPlayer->IsInAVehicle() || pPlayer->m_HL2Local.m_bZooming )
			return false;

		return g_pClientMode->ShouldDrawCrosshair();
	}

	virtual void OnThink( void )
	{
		SetBounds( 0, 0, ScreenWidth(), ScreenHeight() );
	}

	virtual void Paint( void )
	{
		const MCGui_t gui = MC_GetGui();
		const int x = ( gui.w - 15 ) / 2;
		const int y = ( gui.h - 15 ) / 2;

		if ( CMCSprites::Get().DrawSprite( "crosshair", x, y, gui, Color( 255, 255, 255, 220 ) ) )
			return;

		// Placeholder plus
		const Color clr( 255, 255, 255, 220 );
		CMCSprites::FillRect( x + 7, y, 1, 15, gui, clr );
		CMCSprites::FillRect( x, y + 7, 15, 1, gui, clr );
	}
};

DECLARE_HUDELEMENT( CHudMCCrosshair );
