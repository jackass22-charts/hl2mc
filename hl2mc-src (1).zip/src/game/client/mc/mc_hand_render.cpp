//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: First-person Steve arm and held items, drawn in the viewmodel pass
//			while weapon_mc_hand is active. Empty hand shows the arm (skin from
//			the player's own Minecraft install), blocks show as a held cube,
//			tools as their item sprite. Includes the swing and equip motions.
//
//			Poses are in Minecraft camera space (x right, y up, camera looks
//			down -z) with Minecraft's 70 degree vertical FOV.
//
//=============================================================================//

#include "cbase.h"
#include "c_basehlplayer.h"
#include "view_shared.h"
#include "ivrenderview.h"
#include "iinput.h"
#include "mc/mc_shared.h"
#include "mc/mc_items.h"
#include "mc/mc_render.h"

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"

ConVar mc_hand( "mc_hand", "1", FCVAR_ARCHIVE, "Draw the Minecraft first-person arm / held item." );
ConVar mc_hand_offset_x( "mc_hand_offset_x", "0", FCVAR_ARCHIVE, "Move the first-person arm right (+) / left (-)." );
ConVar mc_hand_offset_y( "mc_hand_offset_y", "0", FCVAR_ARCHIVE, "Move the first-person arm up (+) / down (-)." );
ConVar mc_hand_offset_z( "mc_hand_offset_z", "0", FCVAR_ARCHIVE, "Move the first-person arm away (+) / closer (-)." );

#define PX ( 1.0f / 16.0f )
#define MC_HAND_VFOV		70.0f
#define MC_HAND_SCALE		10.0f	// Hammer units per Minecraft unit in the hand view
#define MC_SWING_TIME		0.30f	// 6 ticks
#define MC_EQUIP_DOWN		0.10f
#define MC_EQUIP_UP			0.15f

static float	s_flSwingStart = -100.0f;
static int		s_iLastSwingCount = -1;
static float	s_flEquipStart = -100.0f;
static int		s_iShownItem = -1;
static int		s_iPendingItem = -1;
static float	s_flBobPhase = 0.0f;

//-----------------------------------------------------------------------------
// Poses (kept in sync with the offline preview used to tune them)
//-----------------------------------------------------------------------------
static MCMatrix_t MC_ArmPose( float swing, float equip )
{
	const float sq = sqrtf( swing );
	Vector vecFist( 0.42f - 0.22f * sinf( sq * M_PI_F ) + mc_hand_offset_x.GetFloat(),
					-0.32f + 0.12f * sinf( sq * 2.0f * M_PI_F ) - 0.6f * equip + mc_hand_offset_y.GetFloat(),
					-1.05f - 0.20f * sinf( swing * M_PI_F ) - mc_hand_offset_z.GetFloat() );

	// Arm runs from the fist back toward the lower-right corner of the screen
	Vector vecDir( 0.38f, -0.55f, 0.72f );
	Vector yAxis = -vecDir;
	VectorNormalize( yAxis );
	Vector xAxis = CrossProduct( yAxis, Vector( 0, 0, 1 ) );
	VectorNormalize( xAxis );
	Vector zAxis = CrossProduct( xAxis, yAxis );

	return MCMatrix_t::Translate( vecFist.x, vecFist.y, vecFist.z ) *
		   MCMatrix_t::RotY( -25.0f * sinf( sq * M_PI_F ) ) *
		   MCMatrix_t::RotX( -20.0f * sinf( swing * swing * M_PI_F ) ) *
		   MCMatrix_t::Basis( xAxis, yAxis, zAxis, vec3_origin ) *
		   MCMatrix_t::RotY( 25.0f );
}

static MCMatrix_t MC_ItemBase( float x, float y, float z, float swing, float equip )
{
	const float sq = sqrtf( swing );
	return MCMatrix_t::Translate( x - 0.30f * sinf( sq * M_PI_F ) + mc_hand_offset_x.GetFloat(),
								  y + 0.15f * sinf( sq * 2.0f * M_PI_F ) - 0.6f * equip + mc_hand_offset_y.GetFloat(),
								  z - 0.20f * sinf( swing * M_PI_F ) - mc_hand_offset_z.GetFloat() ) *
		   MCMatrix_t::RotY( -30.0f * sinf( sq * M_PI_F ) ) *
		   MCMatrix_t::RotX( -45.0f * sinf( sq * M_PI_F ) );
}

static MCMatrix_t MC_BlockPose( float swing, float equip )
{
	return MC_ItemBase( 0.50f, -0.40f, -0.85f, swing, equip ) *
		   MCMatrix_t::RotY( 45.0f ) *
		   MCMatrix_t::RotX( 12.0f ) *
		   MCMatrix_t::Scale( 0.40f );
}

static MCMatrix_t MC_ToolPose( float swing, float equip )
{
	return MC_ItemBase( 0.50f, -0.36f, -0.95f, swing, equip ) *
		   MCMatrix_t::RotY( 125.0f ) *
		   MCMatrix_t::RotZ( 25.0f ) *
		   MCMatrix_t::Scale( 0.55f );
}

//-----------------------------------------------------------------------------
// Steve's right arm from a 64x64 skin
//-----------------------------------------------------------------------------
static void MC_DrawArm( const MCMatrix_t &xform, const unsigned char rgb[3] )
{
	IMaterial *pSkin = MC_GetMaterial( "mc/entity/skin" );
	unsigned char col[3] = { rgb[0], rgb[1], rgb[2] };
	if ( !pSkin )
	{
		// No skin extracted: a plain skin-colored arm
		pSkin = MC_GetMaterial( "debug/debugdrawflat" );
		col[0] = (unsigned char)( rgb[0] * 0.78f );
		col[1] = (unsigned char)( rgb[1] * 0.58f );
		col[2] = (unsigned char)( rgb[2] * 0.42f );
	}
	if ( !pSkin )
		return;

	IMaterial *pMats[MC_FACE_COUNT] = { pSkin, pSkin, pSkin, pSkin, pSkin, pSkin };
	const float k = 1.0f / 64.0f;
	MCFaceUV_t uvs[MC_FACE_COUNT];
	uvs[MC_FACE_POS_X] = { 48 * k, 32 * k, 52 * k, 20 * k };	// inner side
	uvs[MC_FACE_NEG_X] = { 40 * k, 32 * k, 44 * k, 20 * k };	// outer side
	uvs[MC_FACE_POS_Y] = { 48 * k, 16 * k, 52 * k, 20 * k };	// fist end
	uvs[MC_FACE_NEG_Y] = { 44 * k, 16 * k, 48 * k, 20 * k };	// shoulder end
	uvs[MC_FACE_POS_Z] = { 44 * k, 32 * k, 48 * k, 20 * k };	// front
	uvs[MC_FACE_NEG_Z] = { 52 * k, 32 * k, 56 * k, 20 * k };	// back

	MC_DrawBox( xform, Vector( -2 * PX, -12 * PX, -2 * PX ), Vector( 2 * PX, 0.0f, 2 * PX ), pMats, uvs, col, true );
}

//-----------------------------------------------------------------------------
// Called from CViewRender::DrawViewModels (viewrender.cpp)
//-----------------------------------------------------------------------------
void MC_DrawFirstPersonHand( const CViewSetup &view )
{
	if ( !MC_IsEnabled() || !mc_hand.GetBool() )
		return;

	C_BaseHLPlayer *pPlayer = dynamic_cast< C_BaseHLPlayer * >( C_BasePlayer::GetLocalPlayer() );
	if ( !pPlayer || !pPlayer->IsAlive() || pPlayer->IsInAVehicle() || pPlayer->m_HL2Local.m_bZooming || input->CAM_IsThirdPerson() )
		return;

	C_BaseCombatWeapon *pWeapon = pPlayer->GetActiveWeapon();
	if ( !pWeapon || Q_stricmp( pWeapon->GetName(), "weapon_mc_hand" ) )
		return;

	const float flNow = gpGlobals->curtime;

	// Swing whenever the server counts one (hits, digging, placing)
	const int iSwingCount = pPlayer->m_HL2Local.m_iMCSwingCount;
	if ( s_iLastSwingCount < 0 )
		s_iLastSwingCount = iSwingCount;
	if ( iSwingCount != s_iLastSwingCount )
	{
		s_iLastSwingCount = iSwingCount;
		if ( flNow - s_flSwingStart > MC_SWING_TIME * 0.5f )
			s_flSwingStart = flNow;
	}
	float flSwing = ( flNow - s_flSwingStart ) / MC_SWING_TIME;
	if ( flSwing < 0.0f || flSwing >= 1.0f )
		flSwing = 0.0f;

	// Equip: lower the old item, swap, raise the new one
	const int iHeld = pPlayer->m_HL2Local.m_iMCInvItem[ clamp( pPlayer->m_HL2Local.m_iMCSelected, 0, 8 ) ];
	if ( s_iShownItem < 0 )
		s_iShownItem = s_iPendingItem = iHeld;
	if ( iHeld != s_iPendingItem )
	{
		s_iPendingItem = iHeld;
		s_flEquipStart = flNow;
	}
	float flEquip = 0.0f;
	const float t = flNow - s_flEquipStart;
	if ( t < MC_EQUIP_DOWN )
	{
		flEquip = t / MC_EQUIP_DOWN;
	}
	else
	{
		s_iShownItem = s_iPendingItem;
		flEquip = MAX( 0.0f, 1.0f - ( t - MC_EQUIP_DOWN ) / MC_EQUIP_UP );
	}

	// Walking bob
	const float flSpeed = pPlayer->GetAbsVelocity().Length2D();
	const bool bOnGround = ( pPlayer->GetFlags() & FL_ONGROUND ) != 0;
	s_flBobPhase += gpGlobals->frametime * ( bOnGround ? flSpeed : 0.0f ) * 0.035f;
	const float flBobAmount = clamp( flSpeed / 200.0f, 0.0f, 1.0f ) * ( bOnGround ? 1.0f : 0.3f );
	const float flBobX = sinf( s_flBobPhase ) * 0.025f * flBobAmount;
	const float flBobY = -fabsf( cosf( s_flBobPhase ) ) * 0.03f * flBobAmount;

	// Minecraft camera space -> world, around the eye
	Vector vecForward, vecRight, vecUp;
	AngleVectors( view.angles, &vecForward, &vecRight, &vecUp );
	MCMatrix_t camera = MCMatrix_t::Basis( vecRight * MC_HAND_SCALE, vecUp * MC_HAND_SCALE, -vecForward * MC_HAND_SCALE, view.origin ) *
						MCMatrix_t::Translate( flBobX, flBobY, 0.0f );

	unsigned char rgb[3];
	MC_GetLightColor( view.origin, 1.0f, rgb );

	// Our own projection so the hand looks the same at any FOV setting
	CViewSetup handView( view );
	const float flAspect = view.m_flAspectRatio > 0.0f ? view.m_flAspectRatio : engine->GetScreenAspectRatio();
	handView.fov = RAD2DEG( 2.0f * atanf( tanf( DEG2RAD( MC_HAND_VFOV * 0.5f ) ) * flAspect ) );
	handView.m_flAspectRatio = flAspect;
	handView.zNear = 1.0f;
	handView.zFar = 200.0f;

	Frustum frustum;
	render->Push3DView( handView, 0, NULL, frustum );

	const MCItemDef_t *pDef = MC_GetItem( s_iShownItem );
	if ( pDef->kind == MC_KIND_BLOCK )
		MC_DrawItemModel( camera * MC_BlockPose( flSwing, flEquip ), s_iShownItem, rgb );
	else if ( pDef->kind == MC_KIND_TOOL )
		MC_DrawItemModel( camera * MC_ToolPose( flSwing, flEquip ), s_iShownItem, rgb );
	else
		MC_DrawArm( camera * MC_ArmPose( flSwing, flEquip ), rgb );

	render->PopView( frustum );
}
