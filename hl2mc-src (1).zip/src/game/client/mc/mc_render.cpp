//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Immediate-mode drawing of textured boxes and quads.
//
//=============================================================================//

#include "cbase.h"
#include "mc/mc_render.h"
#include "mc/mc_items.h"
#include "materialsystem/imaterialsystem.h"
#include "materialsystem/imesh.h"
#include "utldict.h"

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"

//-----------------------------------------------------------------------------
// Matrices
//-----------------------------------------------------------------------------
MCMatrix_t MCMatrix_t::Identity( void )
{
	MCMatrix_t r;
	for ( int i = 0; i < 4; i++ )
		for ( int j = 0; j < 4; j++ )
			r.m[i][j] = ( i == j ) ? 1.0f : 0.0f;
	return r;
}

MCMatrix_t MCMatrix_t::Translate( float x, float y, float z )
{
	MCMatrix_t r = Identity();
	r.m[0][3] = x;
	r.m[1][3] = y;
	r.m[2][3] = z;
	return r;
}

MCMatrix_t MCMatrix_t::Scale( float s )
{
	MCMatrix_t r = Identity();
	r.m[0][0] = r.m[1][1] = r.m[2][2] = s;
	return r;
}

MCMatrix_t MCMatrix_t::RotX( float d )
{
	float c = cosf( DEG2RAD( d ) ), s = sinf( DEG2RAD( d ) );
	MCMatrix_t r = Identity();
	r.m[1][1] = c; r.m[1][2] = -s;
	r.m[2][1] = s; r.m[2][2] = c;
	return r;
}

MCMatrix_t MCMatrix_t::RotY( float d )
{
	float c = cosf( DEG2RAD( d ) ), s = sinf( DEG2RAD( d ) );
	MCMatrix_t r = Identity();
	r.m[0][0] = c;  r.m[0][2] = s;
	r.m[2][0] = -s; r.m[2][2] = c;
	return r;
}

MCMatrix_t MCMatrix_t::RotZ( float d )
{
	float c = cosf( DEG2RAD( d ) ), s = sinf( DEG2RAD( d ) );
	MCMatrix_t r = Identity();
	r.m[0][0] = c; r.m[0][1] = -s;
	r.m[1][0] = s; r.m[1][1] = c;
	return r;
}

MCMatrix_t MCMatrix_t::Basis( const Vector &x, const Vector &y, const Vector &z, const Vector &origin )
{
	MCMatrix_t r = Identity();
	for ( int i = 0; i < 3; i++ )
	{
		r.m[i][0] = x[i];
		r.m[i][1] = y[i];
		r.m[i][2] = z[i];
		r.m[i][3] = origin[i];
	}
	return r;
}

MCMatrix_t MCMatrix_t::operator*( const MCMatrix_t &b ) const
{
	MCMatrix_t r;
	for ( int i = 0; i < 4; i++ )
	{
		for ( int j = 0; j < 4; j++ )
		{
			r.m[i][j] = m[i][0] * b.m[0][j] + m[i][1] * b.m[1][j] + m[i][2] * b.m[2][j] + m[i][3] * b.m[3][j];
		}
	}
	return r;
}

Vector MCMatrix_t::Transform( const Vector &p ) const
{
	return Vector( m[0][0] * p.x + m[0][1] * p.y + m[0][2] * p.z + m[0][3],
				   m[1][0] * p.x + m[1][1] * p.y + m[1][2] * p.z + m[1][3],
				   m[2][0] * p.x + m[2][1] * p.y + m[2][2] * p.z + m[2][3] );
}

Vector MCMatrix_t::Rotate( const Vector &v ) const
{
	return Vector( m[0][0] * v.x + m[0][1] * v.y + m[0][2] * v.z,
				   m[1][0] * v.x + m[1][1] * v.y + m[1][2] * v.z,
				   m[2][0] * v.x + m[2][1] * v.y + m[2][2] * v.z );
}

//-----------------------------------------------------------------------------
// Materials
//-----------------------------------------------------------------------------
IMaterial *MC_GetMaterial( const char *pszPath )
{
	static CUtlDict< IMaterial *, unsigned short > s_Cache;

	unsigned short idx = s_Cache.Find( pszPath );
	if ( idx != s_Cache.InvalidIndex() )
		return s_Cache[idx];

	IMaterial *pMaterial = materials->FindMaterial( pszPath, TEXTURE_GROUP_OTHER, false );
	if ( !pMaterial || pMaterial->IsErrorMaterial() )
	{
		pMaterial = NULL;
	}
	else
	{
		pMaterial->IncrementReferenceCount();
	}

	s_Cache.Insert( pszPath, pMaterial );
	return pMaterial;
}

void MC_GetLightColor( const Vector &vecPos, float flScale, unsigned char out[3] )
{
	Vector vecLight = engine->GetLightForPoint( vecPos, true );
	for ( int i = 0; i < 3; i++ )
	{
		// Linear light -> display brightness, with a little ambient so caves aren't pitch black
		float f = powf( clamp( vecLight[i] * flScale, 0.0f, 1.0f ), 1.0f / 2.2f );
		f = 0.12f + 0.88f * f;
		out[i] = (unsigned char)clamp( (int)( f * 255.0f ), 0, 255 );
	}
}

//-----------------------------------------------------------------------------
// Box drawing
//-----------------------------------------------------------------------------

// Corners of each face (TL, TR, BR, BL as seen from outside), as min/max selectors per axis
static const int s_FaceCorners[MC_FACE_COUNT][4][3] =
{
	// +X: right of the face is -Z
	{ { 1, 1, 1 }, { 1, 1, 0 }, { 1, 0, 0 }, { 1, 0, 1 } },
	// -X: right is +Z
	{ { 0, 1, 0 }, { 0, 1, 1 }, { 0, 0, 1 }, { 0, 0, 0 } },
	// +Y (top): up on the texture is -Z
	{ { 0, 1, 0 }, { 1, 1, 0 }, { 1, 1, 1 }, { 0, 1, 1 } },
	// -Y (bottom)
	{ { 0, 0, 1 }, { 1, 0, 1 }, { 1, 0, 0 }, { 0, 0, 0 } },
	// +Z: right is +X
	{ { 0, 1, 1 }, { 1, 1, 1 }, { 1, 0, 1 }, { 0, 0, 1 } },
	// -Z: right is -X
	{ { 1, 1, 0 }, { 0, 1, 0 }, { 0, 0, 0 }, { 1, 0, 0 } },
};

// Minecraft's directional face shading
static const float s_FaceShade[MC_FACE_COUNT] = { 0.6f, 0.6f, 1.0f, 0.5f, 0.8f, 0.8f };

void MC_DrawBox( const MCMatrix_t &xform, const Vector &mins, const Vector &maxs,
				 IMaterial * const *pMaterials, const MCFaceUV_t *pUVs,
				 const unsigned char rgb[3], bool bShadeFaces )
{
	CMatRenderContextPtr pRenderContext( materials );
	pRenderContext->MatrixMode( MATERIAL_MODEL );
	pRenderContext->PushMatrix();
	pRenderContext->LoadIdentity();

	bool bDone[MC_FACE_COUNT] = { false, false, false, false, false, false };

	for ( int f = 0; f < MC_FACE_COUNT; f++ )
	{
		if ( bDone[f] || !pMaterials[f] )
			continue;

		// Batch all faces sharing this material
		IMaterial *pMaterial = pMaterials[f];
		int iCount = 0;
		for ( int g = f; g < MC_FACE_COUNT; g++ )
			if ( !bDone[g] && pMaterials[g] == pMaterial )
				iCount++;

		pRenderContext->Bind( pMaterial );
		IMesh *pMesh = pRenderContext->GetDynamicMesh();
		CMeshBuilder mb;
		mb.Begin( pMesh, MATERIAL_QUADS, iCount );

		for ( int g = f; g < MC_FACE_COUNT; g++ )
		{
			if ( bDone[g] || pMaterials[g] != pMaterial )
				continue;
			bDone[g] = true;

			float flShade = bShadeFaces ? s_FaceShade[g] : 1.0f;
			unsigned char r = (unsigned char)( rgb[0] * flShade );
			unsigned char gg = (unsigned char)( rgb[1] * flShade );
			unsigned char b = (unsigned char)( rgb[2] * flShade );

			const MCFaceUV_t &uv = pUVs[g];
			const float us[4] = { uv.u0, uv.u1, uv.u1, uv.u0 };
			const float vs[4] = { uv.v0, uv.v0, uv.v1, uv.v1 };

			for ( int c = 0; c < 4; c++ )
			{
				const int *sel = s_FaceCorners[g][c];
				Vector p( sel[0] ? maxs.x : mins.x, sel[1] ? maxs.y : mins.y, sel[2] ? maxs.z : mins.z );
				Vector w = xform.Transform( p );
				mb.Position3f( w.x, w.y, w.z );
				mb.Color4ub( r, gg, b, 255 );
				mb.TexCoord2f( 0, us[c], vs[c] );
				mb.AdvanceVertex();
			}
		}

		mb.End();
		pMesh->Draw();
	}

	pRenderContext->MatrixMode( MATERIAL_MODEL );
	pRenderContext->PopMatrix();
}

// Box-local (y up) -> Source world (z up), scaled and centered
static MCMatrix_t MC_WorldBlockXform( const Vector &vecCenter )
{
	return MCMatrix_t::Basis( Vector( 1, 0, 0 ), Vector( 0, 0, 1 ), Vector( 0, -1, 0 ), vecCenter );
}

static void MC_BlockMaterials( int iItem, IMaterial *pMats[MC_FACE_COUNT] )
{
	const MCItemDef_t *pDef = MC_GetItem( iItem );
	char szPath[128];

	Q_snprintf( szPath, sizeof( szPath ), "mc/block/%s", pDef->pszTexSide ? pDef->pszTexSide : "stone" );
	IMaterial *pSide = MC_GetMaterial( szPath );
	Q_snprintf( szPath, sizeof( szPath ), "mc/block/%s", pDef->pszTexTop ? pDef->pszTexTop : "stone" );
	IMaterial *pTop = MC_GetMaterial( szPath );
	Q_snprintf( szPath, sizeof( szPath ), "mc/block/%s", pDef->pszTexBottom ? pDef->pszTexBottom : "stone" );
	IMaterial *pBottom = MC_GetMaterial( szPath );

	// Placeholder when textures aren't installed: HL2's own debug material
	IMaterial *pFallback = MC_GetMaterial( "debug/debugdrawflat" );
	if ( !pSide ) pSide = pFallback;
	if ( !pTop ) pTop = pSide;
	if ( !pBottom ) pBottom = pSide;

	pMats[MC_FACE_POS_X] = pMats[MC_FACE_NEG_X] = pMats[MC_FACE_POS_Z] = pMats[MC_FACE_NEG_Z] = pSide;
	pMats[MC_FACE_POS_Y] = pTop;
	pMats[MC_FACE_NEG_Y] = pBottom;
}

static const MCFaceUV_t s_FullUV[MC_FACE_COUNT] =
{
	{ 0, 0, 1, 1 }, { 0, 0, 1, 1 }, { 0, 0, 1, 1 }, { 0, 0, 1, 1 }, { 0, 0, 1, 1 }, { 0, 0, 1, 1 },
};

void MC_DrawBlock( const Vector &vecCenter, float flHalfSize, int iItem, const unsigned char rgb[3] )
{
	IMaterial *pMats[MC_FACE_COUNT];
	MC_BlockMaterials( iItem, pMats );

	Vector vecHalf( flHalfSize, flHalfSize, flHalfSize );
	MC_DrawBox( MC_WorldBlockXform( vecCenter ), -vecHalf, vecHalf, pMats, s_FullUV, rgb, true );
}

void MC_DrawCracks( const Vector &vecCenter, float flHalfSize, int iStage )
{
	char szPath[64];
	Q_snprintf( szPath, sizeof( szPath ), "mc/block/destroy_stage_%d", clamp( iStage, 0, 9 ) );
	IMaterial *pMaterial = MC_GetMaterial( szPath );
	if ( !pMaterial )
		return;

	IMaterial *pMats[MC_FACE_COUNT] = { pMaterial, pMaterial, pMaterial, pMaterial, pMaterial, pMaterial };
	const unsigned char white[3] = { 255, 255, 255 };
	Vector vecHalf( flHalfSize, flHalfSize, flHalfSize );
	MC_DrawBox( MC_WorldBlockXform( vecCenter ), -vecHalf, vecHalf, pMats, s_FullUV, white, false );
}

void MC_DrawQuad( const MCMatrix_t &xform, IMaterial *pMaterial, const unsigned char rgb[3] )
{
	if ( !pMaterial )
		return;

	CMatRenderContextPtr pRenderContext( materials );
	pRenderContext->MatrixMode( MATERIAL_MODEL );
	pRenderContext->PushMatrix();
	pRenderContext->LoadIdentity();

	pRenderContext->Bind( pMaterial );
	IMesh *pMesh = pRenderContext->GetDynamicMesh();
	CMeshBuilder mb;
	mb.Begin( pMesh, MATERIAL_QUADS, 2 );

	// Unit square in the local XY plane, y up; drawn twice so it shows from both sides
	static const float corners[4][2] = { { -0.5f, 0.5f }, { 0.5f, 0.5f }, { 0.5f, -0.5f }, { -0.5f, -0.5f } };
	static const float uvs[4][2] = { { 0, 0 }, { 1, 0 }, { 1, 1 }, { 0, 1 } };
	for ( int side = 0; side < 2; side++ )
	{
		for ( int c = 0; c < 4; c++ )
		{
			int k = side ? 3 - c : c;
			Vector w = xform.Transform( Vector( corners[k][0], corners[k][1], 0.0f ) );
			mb.Position3f( w.x, w.y, w.z );
			mb.Color4ub( rgb[0], rgb[1], rgb[2], 255 );
			mb.TexCoord2f( 0, uvs[k][0], uvs[k][1] );
			mb.AdvanceVertex();
		}
	}

	mb.End();
	pMesh->Draw();

	pRenderContext->MatrixMode( MATERIAL_MODEL );
	pRenderContext->PopMatrix();
}

void MC_DrawItemModel( const MCMatrix_t &xform, int iItem, const unsigned char rgb[3] )
{
	const MCItemDef_t *pDef = MC_GetItem( iItem );
	if ( pDef->kind == MC_KIND_BLOCK )
	{
		IMaterial *pMats[MC_FACE_COUNT];
		MC_BlockMaterials( iItem, pMats );
		MC_DrawBox( xform, Vector( -0.5f, -0.5f, -0.5f ), Vector( 0.5f, 0.5f, 0.5f ), pMats, s_FullUV, rgb, true );
	}
	else if ( pDef->kind == MC_KIND_TOOL )
	{
		char szPath[128];
		Q_snprintf( szPath, sizeof( szPath ), "mc/item/%s", pDef->pszName );
		IMaterial *pMaterial = MC_GetMaterial( szPath );
		if ( !pMaterial )
			pMaterial = MC_GetMaterial( "debug/debugdrawflat" );
		MC_DrawQuad( xform, pMaterial, rgb );
	}
}
