//========= HL2:MC - Minecraft-style player mechanics for Half-Life 2 =========//
//
// Purpose: Item icons for GUI slots.
//
//=============================================================================//

#include "cbase.h"
#include "hud.h"
#include "c_baseplayer.h"
#include "mc/mc_items.h"
#include "mc/mc_itemicons.h"
#include <vgui/ISurface.h>
#include <vgui/ILocalize.h>
#include <vgui_controls/Controls.h>
#include "tier3/tier3.h"

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"

using namespace vgui;

extern ConVar mc_hud_icon_color;

//-----------------------------------------------------------------------------
// Isometric block, like Minecraft's inventory rendering
//-----------------------------------------------------------------------------
static bool MC_DrawIsoFace( const char *pszSprite, const Vector2D pts[4], const MCGui_t &gui, int x, int y, float flShade, int iAlpha )
{
	const MCSprite_t *pSprite = CMCSprites::Get().Find( pszSprite );
	if ( !pSprite )
		return false;

	const float s = (float)gui.scale;
	Vertex_t verts[4];
	const Vector2D uv[4] = { Vector2D( 0, 0 ), Vector2D( pSprite->u1, 0 ), Vector2D( pSprite->u1, pSprite->v1 ), Vector2D( 0, pSprite->v1 ) };
	for ( int i = 0; i < 4; i++ )
		verts[i].Init( Vector2D( ( x + pts[i].x ) * s, ( y + pts[i].y ) * s ), uv[i] );

	int c = (int)( 255 * flShade );
	surface()->DrawSetColor( Color( c, c, c, iAlpha ) );
	surface()->DrawSetTexture( pSprite->iTexture );
	surface()->DrawTexturedPolygon( 4, verts );
	return true;
}

static void MC_DrawBlockIcon( int iItem, int x, int y, const MCGui_t &gui, int iAlpha )
{
	const MCItemDef_t *pDef = MC_GetItem( iItem );
	char szTop[64], szSide[64];
	Q_snprintf( szTop, sizeof( szTop ), "block_%s", pDef->pszTexTop );
	Q_snprintf( szSide, sizeof( szSide ), "block_%s", pDef->pszTexSide );

	static const Vector2D top[4]   = { Vector2D( 8.0f, 1.0f ), Vector2D( 14.5f, 4.4f ), Vector2D( 8.0f, 7.8f ), Vector2D( 1.5f, 4.4f ) };
	static const Vector2D left[4]  = { Vector2D( 1.5f, 4.4f ), Vector2D( 8.0f, 7.8f ), Vector2D( 8.0f, 15.0f ), Vector2D( 1.5f, 11.6f ) };
	static const Vector2D right[4] = { Vector2D( 8.0f, 7.8f ), Vector2D( 14.5f, 4.4f ), Vector2D( 14.5f, 11.6f ), Vector2D( 8.0f, 15.0f ) };

	bool bOk = MC_DrawIsoFace( szSide, left, gui, x, y, 0.8f, iAlpha );
	bOk = MC_DrawIsoFace( szSide, right, gui, x, y, 0.6f, iAlpha ) && bOk;
	bOk = MC_DrawIsoFace( szTop, top, gui, x, y, 1.0f, iAlpha ) && bOk;

	if ( !bOk )
	{
		// Placeholder: a small square with the item's initial
		CMCSprites::FillRect( x + 2, y + 2, 12, 12, gui, Color( 120, 100, 80, iAlpha ) );
		char szLetter[2] = { (char)toupper( pDef->pszDisplay[0] ), 0 };
		CMCSprites::Get().DrawString( szLetter, x + 5, y + 4, gui, Color( 255, 255, 255, iAlpha ) );
	}
}

//-----------------------------------------------------------------------------
// HL2 weapon glyphs, sized to fit a slot
//-----------------------------------------------------------------------------
static vgui::HFont MC_IconFont( int iTall )
{
	static CUtlMap< int, vgui::HFont > s_Fonts( DefLessFunc( int ) );
	unsigned short idx = s_Fonts.Find( iTall );
	if ( idx != s_Fonts.InvalidIndex() )
		return s_Fonts[idx];

	// "HalfLife2" is the icon font the HL2 scheme loads (halflife2.ttf)
	vgui::HFont hFont = surface()->CreateFont();
	surface()->SetFontGlyphSet( hFont, "HalfLife2", iTall, 0, 0, 0, ISurface::FONTFLAG_ANTIALIAS | ISurface::FONTFLAG_ADDITIVE | ISurface::FONTFLAG_CUSTOM );
	s_Fonts.Insert( iTall, hFont );
	return hFont;
}

static void MC_DrawWeaponIcon( C_BaseCombatWeapon *pWeapon, int x, int y, const MCGui_t &gui, int iAlpha )
{
	const CHudTexture *pIcon = pWeapon->GetSpriteInactive();
	if ( !pIcon )
		pIcon = pWeapon->GetSpriteActive();

	int r = 255, g = 236, b = 160;
	sscanf( mc_hud_icon_color.GetString(), "%d %d %d", &r, &g, &b );
	const Color tint( r, g, b, iAlpha );

	const int s = gui.scale;
	const int iBox = 18 * s;
	const int iCenterX = ( x + 8 ) * s;
	const int iCenterY = ( y + 8 ) * s;

	if ( !pIcon )
	{
		const char *pszClass = pWeapon->GetName();	// "weapon_xxx"
		char szLetter[2] = { Q_strlen( pszClass ) > 7 ? (char)toupper( pszClass[7] ) : '?', 0 };
		CMCSprites::Get().DrawString( szLetter, x + 5, y + 4, gui, tint );
		return;
	}

	if ( pIcon->bRenderUsingFont )
	{
		const wchar_t ch = (wchar_t)(unsigned char)pIcon->cCharacterInFont;
		int iTall = 16 * s;
		vgui::HFont hFont = MC_IconFont( iTall );
		int w = surface()->GetCharacterWidth( hFont, ch );
		if ( w > iBox && w > 0 )
		{
			iTall = MAX( 4, iTall * iBox / w );
			hFont = MC_IconFont( iTall );
			w = surface()->GetCharacterWidth( hFont, ch );
		}
		const int h = surface()->GetFontTall( hFont );
		surface()->DrawSetTextFont( hFont );
		surface()->DrawSetTextColor( tint );
		surface()->DrawSetTextPos( iCenterX - w / 2, iCenterY - h / 2 );
		surface()->DrawUnicodeChar( ch );
	}
	else
	{
		int w = pIcon->Width(), h = pIcon->Height();
		if ( w <= 0 || h <= 0 )
			return;
		float flScale = MIN( (float)iBox / w, (float)( 16 * s ) / h );
		int dw = (int)( w * flScale ), dh = (int)( h * flScale );
		pIcon->DrawSelf( iCenterX - dw / 2, iCenterY - dh / 2, dw, dh, tint );
	}
}

//-----------------------------------------------------------------------------
void MC_DrawItemIcon( int iItem, int x, int y, const MCGui_t &gui, C_BasePlayer *pPlayer, int iAlpha )
{
	const MCItemDef_t *pDef = MC_GetItem( iItem );
	switch ( pDef->kind )
	{
	case MC_KIND_BLOCK:
		MC_DrawBlockIcon( iItem, x, y, gui, iAlpha );
		break;

	case MC_KIND_TOOL:
	{
		char szName[64];
		Q_snprintf( szName, sizeof( szName ), "item_%s", pDef->pszName );
		if ( !CMCSprites::Get().DrawSprite( szName, x, y, gui, Color( 255, 255, 255, iAlpha ) ) )
		{
			CMCSprites::FillRect( x + 3, y + 3, 10, 10, gui, Color( 150, 150, 160, iAlpha ) );
			char szLetter[2] = { (char)toupper( pDef->pszDisplay[0] ), 0 };
			CMCSprites::Get().DrawString( szLetter, x + 5, y + 4, gui, Color( 255, 255, 255, iAlpha ) );
		}
		break;
	}

	case MC_KIND_WEAPON:
	{
		const char *pszClass = MC_WeaponClassForItem( iItem );
		C_BaseCombatWeapon *pWeapon = ( pPlayer && pszClass ) ? pPlayer->Weapon_OwnsThisType( pszClass ) : NULL;
		if ( pWeapon )
			MC_DrawWeaponIcon( pWeapon, x, y, gui, iAlpha );
		break;
	}

	default:
		break;
	}
}

void MC_DrawItemDecorations( int iItem, int iCount, int iDamage, int x, int y, const MCGui_t &gui )
{
	const MCItemDef_t *pDef = MC_GetItem( iItem );

	// Tool wear bar (green -> red), like Minecraft
	if ( pDef->kind == MC_KIND_TOOL && iDamage > 0 && pDef->iMaxDurability > 0 )
	{
		float flLeft = 1.0f - (float)iDamage / pDef->iMaxDurability;
		int iWidth = (int)( flLeft * 13.0f + 0.5f );
		float flHue = MAX( 0.0f, flLeft ) / 3.0f;	// 0 = red, 1/3 = green
		// HSV(hue, 1, 1) -> RGB for hues between red and green
		int r = (int)( clamp( 2.0f - 6.0f * flHue, 0.0f, 1.0f ) * 255 );
		int g = (int)( clamp( 6.0f * flHue, 0.0f, 1.0f ) * 255 );
		CMCSprites::FillRect( x + 2, y + 13, 13, 2, gui, Color( 0, 0, 0, 255 ) );
		CMCSprites::FillRect( x + 2, y + 13, iWidth, 1, gui, Color( r, g, 0, 255 ) );
	}

	if ( iCount > 1 )
	{
		char szCount[16];
		Q_snprintf( szCount, sizeof( szCount ), "%d", iCount );
		CMCSprites &sprites = CMCSprites::Get();
		sprites.DrawString( szCount, x + 19 - 2 - sprites.TextWidth( szCount, gui ), y + 6 + 3, gui, Color( 255, 255, 255, 255 ), true );
	}
}

void MC_GetItemDisplayName( int iItem, char *pszOut, int iSize )
{
	const char *pszClass = MC_WeaponClassForItem( iItem );
	if ( pszClass )
	{
		C_BasePlayer *pPlayer = C_BasePlayer::GetLocalPlayer();
		C_BaseCombatWeapon *pWeapon = pPlayer ? pPlayer->Weapon_OwnsThisType( pszClass ) : NULL;
		if ( pWeapon )
		{
			const char *pszPrint = pWeapon->GetPrintName();
			const wchar_t *pwsz = g_pVGuiLocalize->Find( pszPrint );
			if ( pwsz )
			{
				g_pVGuiLocalize->ConvertUnicodeToANSI( pwsz, pszOut, iSize );
				// HL2 names have a second line like "(GRAVITY GUN)"; keep the first
				char *pNewline = strchr( pszOut, '\n' );
				if ( pNewline )
					*pNewline = 0;
				return;
			}
			Q_strncpy( pszOut, pszPrint, iSize );
			return;
		}
	}

	Q_strncpy( pszOut, MC_GetItem( iItem )->pszDisplay, iSize );
}
