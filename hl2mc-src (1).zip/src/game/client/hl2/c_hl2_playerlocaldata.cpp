//========= Copyright Valve Corporation, All rights reserved. ============//
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================//
#include "cbase.h"
#include "c_hl2_playerlocaldata.h"
#include "dt_recv.h"

// memdbgon must be the last include file in a .cpp file!!!
#include "tier0/memdbgon.h"

BEGIN_RECV_TABLE_NOBASE( C_HL2PlayerLocalData, DT_HL2Local )
	RecvPropFloat( RECVINFO(m_flSuitPower) ),
	RecvPropInt( RECVINFO(m_bZooming) ),
	RecvPropInt( RECVINFO(m_bitsActiveDevices) ),
	RecvPropInt( RECVINFO(m_iSquadMemberCount) ),
	RecvPropInt( RECVINFO(m_iSquadMedicCount) ),
	RecvPropBool( RECVINFO(m_fSquadInFollowMode) ),
	RecvPropBool( RECVINFO(m_bWeaponLowered) ),
	RecvPropEHandle( RECVINFO(m_hAutoAimTarget) ),
	RecvPropVector( RECVINFO(m_vecAutoAimPoint) ),
	RecvPropEHandle( RECVINFO(m_hLadder) ),
	RecvPropBool( RECVINFO(m_bDisplayReticle) ),
	RecvPropBool( RECVINFO(m_bStickyAutoAim) ),
	RecvPropBool( RECVINFO(m_bAutoAimTarget) ),
#ifdef HL2_EPISODIC
	RecvPropFloat( RECVINFO(m_flFlashBattery) ),
	RecvPropVector( RECVINFO(m_vecLocatorOrigin) ),
#endif
	// HL2:MC
	RecvPropInt( RECVINFO(m_iMCFood) ),
	RecvPropFloat( RECVINFO(m_flMCSaturation) ),
	RecvPropFloat( RECVINFO(m_flMCExhaustion) ),
	RecvPropInt( RECVINFO(m_iMCXPTotal) ),
	RecvPropInt( RECVINFO(m_iMCXPLevel) ),
	RecvPropFloat( RECVINFO(m_flMCXPProgress) ),
	RecvPropInt( RECVINFO(m_iMCAir) ),
	RecvPropInt( RECVINFO(m_iMCArmor) ),
	RecvPropArray3( RECVINFO_ARRAY(m_iMCInvItem), RecvPropInt( RECVINFO(m_iMCInvItem[0]) ) ),
	RecvPropArray3( RECVINFO_ARRAY(m_iMCInvCount), RecvPropInt( RECVINFO(m_iMCInvCount[0]) ) ),
	RecvPropArray3( RECVINFO_ARRAY(m_iMCInvDamage), RecvPropInt( RECVINFO(m_iMCInvDamage[0]) ) ),
	RecvPropInt( RECVINFO(m_iMCCursorItem) ),
	RecvPropInt( RECVINFO(m_iMCCursorCount) ),
	RecvPropInt( RECVINFO(m_iMCCursorDamage) ),
	RecvPropInt( RECVINFO(m_iMCSelected) ),
	RecvPropInt( RECVINFO(m_iMCGameMode) ),
	RecvPropBool( RECVINFO(m_bMCFlying) ),
	RecvPropEHandle( RECVINFO(m_hMCBreakTarget) ),
	RecvPropFloat( RECVINFO(m_flMCBreakProgress) ),
	RecvPropInt( RECVINFO(m_iMCSwingCount) ),
END_RECV_TABLE()

BEGIN_PREDICTION_DATA_NO_BASE( C_HL2PlayerLocalData )
	DEFINE_PRED_FIELD( m_hLadder, FIELD_EHANDLE, FTYPEDESC_INSENDTABLE ),
	DEFINE_PRED_FIELD( m_bMCFlying, FIELD_BOOLEAN, FTYPEDESC_INSENDTABLE ),
END_PREDICTION_DATA()

C_HL2PlayerLocalData::C_HL2PlayerLocalData()
{
	m_flSuitPower = 0.0;
	m_bZooming = false;
	m_iSquadMemberCount = 0;
	m_iSquadMedicCount = 0;
	m_fSquadInFollowMode = false;
	m_bWeaponLowered = false;
	m_hLadder = NULL;
	m_iMCFood = 20;
	m_flMCSaturation = 5.0f;
	m_flMCExhaustion = 0.0f;
	m_iMCXPTotal = 0;
	m_iMCXPLevel = 0;
	m_flMCXPProgress = 0.0f;
	m_iMCAir = 300;
	m_iMCArmor = 0;
	memset( m_iMCInvItem, 0, sizeof( m_iMCInvItem ) );
	memset( m_iMCInvCount, 0, sizeof( m_iMCInvCount ) );
	memset( m_iMCInvDamage, 0, sizeof( m_iMCInvDamage ) );
	m_iMCCursorItem = m_iMCCursorCount = m_iMCCursorDamage = 0;
	m_iMCSelected = 0;
	m_iMCGameMode = 0;
	m_bMCFlying = false;
	m_hMCBreakTarget = NULL;
	m_flMCBreakProgress = 0.0f;
	m_iMCSwingCount = 0;
#ifdef HL2_EPISODIC
	m_flFlashBattery = 0.0f;
	m_vecLocatorOrigin = vec3_origin;
#endif
}

